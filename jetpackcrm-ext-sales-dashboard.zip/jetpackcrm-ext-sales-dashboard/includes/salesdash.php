<?php // phpcs:ignore Squiz.Commenting.FileComment.Missing

/**
 * Defines and returns Sales Dashboard chart data
 */
function jpcrm_salesdash_charts() {
	$charts = array(
		'gross_sales'   => array(
			'title'  => __( 'Gross revenue', 'zero-bs-crm' ),
			'cumul'  => __( 'cumulative', 'zero-bs-crm' ),
			'svg_id' => 'gross',
		),
		'zbs_discounts' => array(
			'title'  => __( 'Discounts', 'zero-bs-crm' ),
			'cumul'  => __( 'non-cumulative', 'zero-bs-crm' ),
			'svg_id' => 'zbsdisc',
		),
		// 'ave_rev'       => array(
		// 	'title'  => __( 'Average revenue', 'zero-bs-crm' ),
		// 	'svg_id' => 'ave',
		// ),
		'zbs_refunds'   => array(
			'title'  => __( 'Refunds', 'zero-bs-crm' ),
			'cumul'  => __( 'non-cumulative', 'zero-bs-crm' ),
			'svg_id' => 'zbs_ref',
		),
		'zbs_failed'    => array(
			'title'  => __( 'Failed payments', 'zero-bs-crm' ),
			'cumul'  => __( 'non-cumulative', 'zero-bs-crm' ),
			'svg_id' => 'zbs_fail',
		),
		'net_sales'     => array(
			'title'  => __( 'Net Revenue', 'zero-bs-crm' ),
			'cumul'  => __( 'non-cumulative', 'zero-bs-crm' ),
			'svg_id' => 'net',
		),
		'zbs_fee'       => array(
			'title'  => __( 'Fees', 'zero-bs-crm' ),
			'cumul'  => __( 'non-cumulative', 'zero-bs-crm' ),
			'svg_id' => 'zbs_fee',
		),
		'zbs_newcust'   => array(
			'title'  => __( 'New contacts', 'zero-bs-crm' ),
			'cumul'  => __( 'non-cumulative', 'zero-bs-crm' ),
			'svg_id' => 'zbs_newcust',
		),
		'zbs_totcust'   => array(
			'title'  => __( 'Total contacts', 'zero-bs-crm' ),
			'cumul'  => __( 'cumulative', 'zero-bs-crm' ),
			'svg_id' => 'zbs_totcust',
		),
	);
	return $charts;
}

/**
 * Sort by date created
 */
function jpcrm_salesdash_sort_activity( $a, $b ) {
	$a_val = (int) $a['zbsc_created'];
	$b_val = (int) $b['zbsc_created'];

	if ( $a_val === $b_val ) {
			return 0;
	}
	return ( $a_val < $b_val ) ? -1 : 1;
}

/**
 * Creates Sales Dashboard page content
 */
function jpcrm_salesdash_page() {

	$charts = jpcrm_salesdash_charts();

	echo '<div class="jpcrm-salesdash-charts">';

	foreach ( $charts as $chart_key => $chart_data ) {
		?>
		<div class="jpcrm-salesdash-chart <?php echo esc_attr( $chart_key ); ?>">
			<div class="title"><?php echo esc_html( $chart_data['title'] ); ?>
			<?php echo empty( $chart_data['cumul'] ) ? '' : '<span class="cumul">(' . esc_html( $chart_data['cumul'] ) . ')</span>'; ?>
		</div>
			<div class="max_this">
				<span class="max_this_value"></span>
				<br/>
				<div class="prev_val">
					vs  <span class="max_prev_value"></span>
				</div>
			</div>
			<div class="compare_this">
				<div class="which up">
					<div class="by">tbc</div>
					<div class="time-ago">last month</div>
				</div>
			</div>
			<svg id="<?php echo esc_attr( $chart_data['svg_id'] ); ?>" width="100%" height="125"></svg>
			<div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
		</div>
		<?php
	}

	?>
	</div>
	<?php
	// Loads recent activity...but disabled for now, as it's half-baked
	// jpcrm_salesdash_activity();
}

/**
 * Display recent activity
 *
 * Note that the output isn't actionable and has issues
 * If/when we use this, we'll want to make it prettier
 */
function jpcrm_salesdash_activity() {
	global $wpdb;
	global $zbs_curr;
	$zbs_curr = zeroBSCRM_getCurrencyChr();

	// get activity
	global $ZBSCRM_t; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase

	$sql = 'SELECT * FROM (
			(SELECT ID, ID AS zbsc_customer, "contact" as table_name, zbsc_created, zbsc_status, zbsc_fname, zbsc_lname, zbsc_email FROM ' . $ZBSCRM_t['contacts'] . ')
			UNION ALL
			(SELECT ID, (SELECT zbsol_objid_to FROM ' . $ZBSCRM_t['objlinks'] . ' WHERE zbsol_objtype_from = ' . ZBS_TYPE_TRANSACTION . ' AND zbsol_objtype_to = ' . ZBS_TYPE_CONTACT . ' AND zbsol_objid_from = ' . $ZBSCRM_t['transactions'] . '.ID ORDER BY ID ASC LIMIT 1) as zbsc_customer, "transaction" as table_name, zbst_created, zbst_status, zbst_total, zbst_title, NULL FROM ' . $ZBSCRM_t['transactions'] . ')
			) results ORDER BY zbsc_created DESC LIMIT 20';

	$results = $wpdb->get_results( $sql, 'ARRAY_A' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.NotPrepared

	usort( $results, 'jpcrm_salesdash_sort_activity' );

	$results = array_reverse( $results );
	?>
	<div class="jpcrm-salesdash-activity">
		<h3 class='title'><i class='icon heartbeat'></i> <?php esc_html_e( 'Recent Activity', 'zero-bs-crm' ); ?></h3>
		<div class="ui relaxed divided list" style="padding:0px 20px 20px 20px;">
			<?php
			foreach ( $results as $result ) {
				if ( $result['table_name'] === 'transaction' ) {

					echo '<div class="item">';
					echo '<div class="content">';

					echo zeroBS_getCustomerIcoLinkedLabel( $result['zbsc_customer'], true, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<a class="header">';
					echo esc_html( $result['zbsc_lname'] . ' - ' . zeroBSCRM_formatCurrency( $result['zbsc_fname'] ) ) . '</a>';
					echo '<div class="description">' . esc_html__( ' with status ', 'zero-bs-crm' );

					$stat_class = 'bold trans-stat ' . $result['zbsc_status'];

					echo '<span class="' . esc_attr( $stat_class ) . '">' . esc_html( ucfirst( $result['zbsc_status'] ) ) . '</span>';

					echo '</div>';
					echo '</div>';
					echo '</div>';
				} elseif ( $result['table_name'] === 'contact' ) {
					echo '<div class="item">';
					echo '<div class="content">';
					echo '<span class="ui label black zbs-hide">' . esc_html__( 'Contact', 'zero-bs-crm' ) . '</span>';

					echo zeroBS_getCustomerIcoLinkedLabel( $result['ID'], true, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

					echo '<span class="header">' . esc_html( __( 'New ', 'zero-bs-crm' ) . $result['zbsc_status'] ) . '</span>';

					echo '<div class="description">' . esc_html__( ' Send them a Follow Up Email ', 'zero-bs-crm' ) . '</div>';
					echo '</div>';
					echo '</div>';
				}
			}

			?>
		</div>
	</div>
	<?php
}