<?php
function jpcrm_sales_dashboard_learn_menus( $learn_menu_array ) {

	$report_range_html = '
		<label>' . esc_html__( 'Report range', 'zero-bs-crm' ) . ':</label>
		<div id="reportrange">
			<i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
			<span></span>
		</div>';

	$learn_menu_array[ 'salesdash' ] = array(
		'title'         => __( 'Sales Dashboard', 'zero-bs-crm' ),
		'show_learn'    => false,
		'right_buttons' => $report_range_html,
	);
	return $learn_menu_array;
}
add_filter( 'jpcrm_learn_menus', 'jpcrm_sales_dashboard_learn_menus' );
