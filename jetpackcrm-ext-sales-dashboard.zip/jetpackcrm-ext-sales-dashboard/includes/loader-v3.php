<?php


#} This adds to the "Extensions " menu :-) can probably do multi level addtiions
#} To control the ORDER of these, simply add the $priority parameter
add_filter('zbs-tools-menu', 'zeroBSCRM_salesdash_menu_link',1);
function zeroBSCRM_salesdash_menu_link($toolsMenu){
  global $zbs, $zbs_salesdash_slugs;
  $admin_url = zeroBSCRM_getAdminURL($zbs_salesdash_slugs['sales-dash']);
  
  $toolsMenu[] = '<a href="' . $admin_url . '" class="item"><i class="icon area chart"></i>  Sales Dashboard</a>';

  return $toolsMenu;
}


define('ZBSCRM_INC_EXT_SALESDASH',true);

global $zbs_salesdash_slugs, $zbs;

$zbs_salesdash_slugs['sales-dash']      = 'sales-dash';
$zbs_salesdash_slugs['gross']           = 'gross-revenue';
$zbs_salesdash_slugs['net']             = 'net-revenue';
$zbs_salesdash_slugs['discounts']       = 'discounts';
$zbs_salesdash_slugs['fees']           = 'fees';
$zbs_salesdash_slugs['average-rev']     = 'average-rev';
$zbs_salesdash_slugs['arr']             = 'arr';
$zbs_salesdash_slugs['new-customers']   = 'new-customers';
$zbs_salesdash_slugs['total-customers'] = 'total-customers';
$zbs_salesdash_slugs['refunds']         = 'refunds';



function zbs_admin_head() {
    global $wpdb;
    $query = "SELECT post_date FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' ORDER BY STR_TO_DATE(post_date, '%m/%d/%Y') ASC LIMIT 0,1";
    $r = $wpdb->get_results($query);

    #} WH fix, this will error out if empty post obj... 
    if (isset($r) && isset($r[0])){
        $createDate = new DateTime($r[0]->post_date);
        $strip = $createDate->format('m/d/Y');

        echo '<script type="text/javascript"> var zbs_min_trans_date = "' . $strip . '"; </script>';
        
    } else {

        echo '<script type="text/javascript"> var zbs_min_trans_date = "???"; </script>';

    }

}
add_action( 'admin_head', 'zbs_admin_head' );


// add filter to add header
add_filter('zbs-page-check', 'zeroBSCRM_salesdash_isPage');

// is our page?
function zeroBSCRM_salesdash_isPage($existingRes){

        $res = $existingRes;

        // if not already set as our page
        if (!$res){

            global $zbs_salesdash_slugs;

            // basic slug check
            if (isset($_GET['page'])) if (in_array($_GET['page'],$zbs_salesdash_slugs)) return true;

        }

        return $res;

}


add_action('zerobs_admin_menu' , 'zero_crm_sales_dash_menu'); 
function zero_crm_sales_dash_menu() {
   //  add_submenu_page('edit.php?post_type=zerobs_transaction', 'Dashboard', 'Dashboard', 'edit_posts', 'sales-dash', 'sales_dashboard_chart');
    global $zbs, $zbs_salesdash_slugs;
    $menu = add_submenu_page( 'zerobscrm-dash', 'Sales Dashboard', 'Sales Dashboard', 'manage_sales_dash', $zbs_salesdash_slugs['sales-dash'], 'jpcrm_salesdash_page', 1 );

    /*
    $submenu2 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Net Revenue', 'Net Revenue', 'manage_sales_dash', $zbs_salesdash_slugs['net'], 'zerobscrm_sales_net' );
    $submenu1 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Gross Revenue', 'Gross Revenue', 'manage_sales_dash', $zbs_salesdash_slugs['gross'], 'zerobscrm_sales_gross' );
    $submenu3 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Discounts', 'Discounts', 'manage_sales_dash', $zbs_salesdash_slugs['discounts'], 'zerobscrm_sales_discount' );
    $submenu4 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Fees', 'Fees', 'manage_sales_dash', $zbs_salesdash_slugs['fees'], 'zerobscrm_sales_fee' );
    $submenu5 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Average Revenue Per Customer', 'Average Revenue', 'manage_sales_dash', $zbs_salesdash_slugs['average-rev'], 'zerobscrm_sales_ave' );
   // $submenu6 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Annual Run Rate', 'Annual Run Rate', 'manage_sales_dash', $zbs_salesdash_slugs['arr'], 'zerobscrm_arr' );
    $submenu7 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'New Customers', 'New Customers', 'manage_sales_dash', $zbs_salesdash_slugs['new-customers'], 'zerobscrm_new' );
    $submenu8 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Total Customers', 'Total Customers', 'manage_sales_dash', $zbs_salesdash_slugs['total-customers'], 'zerobscrm_tot' );
   // $submenu9 = add_submenu_page( $zbs_salesdash_slugs['sales-dash'], 'Refunds', 'Refunds', 'manage_sales_dash', $zbs_salesdash_slugs['gross'], 'zerobscrm_refunds' );

    */

    add_action( 'admin_print_styles-' . $menu, 'zbscrm_sales_dashboard_admin_custom_css' );
    add_action( "admin_print_styles-{$menu}", 'zeroBSCRM_global_admin_styles' );  

    /*
    add_action( 'admin_print_styles-' . $submenu1, 'zbscrm_sales_dashboard_admin_custom_css' );
    add_action( 'admin_print_styles-' . $submenu2, 'zbscrm_sales_dashboard_admin_custom_css' );
    add_action( 'admin_print_styles-' . $submenu3, 'zbscrm_sales_dashboard_admin_custom_css' );
    add_action( 'admin_print_styles-' . $submenu4, 'zbscrm_sales_dashboard_admin_custom_css' );
    add_action( 'admin_print_styles-' . $submenu5, 'zbscrm_sales_dashboard_admin_custom_css' );
 //   add_action( 'admin_print_styles-' . $submenu6, 'zbscrm_sales_dashboard_admin_custom_css' );
    add_action( 'admin_print_styles-' . $submenu7, 'zbscrm_sales_dashboard_admin_custom_css' );
    add_action( 'admin_print_styles-' . $submenu8, 'zbscrm_sales_dashboard_admin_custom_css' );
  //  add_action( 'admin_print_styles-' . $submenu9, 'zbscrm_sales_dashboard_admin_custom_css' );
  */

    add_action( 'admin_print_scripts-' . $menu, 'zbscrm_sales_dashboard_admin_custom_scripts' );

    /*
    add_action( 'admin_print_scripts-' . $submenu1, 'zbscrm_gross_revenue_admin_custom_scripts' );
    add_action( 'admin_print_scripts-' . $submenu2, 'zbscrm_net_revenue_admin_custom_scripts' );
    add_action( 'admin_print_scripts-' . $submenu3, 'zbscrm_discount_revenue_admin_custom_scripts' );
    add_action( 'admin_print_scripts-' . $submenu4, 'zbscrm_fee_revenue_admin_custom_scripts' );
    add_action( 'admin_print_scripts-' . $submenu5, 'zbscrm_ave_revenue_admin_custom_scripts' );
    add_action( 'admin_print_scripts-' . $submenu7, 'zbscrm_new_admin_custom_scripts' );
    add_action( 'admin_print_scripts-' . $submenu8, 'zbscrm_tot_admin_custom_scripts' );
    */

}


#} Will create a table which holds for each day the following
/*

ID
total_value
total_customers

Since we don't actually have Envato customers for the purposes of crm.epicplugins.com it'll do the following 

total_transaction_value = sum($zbo['net']);

The metric gives an indication of the cost to accquire a customer (i.e. on average what each customer is worth)

*/
function zbscrm_sales_db_table(){
       global $wpdb,$epicred_db_version;
        $table_name = $wpdb->prefix . "zbs_global_total_trans";
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
          ID mediumint(9) NOT NULL AUTO_INCREMENT,
          check_point DATETIME DEFAULT NULL,
          total_value DECIMAL(20,2) NOT NULL,
          total_customers mediumint(9) NOT NULL,
          UNIQUE KEY ID (ID)
            );";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql); 
}
register_activation_hook(ZBSCRM_SALES_FILE,'zbscrm_sales_db_table');


function zbs_total_trans(){
    global $wpdb;
    // need to expose this as a run function via the sales dashboard.
    $this_start = get_option('zbs_this_start');
    $this_end   = get_option('zbs_this_end');

    if($this_start == ''){
      $this_start = date('Y-m-01');
      $datestring= $this_start . ' first day of next month';
      $dt=date_create($datestring);
      $this_end =  $dt->format('Y-m-01'); 
    }

    $datestring= $this_start . ' first day of last month';
    $dt=date_create($datestring);
    $that_start =  $dt->format('Y-m-01'); 
    $query = "SELECT ID, post_date, post_title FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_status ='publish'";
    $r = $wpdb->get_results($query);
      $i=0;
      $posts_times = array();
      $gross_revenue = array();
      $day_total = 0;

        foreach ($r as $post) {
            $do_this_ID = true;
            $post_time = strtotime($post->post_date);
            $offset = $post_time % (60*60*24);
            $post_time -= $offset;
            if($i == 0){
                $first_time = $post_time;
            }
            $i++;
            $posts_times[$post_time]++;
            $order = get_post_meta($post->ID,'zbs_transaction_meta', true);
            $terms = get_the_terms($post->ID,'zerobscrm_worktag');

            foreach($terms as $term){
                //if the term name is Envato..  do nothing so set a variable
                if($term->name == 'envato'){
                    $do_this_ID = false;
                }
            } 
                if($do_this_ID){
                    $grand_total += $order['total'];
                    $grand_total_rev[$post_time] = $grand_total;
                    $pt =  date('Y-m-d', $post_time);
                    $post_time_array[$post_time] = $pt;
                            
                    // DAL2 $query = "SELECT ID FROM $wpdb->posts WHERE post_type = 'zerobs_customer' AND post_status ='publish' AND post_date <= '$pt'";   
                        $cCount = $zbs->DAL->contacts->getContacts(array(
                              'olderThan' => $post_time,
                              'count' => true,
                              'ignoreowner' => true
                          ));

                    $customers[$post_time] = $cCount;      
                }
        }
            $j=0;
            foreach($post_time_array as $k => $v){
                 $table_name = $wpdb->prefix . "zbs_global_total_trans";
                 $time = $v;
                 $rev = $grand_total_rev[$k];
                 $cus = $customers[$k];
                $q = "INSERT into $table_name (check_point,total_value,total_customers) VALUES ('$time','$rev','$cus')";
                $wpdb->query($q);  //insert the record to the DB..
                 $i++;
            }
}
add_shortcode('zbs_total_trans','zbs_total_trans');




function zbscrm_sales_dashboard_admin_custom_css(){ 
    wp_enqueue_style('zerobscrmsales',     plugins_url('/css/ZeroBSCRM_Sales_Dashboard.css',ZBSCRM_SALES_FILE) );
}; 
function zbscrm_gross_revenue_admin_custom_scripts(){ 
    global $wpdb;
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_gross_revenue.min.js',ZBSCRM_SALES_FILE), array('d3js', 'd3tip') );
}; 
function zbscrm_net_revenue_admin_custom_scripts(){ 
    global $wpdb;
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_net_revenue.min.js',ZBSCRM_SALES_FILE), array('d3js', 'd3tip') );
};
function zbscrm_discount_revenue_admin_custom_scripts(){ 
    global $wpdb;
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_discount_revenue.min.js',ZBSCRM_SALES_FILE), array('d3js', 'd3tip') );
}; 
function zbscrm_fee_revenue_admin_custom_scripts(){ 
    global $wpdb;
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_fee_revenue.js',ZBSCRM_SALES_FILE), array('d3js', 'd3tip') );
}; 
function zbscrm_ave_revenue_admin_custom_scripts(){ 
    global $wpdb;
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_ave_revenue.min.js',ZBSCRM_SALES_FILE), array('d3js', 'd3tip') );
}; 
function zbscrm_new_admin_custom_scripts(){ 
    global $wpdb;
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_new.min.js',ZBSCRM_SALES_FILE), array('d3js', 'd3tip') );
}; 
function zbscrm_tot_admin_custom_scripts(){ 
    global $wpdb;
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_tot.min.js',ZBSCRM_SALES_FILE), array('d3js', 'd3tip') );
}; 
function zbscrm_sales_dashboard_admin_custom_scripts(){ 
    wp_enqueue_script('d3js',     plugins_url('/js/lib/d3.min.js',ZBSCRM_SALES_FILE) );
    wp_enqueue_script('d3tip',     plugins_url('/js/lib/d3tip.js',ZBSCRM_SALES_FILE), array('d3js') );
    wp_enqueue_script('zbs_moment', plugins_url('/js/lib/moment.min.js',ZBSCRM_SALES_FILE), array('jquery'));
    wp_enqueue_script('zbs_daterange', plugins_url('/js/lib/daterangepicker.min.js', ZBSCRM_SALES_FILE ), array('jquery','zbs_moment'));
    wp_enqueue_script('zerobscrmjs',     plugins_url('/js/zbs_sales_dashboard.js',ZBSCRM_SALES_FILE), array('d3js'), '1.0', true );
}


function zeroBSCRM_calculate_change($current, $previous){

    if($current == 0 && $previous == 0){
        $res['type'] = 'up';
        $res['perc'] = 0;
        return $res;
    }
    if($current == 0 && $previous > 0){
        //we have had a 100% reduction
        $res['type'] = 'down';
        $res['perc'] = 100;
        return $res;
    }
    if($previous == 0 && $current > 0){
        //we have had a 100% increase
        $res['type'] = 'up';
        $res['perc'] = 100;
        return $res;
    }

    if($current == $previous){
        //no change
        $res['type'] = 'up';
        $res['perc'] = 0;
        return $res;
    }


    if($current > $previous){
        $res['type'] = 'up';
        $res['perc'] = round(100*(($current / $previous) - 1),1);
        return $res;
    }

    if($current < $previous){
        $res['type'] = 'down';
        $res['perc'] = round(100*(($previous / $current) - 1),1);
        return $res;
    }
}

//gets the total transactions up to a certain end date
function zeroBSCRM_salesdash_totals($res = array(), $start = '', $end = '', $previous = ''){
    global $zbs, $wpdb;

    global $ZBSCRM_t;
    $contactsTable      = $ZBSCRM_t['contacts'];
    $transactionsTable  = $ZBSCRM_t['transactions']; 

			//build the SUM string
			$sum_current = "SUM(zbst_total) as gross_total_current, SUM(zbst_net) as net_total_current, SUM(zbst_discount) as discount_total_current, SUM(zbst_fee) as fee_total_current";
			$sum_previous = "SUM(zbst_total) as gross_total_previous, SUM(zbst_net) as net_total_previous, SUM(zbst_discount) as discount_total_previous, SUM(zbst_fee) as fee_total_previous";
			//buld the ADDITIONAL WHERES (i.e. WHERE zbsc_status != refunded) (since refunded can be another block)
			$extraWhere = " AND zbst_status <> 'refunded' AND zbst_status <> 'failed'";
	
	
			$refundWhere = " AND zbst_status = 'refunded'";
			$failedWhere = " AND zbst_status = 'failed'";

			$extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);
			$refundWhere = apply_filters('zbs-sales-dashboard-refund-status', $refundWhere);
			$failedWhere = apply_filters('zbs-sales-dashboard-failed-status', $failedWhere);

			//PURE SQL (FOR NOW)
			//transaction sum in current period
			$sql = $wpdb->prepare("SELECT ". $sum_current ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $extraWhere, $end, $start);
			$current_period = $wpdb->get_row($sql);

			$sql = $wpdb->prepare("SELECT ". $sum_previous ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $extraWhere, $start, $previous);
			$previous_period = $wpdb->get_row($sql);

			//gross totals
			$res['gross_total_current']         = zeroBSCRM_formatCurrency($current_period->gross_total_current);
			$res['gross_total_previous']        = zeroBSCRM_formatCurrency($previous_period->gross_total_previous);

			//gross change 
			$change = zeroBSCRM_calculate_change($current_period->gross_total_current, $previous_period->gross_total_previous);
			$res['type'] = $change['type'];
			$res['change'] = $change['perc'];

			//net totals
			$res['net_total_current']           = zeroBSCRM_formatCurrency($current_period->net_total_current);
			$res['net_total_previous']          = zeroBSCRM_formatCurrency($previous_period->net_total_previous);

			//net change 
			$change = zeroBSCRM_calculate_change($current_period->net_total_current, $previous_period->net_total_previous);
			$res['nettype'] = $change['type'];
			$res['netchange'] = $change['perc'];

			//discount totals
			$res['discount_total_current']     = zeroBSCRM_formatCurrency($current_period->discount_total_current);
			$res['discount_total_previous']    = zeroBSCRM_formatCurrency($previous_period->discount_total_previous);

			//discount change 
			$change = zeroBSCRM_calculate_change($current_period->discount_total_current, $previous_period->discount_total_previous);
			$res['distype'] = $change['type'];
			$res['dischange'] = $change['perc'];

			//fee totals
			$res['fee_total_current']           = zeroBSCRM_formatCurrency($current_period->fee_total_current);
			$res['fee_total_previous']          = zeroBSCRM_formatCurrency($previous_period->fee_total_previous);

			//fee change 
			$change = zeroBSCRM_calculate_change($current_period->fee_total_current, $previous_period->fee_total_previous);
			$res['feetype'] = $change['type'];
			$res['feechange'] = $change['perc'];

			//refunded
			//transaction sum in current period
			$sql = $wpdb->prepare("SELECT ". $sum_current ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $refundWhere, $end, $start);
			$current_refund = $wpdb->get_row($sql);

			$sql = $wpdb->prepare("SELECT ". $sum_previous ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $refundWhere, $start, $previous);
			$previous_refund = $wpdb->get_row($sql);

			//refund
			$res['refund_total_current']           = zeroBSCRM_formatCurrency($current_refund->gross_total_current);
			$res['refund_total_previous']          = zeroBSCRM_formatCurrency($previous_refund->gross_total_previous);

			$change = zeroBSCRM_calculate_change($current_refund->gross_total_current, $previous_refund->gross_total_previous);
			$res['refund_type'] = $change['type'];
			$res['refund_perc'] = $change['perc'];

			//failed (Stripe usually...)
			$sql = $wpdb->prepare("SELECT ". $sum_current ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $failedWhere, $end, $start);
			$current_failed = $wpdb->get_row($sql);


			$sql = $wpdb->prepare("SELECT ". $sum_previous ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $failedWhere, $start, $previous);
			$previous_failed = $wpdb->get_row($sql);

			//failed
			$res['failed_total_current']           = zeroBSCRM_formatCurrency($current_failed->gross_total_current);
			$res['failed_total_previous']          = zeroBSCRM_formatCurrency($previous_failed->gross_total_previous);


			$change = zeroBSCRM_calculate_change($current_failed->gross_total_current, $previous_failed->gross_total_previous);
			$res['failed_type'] = $change['type'];
			$res['failed_perc'] = $change['perc'];

			/* TOTAL REVENUE AT END */
			$sql = $wpdb->prepare("SELECT ". $sum_current ." FROM " . $transactionsTable . " WHERE zbst_created <= %s" . $extraWhere, $end);
			$total_current = $wpdb->get_row($sql);

			/* TOTAL REVENUE AT START */
			$sql = $wpdb->prepare("SELECT ". $sum_previous ." FROM " . $transactionsTable . " WHERE zbst_created <= %s" . $extraWhere, $start);
			$total_previous = $wpdb->get_row($sql);

			/* TOTAL CONTACTS AT END */
			$sql = $wpdb->prepare("SELECT count(ID) as customers FROM " . $contactsTable . " WHERE zbsc_created <= %s", $end);
			$total_current_cus = $wpdb->get_row($sql);

			/* TOTAL CONTACTS AT START */
			$sql = $wpdb->prepare("SELECT count(ID) as customers FROM " . $contactsTable . " WHERE zbsc_created <= %s", $start);
			$total_previous_cus = $wpdb->get_row($sql);


			/* TOTAL CONTACTS AT PRIOR START */
			$sql = $wpdb->prepare("SELECT count(ID) as customers FROM " . $contactsTable . " WHERE zbsc_created <= %s", $previous);
			$total_previous_prior_cus = $wpdb->get_row($sql);

			if ( $total_current_cus->customers < 0 ) {
				$AVPU_end = $total_current->gross_total_current / $total_current_cus->customers;
			} else {
				$AVPU_end = 0;
			}
			if ( $total_previous_cus->customers < 0 ) {
				$AVPU_start = $total_previous->gross_total_previous / $total_previous_cus->customers;
			} else {
				$AVPU_start = 0;
			}

			//ARPU change
			$change = zeroBSCRM_calculate_change($AVPU_end, $AVPU_start);
			$res['ave_type'] = $change['type'];
			$res['ave_change'] = $change['perc'];


			$res['avrpu_current']                   = zeroBSCRM_formatCurrency($AVPU_end);
			$res['avrpu_previous']                  = zeroBSCRM_formatCurrency($AVPU_start);

			$res['customers_current']               = $total_current_cus->customers;
			$res['customers_previous']              = $total_previous_cus->customers;


			$change = zeroBSCRM_calculate_change($total_current_cus->customers, $total_previous_cus->customers);
			$res['cust_type_tot'] = $change['type'];
			$res['cust_perc_tot'] = $change['perc'];


			$res['customers_prior']                 = $total_previous_prior_cus->customers;

			$res['customers_added_current']         = $total_current_cus->customers - $total_previous_cus->customers;
			$res['customers_added_previous']        = $total_previous_cus->customers - $total_previous_prior_cus->customers;


			$change = zeroBSCRM_calculate_change($res['customers_added_current'], $res['customers_added_previous']);
			$res['cust_type'] = $change['type'];
			$res['cust_perc'] = $change['perc'];

    return $res;

}


#} re-write of sales dashboard (main view)...running from new DB structure.
#} MODIFY FUNCTIONS FOR TRANSITION PERIOD..
add_action( 'wp_ajax_zero_bs_sales_refresh', 'zeroBSCRM_salesDashboard' );
function zeroBSCRM_salesDashboard(){
    global $zbs, $wpdb;

    //tables
    global $ZBSCRM_t;
    $contactsTable      = $ZBSCRM_t['contacts'];
    $transactionsTable  = $ZBSCRM_t['transactions'];   


    $this_start     =   $_POST['s'];
    $this_end       =   $_POST['e'];
    $that_start     =   $_POST['ps'];

    $zbs_days       =   (int)$_POST['d'];

    $zbs_days = (int)$_POST['d'];
    //steps for the days... 
    $zbs_steps = 60*60*24;



    //store in variables
    $zeroBSCRMdash['start']     = strtotime($_POST['s']);

    //need to push this to the end of the day since it will time stamp to the start of the day
    $zeroBSCRMdash['end'] = date_create( $_POST['e'] )->setTime( 23, 59, 59 )->getTimestamp();

    
    
    
    $zeroBSCRMdash['previous']  = strtotime($_POST['ps']);

    //days to draw over
    $zeroBSCRMdash['days']      =  $_POST['d'];

		$res = array();
    $res = zeroBSCRM_salesdash_totals($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end'], $zeroBSCRMdash['previous']);


    //pass each of the charts through their own function with comments about what they are returning...
    //feeds into this section of the JS
    /*
        GrossChart(res.d3js, res.minx, res.maxx, res.max_this);
    */
    $res = zeroBSCRM_gross_revenue_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);
    $res = zeroBSCRM_net_revenue_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);
    $res = zeroBSCRM_discount_revenue_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);
    $res = zeroBSCRM_fee_revenue_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);

    //new charts (refunds and failed)
    $res = zeroBSCRM_refund_revenue_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);
    $res = zeroBSCRM_failed_revenue_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);

    //contacts charts
    $res = zeroBSCRM_new_contacts_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);
    
    echo json_encode($res);
    die();

}



function zeroBSCRM_gross_revenue_chart_newDB($res, $start, $end){
    global $zbs, $wpdb;
    global $ZBSCRM_t;

		$transactionsTable  = $ZBSCRM_t['transactions'];
		$variables = "zbst_total as sale, zbst_created as year";

		$extraWhere = " AND zbst_status <> 'refunded' AND zbst_status <> 'failed'";
		$extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);

		$sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $transactionsTable . " WHERE zbst_date <= %s AND zbst_date >= %s" . $extraWhere, $end, $start);

		$data = $wpdb->get_results($sql);

		//calculate max
		$max = 0;
		foreach($data as $d){
				if($d->sale > $max){
						$max = $d->sale;
				}
		}

		$filled_zeros = array();
		$filled_zeros = zeroBSCRM_populate_data_array($data, $start, $end);

		$running_count = 0;

		//init these arrays..
		$total_data = array();
		$new_data = array();
		$processed_data         = zeroBSCRM_process_filled_zeros($filled_zeros, $running_count);
		$new_data               = $processed_data['new_data'];
		$total_data             = $processed_data['total_data'];

		$max                    = $processed_data['total_max'];

		//make cumulative



		$res['d3js']        = $total_data;
		$res['minx']        = $start;
		$res['maxx']        = $end;
		$res['max_this']    = $max;

    return $res;
}

function zeroBSCRM_net_revenue_chart_newDB($res, $start, $end){
    global $zbs, $wpdb;
    global $ZBSCRM_t;

    $transactionsTable  = $ZBSCRM_t['transactions'];
    $variables = "zbst_net as sale, zbst_created as year";

    $extraWhere = " AND zbst_status <> 'refunded' AND zbst_status <> 'failed'";
    $extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);

    $sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $extraWhere, $end, $start);
    $data = $wpdb->get_results($sql);

    //calculate max
    $max = 0;
    foreach($data as $d){
        if($d->sale > $max){
            $max = $d->sale;
        }
    }

    $filled_zeros = array();
    $filled_zeros = zeroBSCRM_populate_data_array($data, $start, $end);

    //init these arrays..
    $total_data = array();
    $new_data = array();
		$running_count = 0;
    $processed_data         = zeroBSCRM_process_filled_zeros($filled_zeros, $running_count);
    $new_data               = $processed_data['new_data'];
    $total_data             = $processed_data['total_data'];

    $max                    = $processed_data['the_max'];


    $res['d3jsnet'] = $new_data;
    $res['minx'] = $start;
    $res['maxx'] = $end;
    $res['net_max'] = $max;

    return $res;
}

function zeroBSCRM_discount_revenue_chart_newDB($res, $start, $end){
    global $zbs, $wpdb;
    global $ZBSCRM_t;

    $transactionsTable  = $ZBSCRM_t['transactions'];
    $variables = "zbst_discount as sale, zbst_created as year";

    $extraWhere = " AND zbst_status <> 'refunded' AND zbst_status <> 'failed'";
    $extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);

    $sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $extraWhere, $end, $start);
    $data = $wpdb->get_results($sql);

    //calculate max
    $max = 0;
    foreach($data as $d){
        if($d->sale > $max){
            $max = $d->sale;
        }
    }

    $filled_zeros = array();
    $filled_zeros = zeroBSCRM_populate_data_array($data, $start, $end);

    //init these arrays..
    $total_data = array();
    $new_data = array();
		$running_count = 0;
    $processed_data         = zeroBSCRM_process_filled_zeros($filled_zeros, $running_count);
    $new_data               = $processed_data['new_data'];
    $total_data             = $processed_data['total_data'];

    $max                    = $processed_data['the_max'];


    $res['d3jsdis'] = $new_data;
    $res['minx'] = $start;
    $res['maxx'] = $end;
    $res['disc_max'] = $max;

    return $res;
}

function zeroBSCRM_fee_revenue_chart_newDB($res, $start, $end){
    global $zbs, $wpdb;
    global $ZBSCRM_t;

    $transactionsTable  = $ZBSCRM_t['transactions'];
    $variables = "zbst_fee as sale, zbst_created as year";

    $extraWhere = " AND zbst_status <> 'refunded' AND zbst_status <> 'failed'";
    $extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);

    $sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $extraWhere, $end, $start);
    $data = $wpdb->get_results($sql);

    //calculate max
    $max = 0;
    foreach($data as $d){
        if($d->sale > $max){
            $max = $d->sale;
        }
    }

    $filled_zeros = array();
    $filled_zeros = zeroBSCRM_populate_data_array($data, $start, $end);

    //init these arrays..
    $total_data = array();
    $new_data = array();
		$running_count = 0;
    $processed_data         = zeroBSCRM_process_filled_zeros($filled_zeros, $running_count);
    $new_data               = $processed_data['new_data'];
    $total_data             = $processed_data['total_data'];

    $max                    = $processed_data['the_max'];


    $res['d3jsfee'] = $new_data;
    $res['minx'] = $start;
    $res['maxx'] = $end;
    $res['fee_max'] = $max;

    return $res;
}

function zeroBSCRM_refund_revenue_chart_newDB($res, $start, $end){
    global $zbs, $wpdb;
    global $ZBSCRM_t;

    $transactionsTable  = $ZBSCRM_t['transactions'];
    $variables = "zbst_total as sale, zbst_created as year";

    $extraWhere = " AND zbst_status = 'refunded'";
    $extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);

    $sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $extraWhere, $end, $start);
    $data = $wpdb->get_results($sql);

    //calculate max
    $max = 0;
    foreach($data as $d){
        if($d->sale > $max){
            $max = $d->sale;
        }
    }

    $filled_zeros = array();
    $filled_zeros = zeroBSCRM_populate_data_array($data, $start, $end);

    //init these arrays..
    $total_data = array();
    $new_data = array();
		$running_count = 0;
    $processed_data         = zeroBSCRM_process_filled_zeros($filled_zeros, $running_count);
    $new_data               = $processed_data['new_data'];
    $total_data             = $processed_data['total_data'];

    $max                    = $processed_data['the_max'];


    $res['d3jsref'] = $new_data;
    $res['minx'] = $start;
    $res['maxx'] = $end;
    $res['ref_max'] = $max;

    return $res;
}

function zeroBSCRM_failed_revenue_chart_newDB($res, $start, $end){
    global $zbs, $wpdb;
    global $ZBSCRM_t;

    $transactionsTable  = $ZBSCRM_t['transactions'];
    $variables = "zbst_total as sale, zbst_created as year";

    $extraWhere = " AND zbst_status = 'failed'";
    $extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);

    $sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $transactionsTable . " WHERE zbst_created <= %s AND zbst_created >= %s" . $extraWhere, $end, $start);
    $data = $wpdb->get_results($sql);

    //calculate max
    $max = 0;
    foreach($data as $d){
        if($d->sale > $max){
            $max = $d->sale;
        }
    }

    $filled_zeros = array();
    $filled_zeros = zeroBSCRM_populate_data_array($data, $start, $end);

    //init these arrays..
    $total_data = array();
    $new_data = array();
		$running_count = 0;
    $processed_data         = zeroBSCRM_process_filled_zeros($filled_zeros, $running_count);
    $new_data               = $processed_data['new_data'];
    $total_data             = $processed_data['total_data'];

    $max                    = $processed_data['the_max'];


    $res['d3jsfail'] = $new_data;
    $res['minx'] = $start;
    $res['maxx'] = $end;
    $res['fail_max'] = $max;

    return $res;
}
//new contacts chart
function zeroBSCRM_new_contacts_chart_newDB($res, $start, $end){
    global $zbs, $wpdb;
    global $ZBSCRM_t;
    $contactsTable  = $ZBSCRM_t['contacts'];
    $variables = "count(ID) as sale, zbsc_created as year";

    $extraWhere = "";
    $extraWhere = apply_filters('zbs-sales-dashboard-exclude-status', $extraWhere);

    $sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $contactsTable . " WHERE zbsc_created <= %s AND zbsc_created >= %s GROUP BY ID ORDER BY zbsc_created ASC" . $extraWhere, $end, $start);
    $data = $wpdb->get_results($sql);


    $variables = "count(ID) as total_start";

    $sql = $wpdb->prepare("SELECT ". $variables ." FROM " . $contactsTable . " WHERE zbsc_created <= %s" . $extraWhere, $start);
    $customers_at_start = (int)$wpdb->get_var($sql);  

    //calculate max
    $max = 0;
    $total_period = 0;
    $total_data = array();
    $running_count = $customers_at_start;
    
    $zbs_steps = 60*60*24;
    $start_midnight = $start;

    $filled_zeros = array();
    $filled_zeros = zeroBSCRM_populate_data_array($data, $start, $end);

    //init these arrays..
    $total_data = array();
    $new_data = array();
    $processed_data         = zeroBSCRM_process_filled_zeros($filled_zeros, $running_count);
    $new_data               = $processed_data['new_data'];
    $total_data             = $processed_data['total_data'];

    $res['d3total']         = $total_data;
    $res['total_at_start']  = $customers_at_start;
    $res['total_at_end']    = $processed_data['total_max'];

    $res['d3users']         = $new_data;
    $res['minx']            = $start;
    $res['maxx']            = $end;

    $res['max_customers']   = $processed_data['the_max'];

    return $res;
}


function zeroBSCRM_populate_data_array($data, $start, $end, $zbs_steps = 86400){


    $start_month = strtotime( 'first day of ' . $start);

    $start_midnight = $start;

    $filled_zeros = array();
    $the_day = $start;

    while($the_day <= $end){
        $filled_zeros[$the_day] = 0;
        $the_day += $zbs_steps;
    }

    foreach($data as $d){
        $the_offset = $d->year % $zbs_steps;
        $d->year -= $the_offset;
        $filled_zeros[$d->year] += $d->sale;

    }


    return $filled_zeros;
}

function zeroBSCRM_process_filled_zeros($filled_zeros = array(), $running_count = 0){

    $total_period = 0;
		$max = 0;
    foreach($filled_zeros as $k => $v){
        $row['year']        = $k;
        $row['sale']        = $v;
        if($v > $max){
            $max = $v;
        }
        $total_row['year']  = $k;
        $total_row['sale']  = $running_count + $v;
        $running_count += $v;
        $new_data[]          = $row;
        $total_data[]        =   $total_row;

        $total_period += $v;
    }

    $res['new_data']    = $new_data;
    $res['total_data']  = $total_data;
    $res['total_max']   = $running_count;
    $res['the_max']     = $max;

    $res['total_period'] = $total_period;

    return $res;
}

if (!function_exists('write_log')) {
    function write_log ( $log )  {
   
            if ( is_array( $log ) || is_object( $log ) ) {
                error_log( print_r( $log, true ) );
            } else {
                error_log( $log );
            }
      
    }
}




#} Prepopulate sales array
function zbs_prepopulate_sales_array($zbstime){
    $zbsdate = date("Y-m-d", $zbstime);
    $zbsnow = date("Y-m-d", time());

    $zbs_first_year = date("Y", $zbstime);
    $zbs_first_month = date("m", $zbstime);

    $zbsmonths = 1;
    $zbs_our_month = $zbs_first_month;
    $zbs_our_year = $zbs_first_year;
    $gross_revenue = array();
    $barout = array();

    while($zbsmonths <= 12){
        if($zbs_our_month > 12){
            $zbs_our_year++;
            $zbs_our_month = 1;
            $first = mktime(0,0,0,$zbs_our_month,1,$zbs_our_year);
            $gross_revenue[$first] = 0;
        }else{
            $first = mktime(0,0,0,$zbs_our_month,1,$zbs_our_year);
            $gross_revenue[$first] = 0; //fill with 0s...
        }
        $zbsmonths++;
        $zbs_our_month++;
    }
    return $gross_revenue;
}

#} Gross Sales Single View
add_action( 'wp_ajax_zero_bs_gross_sales_refresh', 'zero_bs_gross_sales_refresh' );
function zero_bs_gross_sales_refresh(){
	//enqueues only on the Sales Dashboard Page..

	global $wpdb;

	//store in variables
	$zeroBSCRMdash['start']     = strtotime($_POST['s']);
	$zeroBSCRMdash['end']       = strtotime($_POST['e']);
	$zeroBSCRMdash['previous']  = strtotime($_POST['ps']);

	$res = array();
	$res = zeroBSCRM_salesdash_totals($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end'], $zeroBSCRMdash['previous']);
	$res = zeroBSCRM_gross_revenue_chart_newDB($res, $zeroBSCRMdash['start'], $zeroBSCRMdash['end']);

	echo json_encode($res);
	die();
}; 


function zeroBSCRM_populate_month_data_array($start, $end, $zbs_steps = 86400){


    $filled_zeros = array();
    $the_day = $start;

    while($the_day <= $end){
        $the_month = date("M y", $the_day);
        $filled_zeros[$the_month] = 0;
        $the_day += $zbs_steps;
    }

    return $filled_zeros;
}

function zeroBSCRM_is_first_transaction($meta = array()){
    //takes a transaction meta and checks whether it is the first transaction of that contact
    //ignores pending, failed, refunded

    $customerID = $meta['customer'];
    $all_trans = zeroBS_getTransactionsForCustomer($customerID,true,1000000,0,false);
    $first_tran = "yes";

    $all_trans = array_reverse($all_trans);

    $min_date = $meta['date'];

    $zbs_trans_stat = strtolower($tran['status']);
 
    foreach($all_trans as $tran){

        if($zbs_trans_stat != 'refunded' && $zbs_trans_stat != 'failed' && $zbs_trans_stat != 'pending'){        

            if(strtotime($tran['created']) < $meta['date']){
                $min_date = strtotime($tran['created']);
            }


        }
    }


    if($meta['date'] == $min_date){
        return 'yes';
    }else{
        return'no';
    }



}


function zeroBSCRM_historic_transaction_data($start=''){
    /*
    var data = [
    {month: "Q1-2016", apples: 3840, bananas: 1920, cherries: -1960, dates: -400},
    {month: "Q2-2016", apples: 1600, bananas: 1440, cherries: -960, dates: -400},
    {month: "Q3-2016", apples:  640, bananas:  960, cherries: -640, dates: -600},
    {month: "Q4-2016", apples:  320, bananas:  480, cherries: -640, dates: -400}
    ];
    */
    global $wpdb;
    $transaction_sql_DB1 = "SELECT * FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' ORDER BY post_date ASC";
    $transactions = $wpdb->get_results($transaction_sql_DB1);

    $end = time();

    $stripe_invoices = array();
    $new_customer_data = array();
    $data = array();

    foreach($transactions as $transaction){
        $meta = zeroBS_getTransactionMeta($transaction->ID);
        $zbs_trans_stat = strtolower($meta['status']);
        $created = strtotime($transaction->post_date);

     //   do it this way, then DEDUCT the failed and refunded.
        if($zbs_trans_stat != 'refunded' && $zbs_trans_stat != 'failed' && $zbs_trans_stat != 'pending'){
            if($created >= $start){

                $meta['date'] = $created;

                if(zeroBSCRM_is_first_transaction($meta) == "yes"){
                
                    //this split can be used to 
                    $new_customer_data[] = array(
                        'sale' => $meta['total'],
                        'year' => $created,
                        'month' => date("M y", $created)
                    );

                }else{

                    $existing_customer_data[] = array(
                        'sale' => $meta['total'],
                        'year' => $created,
                        'month' => date("M y", $created)
                    );

                }

            }
       }

        if($zbs_trans_stat == 'refunded'){
            if($created >= $start){
                $refund_data[] = array(
                    'sale' => $meta['total'],
                    'year' => $created,
                    'month' => date("M y", $created)
                );
            }
        }

        if($zbs_trans_stat == 'failed'){
            if($created >= $start){

            //get the Stripe Invoice Meta
            $stripe_invoice = get_post_meta($transaction->ID ,'zbs_transaction_extra_stripe_invoice', true);

            if($stripe_invoice != ''){
                //this will only build the failed_data once for Stripe Failures 
                //if the invoice meta is set, and it's already been accounted for.
                if(!in_array( $stripe_invoice, $stripe_invoices)){
                    $failed_data[] = array(
                        'sale' => $meta['total'],
                        'year' => $created,
                        'month' => date("M y", $created)
                    );
                    $stripe_invoices[] = $stripe_invoice;
                }

            }else{
                //stripe_invoice is not set.
                $failed_data[] = array(
                    'sale' => $meta['total'],
                    'year' => $created,
                    'month' => date("M y", $created)
                );
            }



            }
        }
    }



    $months = zeroBSCRM_populate_month_data_array($start, $end);

    $new_customer_processed_data = array();
    $existing_customer_processed_data = array();
    $refund_processed_data = array();
    $failed_processed_data = array();

    foreach($months as $month){
        $new_cust_processed_data[$month] = 0;
        $existing_customer_data[$month] = 0;
        $refund_data[$month] = 0;
        $failed_data[$month] = 0;
    }

    if(count($data) > 0){
        foreach($new_customer_data as $data){
            $new_cust_processed_data[$data['month']] += $data['sale'];
        }
     
        foreach($existing_customer_data as $data){
            $existing_customer_processed_data[$data['month']] += $data['sale'];
        }
    
        foreach($refund_data as $data){
            $refund_processed_data[$data['month']] -= $data['sale'];
        }

        foreach($failed_data as $data){
            $failed_processed_data[$data['month']] -= $data['sale'];
        }

    }


    //now fill them with 0s..
    $final_new_customer_data = array();
    $final_existing_customer_data = array();
    $final_refund_data = array();
    $final_failed_data = array();



    $i = 0;
    foreach($months as $k => $v){
        //new customers attributing for the revenue
        if(array_key_exists($k,$new_cust_processed_data)){
            $final_new_customer_data[$i] =  round($new_cust_processed_data[$k],2);
        }else{
            $final_new_customer_data[$i] = 0;
        }

        //exiting attributing
        if(array_key_exists($k,$existing_customer_processed_data)){
            $final_existing_customer_data[$i] =  $existing_customer_processed_data[$k];
        }else{
            $final_existing_customer_data[$i] = 0;
        }


        //refunds
        if(array_key_exists($k,$refund_processed_data)){
            $final_refund_data[$i] =  $refund_processed_data[$k];
        }else{
            $final_refund_data[$i] = 0;
        }

        //failed
        if(array_key_exists($k,$failed_processed_data)){
            $final_failed_data[$i] =  $failed_processed_data[$k];
        }else{
            $final_failed_data[$i] = 0;
        }

        $i++;
    }

    //now finally create the data needed for the chart.
    /*
                    var data = [
                    {month: "Q1-2016", apples: 3840, bananas: 1920, cherries: -1960, dates: -400},
                    {month: "Q2-2016", apples: 1600, bananas: 1440, cherries: -960, dates: -400},
                    {month: "Q3-2016", apples:  640, bananas:  960, cherries: -640, dates: -600},
                    {month: "Q4-2016", apples:  320, bananas:  480, cherries: -640, dates: -400}
                    ];

                    .keys(["new customers", "existing customers", "refund", "failed"])
    */

    
    $gross_chart_data = array();
    $i=0;
    foreach($months as $k => $v){
        $gross_chart_data[] = array(
            "month" => $k,
            "new customers" => $final_new_customer_data[$i],
            "existing customers" => $final_existing_customer_data[$i],
            "refund" => $final_refund_data[$i],
            "failed" => $final_failed_data[$i]

        );
        $i++;
    }

    $total_gross_revenue = array_sum($final_new_customer_data) + array_sum($final_existing_customer_data);

    $chart['data']  = $gross_chart_data;
    $chart['total'] = $total_gross_revenue;

    return $chart;



}

function zerobscrm_sales_gross(){
    global $wpdb,  $zbs, $zbs_curr, $zbs_salesdash_slugs;
    $zbs_curr = zeroBSCRM_getCurrencyChr(); 
    ?>

    <div id="zbs-admin-top-bar-sd">
        <div id="zbs-list-top-bar" class="ui stackable menu inverted">
            <div class='ui item' style='margin: 0px;padding: 0px;'>
                <h2 class="zbs-white"><span class="add-new-button"><?php _e("Gross Revenue","zerobscrm");?></span>
                <a href='?page=<?php echo $zbs_salesdash_slugs['sales-dash']; ?>' class='ui button blue tiny' style='margin-left:10px;'><?php _e('Back to Dashboard', 'zero-bs-crm'); ?></a>
                </h2>
            </div>
            <div class='menu right ui inverted' id="zbs-date-picker-background">
                <div class='month-selector'>
                    <div id="reportrange" class="pull-right" style="cursor: pointer; padding: 5px 10px; border: 1px solid #ccc;margin-top:-3px;">
                    <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                    <span></span> <b class="caret"></b>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class='container-fluid'>

        <?php
            $first_sql = "SELECT min(post_date) FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'zerobs_transaction'";
            $first_date = $wpdb->get_var($first_sql);
            $start = strtotime($first_date);

        

            $gross_chart_data = zeroBSCRM_historic_transaction_data($start);
            $chart_data = json_encode($gross_chart_data['data']);
        ?>
        <div class='sales-graph-wrappers gross-wrappers-old'>
            <div class='row'>
                <div class='col-md-5'>
                    <div class='graph-box gross_sales'>
                        <div class='title'><?php _e('Gross Revenue', 'zerobs'); ?><span class='cumul'>(<?php _e('cumulative','zero-bs-crm'); ?>)</span></div>
                        <div class='max_this'>
                            <span class='max_this_value'></span>
                            <br/>
                            <div class='prev_val'>
                                vs  <span class="max_prev_value"></span>
                            </div>
                        </div>
                        <div class='compare_this'>
                            <div class='which up'>
                                <div class='by'>tbc</div>
                                <div class='time-ago'>last month</div>
                            </div>
                        </div>
                        <svg id="gross" width="100%" height="125"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                    <br/>

                    <div class='graph-box gross_sales' style="padding:10px;">
                        <div class='title'><?php _e('Gross Revenue', 'zerobs'); ?><span class='cumul'>(<?php _e('cumulative','zero-bs-crm'); ?>)</span></div>
         
                        <table class='ui table striped'>
                            <thead>
                                <th>Month</th>
                                <th>New Customers</th>
                                <th>Existing Customers</th>
                                <th>Refund</th>
                                <th>Failed</th>
                            </thead>

                            <tbody>
                        
                            <?php 
                              //  zbs_prettyprint($gross_chart_data);
                                $table_data = $gross_chart_data['data'];
                                $table_data = array_reverse($table_data);
                                foreach($table_data as $row){

                                    echo "<tr>";
                                        echo "<td>" . $row['month'] . "</td>";
                                        echo "<td>" . zeroBSCRM_formatCurrency($row['new customers']) . "</td>";
                                        echo "<td>" . zeroBSCRM_formatCurrency($row['existing customers']) . "</td>";
                                        echo "<td>" . zeroBSCRM_formatCurrency($row['refund']) . "</td>";
                                        echo "<td>" . zeroBSCRM_formatCurrency($row['failed']) . "</td>";
                                    echo "</tr>";

                                }

                            ?>

                            </tbody>

                        </table>

                    </div>


            </div>



                    <style>

                    .axis text {
                    font: 10px sans-serif;
                    }

                    .axis line,
                    .axis path {
                    fill: none;
                    stroke: #000;
                    shape-rendering: crispEdges;
                    }

                    </style>
                <div class='col-md-7'>
                    <div class='graph-box history-box'>
                    <div class='title'><?php _e('Gross Revenue', 'zerobs'); ?><span class='cumul'>(<?php _e('All time','zero-bs-crm'); ?>)</span>
                    <h3 class='total-over-time'><?php echo zeroBSCRM_formatCurrency($gross_chart_data['total']); ?></h3>
                    </div>

                    <svg id="hist"  width="100%" height="500"></svg>
                    <style>
                        .main-wrap{
                            margin: auto;
                            text-align: center;
                            position: relative;
                            display: inline-block;
                            width: 100%;
                            margin-left: 61px;
                        }
                        .legend{
                            width: 100%;
                            margin: auto;
                            text-align: left;;
                            line-height: 8px;
                        }
                        .legend .lab{
                            width:10px;
                            height:10px;
                            float:left;
                            margin-right:5px;
                        }
                        .legend .wrap{
                            float:left;
                            margin-right:4%;
                            width:20%;
                        }
                        .legend .new_cust{
                            background: #2185D0;
                        }
                        .legend .renew_cust{
                            background: #21BA45;
                        }
                        .legend .refund{
                            background: #DB2828;
                        }
                        .legend .failed{
                            background: #991c1c;
                        }
                    </style>
                    <div class='main-wrap'>
                        <div class='legend'>
                            <div class='wrap'>
                            <div class='lab new_cust'></div><div><?php _e("New Customers","zero-bs-crm"); ?></div>
                            </div>
                            <div class='wrap'>
                            <div class='lab renew_cust'></div><div><?php _e("Existing Customers","zero-bs-crm"); ?></div>
                            </div>
                            <div class='wrap'>
                            <div class='lab refund'></div><div><?php _e("Refunded","zero-bs-crm"); ?></div>
                            </div>
                            <div class='wrap'>
                            <div class='lab failed'></div><div><?php _e("Failed Payment","zero-bs-crm"); ?></div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </div>

                    <script src="https://d3js.org/d3.v4.min.js"></script>
                    <script>
                    var data = <?php echo $chart_data; ?>

                    var series = d3.stack()
                        .keys(["new customers", "existing customers", "refund", "failed"])
                        .offset(d3.stackOffsetDiverging)
                        (data);

                    var svg = d3.select("#hist"),
                        margin = {top: 30, right: 30, bottom: 50, left: 60},
                        width = jQuery('#hist').width(),
                        height = +svg.attr("height");

                    var x = d3.scaleBand()
                        .domain(data.map(function(d) { return d.month; }))
                        .rangeRound([margin.left, width - margin.right])
                        .padding(0.1);

                    var y = d3.scaleLinear()
                        .domain([d3.min(series, stackMin), d3.max(series, stackMax)])
                        .rangeRound([height - margin.bottom, margin.top]);

                    //d3.schemeCategory20
                    var z = d3.scaleOrdinal()
                        .range(["#2185D0","#21BA45","#DB2828","#991c1c"]);

                    svg.append("g")
                    .selectAll("g")
                    .data(series)
                    .enter().append("g")
                        .attr("fill", function(d) { return z(d.key); })
                    .selectAll("rect")
                    .data(function(d) { return d; })
                    .enter().append("rect")
                        .attr("width", x.bandwidth)
                        .attr("x", function(d) { return x(d.data.month); })
                        .attr("y", function(d) { return y(d[1]); })
                        .attr("height", function(d) { return y(d[0]) - y(d[1]); })

                    svg.append("g")
                        .attr("transform", "translate(0," + y(0) + ")")
                        .attr("class", "axis")
                        .call(d3.axisBottom(x))
                        .selectAll("text")	
                            .style("text-anchor", "end")
                            .attr("dx", "-.8em")
                            .attr("dy", ".15em")
                            .attr("transform", "rotate(-70)");

                    
                    svg.append("g")
                        .attr("transform", "translate(" + margin.left + ",0)")
                        .call(d3.axisLeft(y));
                        

                    function stackMin(serie) {
                    return d3.min(serie, function(d) { return d[0]; });
                    }

                    function stackMax(serie) {
                    return d3.max(serie, function(d) { return d[1]; });
                    }

                    </script>


                    </div>
                </div>

            </div>
        </div>






    <?php 
};

#} Net Sales Single View
add_action( 'wp_ajax_zero_bs_net_sales_refresh', 'zero_bs_net_sales_refresh' );
function zero_bs_net_sales_refresh(){
    //enqueues only on the Sales Dashboard Page..
    global $wpdb;

    $zbs_days = (int)$_POST['d'];

    if($zbs_days > 100){
        $zbs_steps = 60*60*24*30;
    }else{
        $zbs_steps = 60*60*24;
    }

    $offset = 0;

    //quick hacky way for now..  can refine later to return AJAX
    $this_start = get_option('zbs_this_start');
    $this_end   = get_option('zbs_this_end');
    $that_start = get_option('zbs_this_prev_start');

    //move the above to run from the AJAX post... 
    $this_start     =   $_POST['s'];
    $this_end       =   $_POST['e'];
    $that_start     =   $_POST['ps'];

    //this_end we need to move to midnight that night
    $this_end = date('Y-m-d', strtotime('+1 day', strtotime($this_end)));

    //the end of that is the start of this..
    $that_end = $this_start;

    $r['start'] = $this_start;
    $r['end'] = $this_end;
    $r['prev'] = $that_start;


    #} Gross Sales...
    $grand_total = 0;
    $net_total = 0;
    $disc_tot = 0;
    $max_fee = 0;
    $fee_tot = 0;
    $max_disc = 0;
    $max_tax = 0;
    $max_day_gross = 0;

    //new summations
    $gross_total = 0;
    $net_total = 0;
    $discount_total = 0;
    $fee_total = 0;

    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date >= '$this_start' AND post_date < '$this_end' ORDER by post_date ASC";
    

    $res['query'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;

    $max_day_net = 0; //define this..
    $max_day_dis = 0; //define this..
    $max_day_fee = 0; //define this...
    $posts_times = array();
    $gross_revenue = array();


        foreach ($r as $post) {
            $offset = 0;
            $post_time = strtotime($post->post_date);
            $offset = $post_time % $zbs_steps;   //30 days offset
            $post_time -= $offset;
            $posts_times[$post_time] = 0;
            $order = get_post_meta($post->ID,'zbs_transaction_meta', true);

            $discount_cost[$post_time] = 0;
            $fee_cost[$post_time] = 0;

            #} Gross Revenue (Cumulative)
            $gross_total += $order['total'];
            $gross_revenue[$post_time] = $gross_total;     //start adding together rows that are the same day..
            $max_day_gross = max($max_day_gross, $gross_revenue[$post_time]);


            #} Net Revenue (Cumulative)
            if(!array_key_exists('net',$order)){
              $order['net'] = $order['total'];  //total will always exist...?
            }


            $net_total += $order['net'];
            $net_revenue[$post_time] = $net_total;
            $max_day_net = max($max_day_net, $net_revenue[$post_time]);


        }

        $keys = array_keys($posts_times);  //these are the keys (i.e. the days in the above)


        $d3gross2 = array();
        $j = 0;
        for($i = $keys[0]; $i <= $keys[(count($keys)-1)]; $i += $zbs_steps) {
            $gross['year']  =   $i;
            $net['year']    =   $i;


            #} the x-axis scalars
            if($j == 0){
              $min_grossrev_year = $i;
            }
            $max_grossrev_year = max($min_grossrev_year, $i);


            #} Gross Revenue (Cumulative) so need a 'flat-line' if no sales during a time-step
            if(!array_key_exists($i,$gross_revenue)){
              $gross['sale'] = $flat;    //allow for flat days...
            }else{
              $gross['sale'] = $gross_revenue[$i];
              $flat = $gross_revenue[$i]; 
            }
            
            #} Net Revenue (Cumulative) so need a 'flat-line' if no sales during a time-step
            if(!array_key_exists($i,$net_revenue)){
              $net['sale'] = $flat;    //allow for flat days...
            }else{
              $net['sale'] = $net_revenue[$i];
              $flat = $net_revenue[$i]; 
            }

            #} Discount and Fees (Non Cumulative) so slightly easier..
            if(array_key_exists($i,$discount_cost) && array_key_exists($i,$fee_cost)){
                $discount['sale'] = $discount_cost[$i];
                $fee['sale'] = $fee_cost[$i];
            }

            $d3gross2[] = $gross;
            $d3net2[] = $net;


            $j++;
        }



        
     
      

        $max_this = $gross_total;
        $max_net = $net_total;
        // $d3gross = $gross_data;

    
    $gross_total_p = 0;
    $net_total_p = 0;
    $discount_total_p = 0;
    $fee_total_p = 0;
    $ave_y__max_axis = 0;


    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date > '$that_start' AND post_date < '$that_end' ORDER by post_date ASC";


    $r = $wpdb->get_results($query);
        foreach($r as $v){
            $order = get_post_meta($v->ID,'zbs_transaction_meta', true);
            $gross_total_p = $gross_total_p + $order['total'];
            if(!array_key_exists('net',$order)){
                $order['net'] = $order['total'];
            }
            $net_total_p = $net_total_p + $order['net'];
        }



        if($gross_total >= $gross_total_p){
            //this time is more than last time so it's an increase
            $perc = round( (($gross_total / $gross_total_p) - 1) * 100, 1);
            $type = 'up';
        }else{
            //last time more than this time so it's a decrease
            $perc = round( (($gross_total_p / $gross_total ) - 1) * 100, 1);
            $type = 'down';
        }

        if($net_total >= $net_total_p){
            //this time is more than last time so it's an increase
            $netperc = round( (($net_total / $net_total_p) - 1) * 100, 1);
            $nettype = 'up';
        }else{
            //last time more than this time so it's a decrease
            $netperc = round( (($net_total_p / $net_total ) - 1) * 100, 1);
            $nettype = 'down';
        }

    $zbstime = strtotime("first day of next month -1 year", time());
    $zbsdate = date("Y-m-d", $zbstime);
    $zbsnow = date("Y-m-d", time());

    $zbs_first_year = date("Y", $zbstime);
    $zbs_first_month = date("m", $zbstime);

    $zbsmonths = 1;
    $zbs_our_month = $zbs_first_month;
    $zbs_our_year = $zbs_first_year;

    $gross_revenue = array();
    $barout = array();

    $gross_revenue = zbs_prepopulate_sales_array($zbstime);   

    #} query the transactions over the past year and group by $order['total'] matched by months..
    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date >= '$zbsdate' AND post_date <= '$zbsnow' ORDER by post_date ASC";
    $res['query2'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;

    $posts_times = array();


        foreach ($r as $post) {
            $offset = 0;
            $first = mktime(0,0,0,$post->m,1,$post->y);
            $order = get_post_meta($post->ID,'zbs_transaction_meta', true);

            #} Net Revenue (Cumulative)
            if(!array_key_exists('net',$order)){
                $order['net'] = $order['total'];
            }
            $gross_total = $order['net'];
            $gross_revenue[$first] += $gross_total;     //start adding together rows that are the same day..

        }

        
        foreach($gross_revenue as $key => $value){
            $bar['year'] = $key;
            $bar['sale'] = $value;
            $barnf['year'] = $key;
            $barnf['sale'] = number_format($value,0);
            $barout[] = $bar;
            $baroutnf[] = $barnf;
        }




            $res['wout']                  =   $barout;
            $res['woutnf']                =   $baroutnf;
            $res['pts']                   =   $first;    
            $res['d3js']                  =   $d3gross2;
            $res['d3jsnet']               =   $d3net2;
            $res['max_this']              =   round($max_day_gross);
            $res['net_max']               =   round($max_day_net);             
            $res['max_this_nf']           =   number_format(round($max_day_gross));
            $res['net_max_nf']            =   number_format(round($max_day_net));
            $res['type']                  =   $type;
            $res['change']                =   $perc;
            $res['nettype']               =   $nettype;
            $res['netchange']             =   $netperc;
            $res['minx']                  =   $min_grossrev_year;
            $res['maxx']                  =   $max_grossrev_year;
            $res['fee_tot']               =   number_format($fee_tot,0);
            $res['fee_max']               =   round($max_day_fee);
            $res['this_start']            =   $this_start;
            $res['this_end']              =   $this_end;
            $res['gross_total_p']         =   number_format($gross_total_p,0);
            $res['net_total_p']           =   number_format($net_total_p,0);

        
        echo json_encode($res);
        die();
}; 
function zerobscrm_sales_net(){
    global $wpdb,  $zbs, $zbs_curr;
    $query = "SELECT post_date, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date > '2013-01-01' GROUP by YEAR(post_date), MONTH(post_date)  ORDER by post_date DESC";
    $r = $wpdb->get_results($query);
      $zbs_curr = zeroBSCRM_getCurrencyChr();
  ?>
    <div class='sales-overview container-fluid'>
      <div class='col-md-6'>
            <h3><?php _e('Net Revenue','zerobs'); ?></h3>
      </div>
      <div class='month-selector'>
        <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
            <span></span> <b class="caret"></b>
        </div>
      </div>
    </div>
    <div class='container-fluid'>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales' style='height:437px'>
                          <div class='max_this'> <span class='max_this_value'></span></div>
                          <div class='compare_this'>
                              <div class='which up'>
                                  <div class='by'>tbc</div>
                                  <div class='time-ago'>last month</div>
                              </div>
                          </div>
                        <svg id="gross" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row sales-look'>
                <div class='graph-box gross_sales status'>
                    <div class='col-md-3'>
                        <h4>Current Month</h4>
                        <div class='rev'> <span class='wout-0'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Month</h4>
                        <div class='rev'> <span class='wout-1'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Three Months Ago</h4>
                        <div class='rev'> <span class='wout-4'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Year</h4>
                        <div class='rev'> <span class='wout-12'></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales cust' style='height:437px'>
                     <div class='attr'><?php _e('Net sales over time','zerobs'); ?></div>
                        <svg id="stacker" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
};

#} Discounts - trimmed
add_action( 'wp_ajax_zero_bs_discount_sales_refresh', 'zero_bs_discount_sales_refresh' );
function zero_bs_discount_sales_refresh(){
    //enqueues only on the Sales Dashboard Page..
    global $wpdb;

    $zbs_days = (int)$_POST['d'];

    if($zbs_days > 100){
        $zbs_steps = 60*60*24*30;
    }else{
        $zbs_steps = 60*60*24;
    }

    $offset = 0;
    //move the above to run from the AJAX post... 
    $this_start     =   $_POST['s'];
    $this_end       =   $_POST['e'];
    $that_start     =   $_POST['ps'];

    //this_end we need to move to midnight that night
    $this_end = date('Y-m-d', strtotime('+1 day', strtotime($this_end)));

    //the end of that is the start of this..
    $that_end = $this_start;

    $r['start'] = $this_start;
    $r['end'] = $this_end;
    $r['prev'] = $that_start;


    #} Gross Sales...
    $disc_tot = 0;
    $max_disc = 0;
    $max_tax = 0;
    $max_day_gross = 0;
    $discount_total = 0;


    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date >= '$this_start' AND post_date < '$this_end' ORDER by post_date ASC";
    

    $res['query'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;

    $posts_times = array();
    $gross_revenue = array();
    $discount_cost = array();
    $max_day_dis = 0;

        foreach ($r as $post) {
            $offset = 0;
            $post_time = strtotime($post->post_date);
            $offset = $post_time % $zbs_steps;   //30 days offset
            $post_time -= $offset;
            $posts_times[$post_time] = 0;
            $order = get_post_meta($post->ID,'zbs_transaction_meta', true);

            if(!array_key_exists('discount',$order)){
              $order['discount'] = 0;
            }else if($order['discount'] < 0){
              $order['discount'] = 0;
            }

            $discount_total += $order['discount'];
            if(!array_key_exists($post_time, $discount_cost)){
                $discount_cost[$post_time] = $order['discount'];
            }else{
                $discount_cost[$post_time] += $order['discount'];  
            }
            $max_day_dis = max($max_day_dis, $discount_cost[$post_time]);
        }

        $keys = array_keys($posts_times);  //these are the keys (i.e. the days in the above)


        $d3gross2 = array();
        $j = 0;
        for($i = $keys[0]; $i <= $keys[(count($keys)-1)]; $i += $zbs_steps) {
            $discount['year'] = $i;
       
            if($j == 0){
              $min_grossrev_year = $i;
            }
            $max_grossrev_year = max($min_grossrev_year, $i);

            #} Discount and Fees (Non Cumulative) so slightly easier..
            if(array_key_exists($i,$discount_cost) && array_key_exists('sale',$discount)){
                $discount['sale'] = $discount_cost[$i];
            }else{
                $discount['sale'] = 0;
            }
          

            $d3dis2[] = $discount;
            $j++;
        }

        $grand_total = 0;

        
        foreach($r as $v){
            $order = get_post_meta($v->ID,'zbs_transaction_meta', true);
            $grand_total = $grand_total + $order['total'];
            $row['sale'] = $grand_total;
            $row['year'] = strval(strtotime($v->post_date));
            $gross_data[] = $row; 
        

            if(!array_key_exists('discount',$order)){
              $order['discount'] = 0;
            }else if($order['discount'] < 0){
              $order['discount'] = 0;
            }

             $max_disc = max($max_disc, $order['discount']);

            $disc_tot += $order['discount'];
            $row['sale'] = $order['discount'];
            $discount_data[] = $row;

            $max_xaxis = $row['year'];
            if($i == 0){
                $min_xaxis = $row['year'];
            }
            $i++;
        }


    $discount_total_p = 0;



    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date > '$that_start' AND post_date < '$that_end' ORDER by post_date ASC";


    $r = $wpdb->get_results($query);
        foreach($r as $v){
            $order = get_post_meta($v->ID,'zbs_transaction_meta', true);

            if(!array_key_exists('discount',$order)){
              $order['discount'] = 0;
            }else if($order['discount'] < 0){
              $order['discount'] = 0;
            }

            $discount_total_p = $discount_total_p + $order['discount'];

        }


        if($discount_total >= $discount_total_p){
            //this time is more than last time so it's an increase
            if($discount_total_p == 0){
                $disperc = 100;
            }else{
                $disperc = round( (($discount_total / $discount_total_p) - 1) * 100, 1);
            }
            $distype = 'up';
        }else{
            //last time more than this time so it's a decrease
            $disperc = round( (($discount_total_p / $discount_total ) - 1) * 100, 1);
            $distype = 'down';
        }


 

    $zbstime = strtotime("first day of next month -1 year", time());
    $zbsdate = date("Y-m-d", $zbstime);
    $zbsnow = date("Y-m-d", time());

    $zbs_first_year = date("Y", $zbstime);
    $zbs_first_month = date("m", $zbstime);

    $zbsmonths = 1;
    $zbs_our_month = $zbs_first_month;
    $zbs_our_year = $zbs_first_year;

    $gross_revenue = array();
    $barout = array();

    $gross_revenue = zbs_prepopulate_sales_array($zbstime);  

    

    #} query the transactions over the past year and group by $order['total'] matched by months..
    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date >= '$zbsdate' AND post_date <= '$zbsnow' ORDER by post_date ASC";
    $res['query2'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;

    $posts_times = array();



        foreach ($r as $post) {
            $offset = 0;
            $first = mktime(0,0,0,$post->m,1,$post->y);
            $order = get_post_meta($post->ID,'zbs_transaction_meta', true);


            #} Discounts (Non-cumulative)
            if(!array_key_exists('discount',$order)){
              $order['discount'] = 0;
            }else if($order['discount'] < 0){
              $order['discount'] = 0;
            }

            $gross_total = $order['discount'];
            #} Gross Revenue (Cumulative)
            $gross_revenue[$first] += $gross_total;     //start adding together rows that are the same day..



            $discount_total += $order['discount'];
            $discount_cost[$post_time] += $order['discount'];
        }

        $barout = array();
        foreach($gross_revenue as $key => $value){
            $bar['year'] = $key;
            $bar['sale'] = $value;
            $barnf['year'] = $key;
            $barnf['sale'] = number_format($value,0);
            $barout[] = $bar;
            $baroutnf[] = $barnf;
        }



            $res['wout']                  =   $barout;
            $res['woutnf']                =   $baroutnf;
            $res['d3jsdis']               =   $d3dis2;
            $res['max_tax']               =   $max_tax;
            $res['max_this']              =   round($max_day_gross);
            $res['distype']               =   $distype;
            $res['dischange']             =   $disperc;
            $res['minx']                  =   $min_grossrev_year;
            $res['maxx']                  =   $max_grossrev_year;
            $res['disc_tot']              =   number_format($disc_tot,0);
            $res['disc_max']              =   round($max_day_dis);
            $res['disc_total_p']          =   number_format($discount_total_p,0);
      
        echo json_encode($res);
        die();
}; 
function zerobscrm_sales_discount(){
    global $wpdb,  $zbs;
    $zbs_curr = zeroBSCRM_getCurrencyChr();

  ?>
    <div class='sales-overview container-fluid'>
      <div class='col-md-6'>
            <h3><?php _e('Discounts','zerobs'); ?></h3>
      </div>
      <div class='month-selector'>
        <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
            <span></span> <b class="caret"></b>
        </div>
      </div>
    </div>
    <div class='container-fluid'>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales' style='height:437px'>
                          <div class='max_this'> <span class='max_this_value'></span></div>
                          <div class='compare_this'>
                              <div class='which up'>
                                  <div class='by'>tbc</div>
                                  <div class='time-ago'>last month</div>
                              </div>
                          </div>
                        <svg id="gross" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row sales-look'>
                <div class='graph-box gross_sales status'>
                    <div class='col-md-3'>
                        <h4>Current Month</h4>
                        <div class='rev'> <span class='wout-0'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Month</h4>
                        <div class='rev'> <span class='wout-1'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Three Months Ago</h4>
                        <div class='rev'> <span class='wout-4'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Year</h4>
                        <div class='rev'> <span class='wout-12'></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales cust' style='height:437px'>
                     <div class='attr'><?php _e('Discounts over time','zerobs'); ?></div>
                        <svg id="stacker" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
};

#} Fees - trimmed
add_action( 'wp_ajax_zero_bs_fee_sales_refresh', 'zero_bs_fee_sales_refresh' );
function zero_bs_fee_sales_refresh(){
    //enqueues only on the Sales Dashboard Page..
    global $wpdb;

    $zbs_days = (int)$_POST['d'];

    if($zbs_days > 100){
        $zbs_steps = 60*60*24*30;
    }else{
        $zbs_steps = 60*60*24;
    }

    $offset = 0;

    //quick hacky way for now..  can refine later to return AJAX
    $this_start = get_option('zbs_this_start');
    $this_end   = get_option('zbs_this_end');
    $that_start = get_option('zbs_this_prev_start');

    //move the above to run from the AJAX post... 
    $this_start     =   $_POST['s'];
    $this_end       =   $_POST['e'];
    $that_start     =   $_POST['ps'];

    //this_end we need to move to midnight that night
    $this_end = date('Y-m-d', strtotime('+1 day', strtotime($this_end)));

    //the end of that is the start of this..
    $that_end = $this_start;

    $r['start'] = $this_start;
    $r['end'] = $this_end;
    $r['prev'] = $that_start;


    #} Gross Sales...
    $grand_total = 0;
    $max_fee = 0;
    $fee_tot = 0;
    $max_day_gross = 0;
    $fee_total = 0;

    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date >= '$this_start' AND post_date < '$this_end' ORDER by post_date ASC";
    

    $res['query'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;
    $max_day_fee = 0;
    $min_grossrev_year = 0;
    $max_grossrev_year = 0;

    $posts_times = array();
    $gross_revenue = array();

        foreach ($r as $post) {
            $offset = 0;
            $post_time = strtotime($post->post_date);
            $offset = $post_time % $zbs_steps;   //30 days offset
            $post_time -= $offset;
            $posts_times[$post_time] = 0;
            $order = get_post_meta($post->ID,'zbs_transaction_meta', true);
            if(array_key_exists('fee',$order)){
                $afee = ltrim($order['fee'], '-');
            }else{
                $afee = 0;
            }
            $fee_total += $afee;
            $fee_cost[$post_time] = $fee_total;
            $max_day_fee = max($max_day_fee, $fee_cost[$post_time]);

        }

        $keys = array_keys($posts_times);  //these are the keys (i.e. the days in the above)


        $d3gross2 = array();
        $j = 0;
        for($i = $keys[0]; $i <= $keys[(count($keys)-1)]; $i += $zbs_steps) {
            $fee['year']      = $i;

            #} the x-axis scalars
            if($j == 0){
              $min_grossrev_year = $i;
            }
            $max_grossrev_year = max($min_grossrev_year, $i);
            if(array_key_exists($i,$fee_cost)){
                $fee['sale'] = $fee_cost[$i];
            }
            $d3fee2[] = $fee;

            $j++;
        }



        
        foreach($r as $v){
            $order = get_post_meta($v->ID,'zbs_transaction_meta', true);
            $grand_total = $grand_total + $order['total'];
            $row['sale'] = $grand_total;
            $row['year'] = strval(strtotime($v->post_date));
            $gross_data[] = $row; 
        

            if(!array_key_exists('fee',$order)){
              $order['fee'] = 0;
            }
            $max_fee = max($max_fee, ltrim($order['fee'], '-'));

            $fee_tot += ltrim($order['fee'], '-');
            $row['sale'] = ltrim($order['fee'], '-');
            $fee_data[] = $row;


            $max_xaxis = $row['year'];
            if($i == 0){
                $min_xaxis = $row['year'];
            }
            $i++;
        }


        $d3fee = $fee_data;
        $fee_total_p = 0;
        $ave_y__max_axis = 0;


    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date > '$that_start' AND post_date < '$that_end' ORDER by post_date ASC";


    $r = $wpdb->get_results($query);
        foreach($r as $v){
            $order = get_post_meta($v->ID,'zbs_transaction_meta', true);
            if(array_key_exists('fee',$order)){
                $afee = ltrim($order['fee'], '-');
            }else{
                $afee = 0;
            }
            $fee_total_p += $afee;
        }

        if($fee_total ==  0 || $fee_total_p == 0){
            $feeperc = 0;
        }else{
            if($fee_total >= $fee_total_p){
                //this time is more than last time so it's an increase
                $feeperc = round( (($fee_total / $fee_total_p) - 1) * 100, 1);
                $feetype = 'up';
            }else{
                //last time more than this time so it's a decrease
                $feeperc = round( (($fee_total_p / $fee_total ) - 1) * 100, 1);
                $feetype = 'down';
            }
        }

    $zbstime = strtotime("first day of next month -1 year", time());
    $zbsdate = date("Y-m-d", $zbstime);
    $zbsnow = date("Y-m-d", time());

    $zbs_first_year = date("Y", $zbstime);
    $zbs_first_month = date("m", $zbstime);

    $zbsmonths = 1;
    $zbs_our_month = $zbs_first_month;
    $zbs_our_year = $zbs_first_year;

    $gross_revenue = array();
    $barout = array();

    $gross_revenue = zbs_prepopulate_sales_array($zbstime);  

    

    #} query the transactions over the past year and group by $order['total'] matched by months..
    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date >= '$zbsdate' AND post_date <= '$zbsnow' ORDER by post_date ASC";
    $res['query2'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;

    $posts_times = array();


        foreach ($r as $post) {
            $offset = 0;
            $first = mktime(0,0,0,$post->m,1,$post->y);
            $order = get_post_meta($post->ID,'zbs_transaction_meta', true);
            #} Fees (Non-cumulative)
            if(!array_key_exists('fee',$order)){
              $order['fee'] = 0;
            }else{
                $order['fee'] = ltrim($order['fee'], '-');
            }

            $gross_total = $order['fee'];
            #} Gross Revenue (Cumulative)
            $gross_revenue[$first] += $gross_total;     //start adding together rows that are the same day..


            $afee = ltrim($order['fee'], '-');
            $fee_total += $afee;
            $fee_cost[$post_time] += $afee;

        }

        $barout = array();
        foreach($gross_revenue as $key => $value){
            $bar['year'] = $key;
            $bar['sale'] = $value;
            $barnf['year'] = $key;
            $barnf['sale'] = number_format($value,0);
            $barout[] = $bar;
            $baroutnf[] = $barnf;
        }



            $res['wout']                  =   $barout;
            $res['woutnf']                =   $baroutnf;
            $res['d3jsfee']               =   $d3fee2;    
            $res['max_this']              =   round($max_day_gross);
            $res['minx']                  =   $min_grossrev_year;
            $res['maxx']                  =   $max_grossrev_year;        
            $res['fee_tot']               =   number_format($fee_tot,0);
            $res['fee_max']               =   round($max_day_fee);    
            $res['fee_total_p']           =   number_format($fee_total_p,0);
    
        
        echo json_encode($res);
        die();
}; 
function zerobscrm_sales_fee(){
    global $wpdb,  $zbs;
    $zbs_curr = zeroBSCRM_getCurrencyChr();

  ?>
    <div class='sales-overview container-fluid'>
      <div class='col-md-6'>
            <h3><?php _e('Fees','zerobs'); ?></h3>
      </div>
      <div class='month-selector'>
        <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
            <span></span> <b class="caret"></b>
        </div>
      </div>
    </div>
    <div class='container-fluid'>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales' style='height:437px'>
                          <div class='max_this'> <span class='max_this_value'></span></div>
                          <div class='compare_this'>
                              <div class='which up'>
                                  <div class='by'>tbc</div>
                                  <div class='time-ago'>last month</div>
                              </div>
                          </div>
                        <svg id="gross" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row sales-look'>
                <div class='graph-box gross_sales status'>
                    <div class='col-md-3'>
                        <h4>Current Month</h4>
                        <div class='rev'> <span class='wout-0'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Month</h4>
                        <div class='rev'> <span class='wout-1'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Three Months Ago</h4>
                        <div class='rev'> <span class='wout-4'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Year</h4>
                        <div class='rev'> <span class='wout-12'></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales cust' style='height:437px'>
                     <div class='attr'><?php _e('Fees over time','zerobs'); ?></div>
                        <svg id="stacker" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
};

#} Average Revenue - trimmed
add_action( 'wp_ajax_zero_bs_ave_sales_refresh', 'zero_bs_ave_sales_refresh' );
function zero_bs_ave_sales_refresh(){
    //enqueues only on the Sales Dashboard Page..
    global $wpdb;

    $zbs_days = (int)$_POST['d'];

    if($zbs_days > 100){
        $zbs_steps = 60*60*24*30;
    }else{
        $zbs_steps = 60*60*24;
    }

    $offset = 0;

    //move the above to run from the AJAX post... 
    $this_start     =   $_POST['s'];
    $this_end       =   $_POST['e'];
    $that_start     =   $_POST['ps'];

    //this_end we need to move to midnight that night
    $this_end = date('Y-m-d', strtotime('+1 day', strtotime($this_end)));

    //the end of that is the start of this..
    $that_end = $this_start;



        $zbstime = strtotime("first day of next month -1 year", time());
        $zbsdate = date("Y-m-d", $zbstime);
        $zbsnow = date("Y-m-d", time());


        #} Average revenue per customer line...
        $table_name = $wpdb->prefix . "zbs_global_total_trans";
        $query = "SELECT ID, check_point, total_value, total_customers FROM $table_name WHERE check_point >= '$this_start' AND check_point < '$this_end' ORDER by check_point ASC";
        $r = $wpdb->get_results($query);
        $posts_times = array();
        $c = 0;
        foreach ($r as $post) {
            $post_time = strtotime($post->check_point);
            $offset = $post_time % $zbs_steps;
            $post_time -= $offset;
            $posts_times[$post_time]++;

            #} Gross Revenue (Cumulative)
            $average_rev = round($post->total_value / $post->total_customers,2);
            $average_revenue[$post_time] = $average_rev;     //start adding together rows that are the same day..
            $max_day_rev = $average_revenue[$post_time];  // this one will be the LAST value

            $ave_y_max_axis = max($ave_y_max_axis, $average_revenue[$post_time]);

            if($c==0){
                $first_day_rev = $average_revenue[$post_time];
                $ave_y_min_axis = $average_revenue[$post_time];
            }else{
                $ave_y__min_axis = min($ave_y_min_axis, $average_revenue[$post_time]);
            }
            $c++;
        }

        $keys = array_keys($posts_times);  //these are the keys (i.e. the days in the above)
        $d3ave = array();
        $j = 0;
        for($i = $keys[0]; $i <= $keys[(count($keys)-1)]; $i += $zbs_steps) {
            $ave['year']  =   $i;
           
            #} the x-axis scalars
            if($j == 0){
              $min_averev_year = $i;
            }
            $max_averev_year = max($min_customer_year, $i);


            #} Gross Revenue (Cumulative) so need a 'flat-line' if no sales during a time-step
            if($average_revenue[$i] === null){
              $ave['sale'] = $flat;    //allow for flat days...
            }else{
              $ave['sale'] = $average_revenue[$i];
              $flat = $average_revenue[$i]; 
            }
            $d3ave[] = $ave;
            $j++;
        }

    #} Average revenue per customer line...
    $table_name = $wpdb->prefix . "zbs_global_total_trans";
    $query = "SELECT ID, check_point, total_value, total_customers, MONTH(check_point) as m, YEAR(check_point) as y FROM $table_name WHERE check_point >= '$zbsdate' AND check_point < '$zbsnow' ORDER by check_point ASC";
    $r = $wpdb->get_results($query);
    $i=0;

    $posts_times = array();
    $gross_revenue = array();

        foreach ($r as $post) {
            $offset = 0;
            $first = mktime(0,0,0,$post->m,1,$post->y);

            $gross_total = round($post->total_value / $post->total_customers,2);
            #} Gross Revenue (Cumulative)
            $gross_revenue[$first] = $gross_total;     //get the last of the month...


        }

        $barout = array();
        foreach($gross_revenue as $key => $value){
            $bar['year'] = $key;
            $bar['sale'] = $value;
            $barnf['year'] = $key;
            $barnf['sale'] = number_format($value,2);
            $barout[] = $bar;
            $baroutnf[] = $barnf;
        }

    //calculate average revenue change over period
        if($max_day_rev > $first_day_rev){
            $ave_rev_change = round( (($max_day_rev/$first_day_rev) -1 ) * 100, 1);
            $ave_change = 'up';
        }else{
            $ave_rev_change = round( (($first_day_rev/$max_day_rev) -1 ) * 100, 1);
            $ave_change = 'down';
        }


            $res['wout']                  =   $barout;
            $res['woutnf']                =   $baroutnf;
            $res['d3jsave']               =   $d3ave;
            $res['ave_max']               =   $max_day_rev;
            $res['ave_y_min']             =   $ave_y__min_axis;
            $res['ave_y_max']             =   $ave_y_max_axis;
            $res['ave_change']            =   $ave_rev_change;
            $res['ave_dir']               =   $ave_change;
            $res['ave']                   =   number_format($average_rev,2);
            $res['ave_first_prev']        =   number_format($first_day_rev,2);

        
        echo json_encode($res);
        die();
}; 
function zerobscrm_sales_ave(){
    global $wpdb,  $zbs;
    $zbs_curr = zeroBSCRM_getCurrencyChr();

  ?>
    <div class='sales-overview container-fluid'>
      <div class='col-md-6'>
            <h3><?php _e('Average Revenue','zerobs'); ?></h3>
      </div>
      <div class='month-selector'>
        <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
            <span></span> <b class="caret"></b>
        </div>
      </div>
    </div>
    <div class='container-fluid'>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales' style='height:437px'>
                          <div class='max_this'> <span class='max_this_value'></span></div>
                          <div class='compare_this'>
                              <div class='which up'>
                                  <div class='by'>tbc</div>
                                  <div class='time-ago'>last month</div>
                              </div>
                          </div>
                        <svg id="gross" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row sales-look'>
                <div class='graph-box gross_sales status'>
                    <div class='col-md-3'>
                        <h4>Current Month</h4>
                        <div class='rev'> <span class='wout-0'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Month</h4>
                        <div class='rev'> <span class='wout-1'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Three Months Ago</h4>
                        <div class='rev'> <span class='wout-4'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Year</h4>
                        <div class='rev'> <span class='wout-12'></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
};

#} New Customers Single View
add_action( 'wp_ajax_zero_bs_new_refresh', 'zero_bs_new_refresh' );
function zero_bs_new_refresh(){
    //enqueues only on the Sales Dashboard Page..
    global $wpdb, $zbs;

    $zbs_days = (int)$_POST['d'];

    if($zbs_days > 100){
        $zbs_steps = 60*60*24*30;
    }else{
        $zbs_steps = 60*60*24;
    }

    $offset = 0;

    //move the above to run from the AJAX post... 
    $this_start     =   $_POST['s'];
    $this_end       =   $_POST['e'];
    $that_start     =   $_POST['ps'];

    //this_end we need to move to midnight that night
    $this_end = date('Y-m-d', strtotime('+1 day', strtotime($this_end)));

    //the end of that is the start of this..
    $that_end = $this_start;

    $r['start'] = $this_start;
    $r['end'] = $this_end;
    $r['prev'] = $that_start;

		$totes_at_start_last_period = $zbs->DAL->contacts->getContacts(array(
					'youngerThan' => strtotime($that_start),
					'olderThan' => strtotime($that_end),
					'count' => true,
					'ignoreowner' => true
			));
		$totes_at_start = $zbs->DAL->contacts->getContacts(array(
					'olderThan' => strtotime($this_start),
					'count' => true,
					'ignoreowner' => true
			));
		$totes_at_end2 = $zbs->DAL->contacts->getContacts(array(
					'olderThan' => strtotime($this_end),
					'count' => true,
					'ignoreowner' => true
			));


		$r = $zbs->DAL->contacts->getContacts(array(
					'youngerThan' => strtotime($this_start),
					'olderThan' => strtotime($this_end),
					'ignoreowner' => true,
					'withCustomFields' => false,
					'sortByField' => 'zbsc_created',
					'sortOrder'   => 'ASC'
			));

		$posts_times = array();

		foreach ($r as $post) {
				$post_time = $post['created'];
				$offset = $post_time % $zbs_steps;
				$post_time -= $offset;
				$posts_times[$post_time] = $posts_times[$post_time]+1;
		}

        $keys = array_keys($posts_times);

        $running_count = $totes_at_start;

        $d3users = array();
        $j = 0;
        for($i = $keys[0]; $i <= $keys[(count($keys)-1)]; $i += $zbs_steps) {
            $running_count += $posts_times[$i];
            $row['year'] = $i;
            if($j == 0){
              $min_customer_year = $i;
            }
            $max_customer_year = max($min_customer_year, $i);
            $max_in_a_day = max($max_in_a_day, $posts_times[$i]);
            $row['sale'] = $posts_times[$i];
            $d3users[] = $row;

            $row['sale'] = $running_count;
            $d3totalcust[] = $row;

            //all time

            $j++;
        }

        //change over period (customers)
        $this_time_customers_added = $running_count - $totes_at_start;
        $last_time_customers_added =  $totes_at_start_last_period;

        //total
        $totes_at_end = $totes_at_start + $running_count;

        if($this_time_customers_added > $last_time_customers_added){
            $cust_perc = round( (($this_time_customers_added / $last_time_customers_added) - 1) * 100, 1);
            $cust_type = 'up';
        }else{
            $cust_perc = round( (($last_time_customers_added / $this_time_customers_added) - 1) * 100, 1);
            $cust_type = 'down';         
        }

        //change in total customers (will always be trending up)..
        $cust_perc_tot = (( $totes_at_end2 / $totes_at_start) - 1) * 100;



    $zbstime = strtotime("first day of next month -1 year", time());
    $zbsdate = date("Y-m-d", $zbstime);
    $zbsnow = date("Y-m-d", time());
    #} query the transactions over the past year and group by $order['total'] matched by months..
    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_customer' AND post_date >= '$zbsdate' AND post_date <= '$zbsnow' ORDER by post_date ASC";
    $res['query2'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;

    $posts_times = array();
    $gross_revenue = array();

    foreach ($r as $post) {
        $offset = 0;
        $first = mktime(0,0,0,$post->m,1,$post->y);

        $timestamp = strtotime($post->post_date);
        $day = date('D', $timestamp);

        $order = get_post_meta($post->ID,'zbs_transaction_meta', true);

        $gross_total = 1;
        #} Gross Revenue (Cumulative)
        $gross_revenue[$first] += $gross_total;     //start adding together rows that are the same day..
        $day_sum[$day] += $gross_total;
    }

    $barout = array();
    foreach($gross_revenue as $key => $value){
        $bar['year'] = $key;
        $bar['sale'] = $value;
        $barnf['year'] = $key;
        $barnf['sale'] = number_format($value,0);
        $barout[] = $bar;
        $baroutnf[] = $barnf;
    }

    $daysout = array();
    foreach($day_sum as $key => $value){
        $zbsday['name'] = $key;
        $zbsday['value'] = $value;
        $zbsdaynf['name'] = $key;
        $zbsdaynf['value'] = number_format($value,0);
        $zbsdayout[] = $zbsday;
        $zbsdayoutnf[] = $zbsdaynf;
    }    

            $res['wout']                  =   $barout;
            $res['woutnf']                =   $baroutnf;
            $res['dayout']                =   $zbsdayout;
            $res['dayoutnf']              =   $zbsdayoutnf;
            $res['days']                  =   $day_sum;
            $res['d3users']               =   $d3users;
            $res['min_custx']             =   $min_customer_year;
            $res['max_custx']             =   $max_customer_year;
            $res['max_customers']         =   $max_in_a_day;
            $res['cust_totes']            =   $running_count - $totes_at_start;
            $res['cust_at_start']         =   $totes_at_start;
            $res['cust_at_start_nf']      =   number_format($totes_at_start,0);
            $res['cust_at_end']           =   $totes_at_start + $running_count - $totes_at_start;
            $res['cust_at_end_nf']        =   number_format($totes_at_start + $running_count - $totes_at_start);
            $res['total_cust']            =   $d3totalcust;
            $res['this_start']            =   $this_start;
            $res['this_end']              =   $this_end;
            $res['cust_perc']             =   $cust_perc;
            $res['cust_type']             =   $cust_type;
            $res['customers_this_time']   =   number_format($this_time_customers_added,0);
            $res['customers_last_time']   =   number_format($last_time_customers_added,0);
            $res['cust_perc_tot']         =   round($cust_perc_tot,1);
            $res['totes_at_end']          =   $totes_at_end2;
            $res['totes_at_start']        =   $totes_at_start;
        
        echo json_encode($res);
        die();
}; 
function zerobscrm_new(){
    global $wpdb,  $zbs;
    $query = "SELECT post_date, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date > '2013-01-01' GROUP by YEAR(post_date), MONTH(post_date)  ORDER by post_date DESC";
    $r = $wpdb->get_results($query);
  ?>
    <div class='sales-overview container-fluid'>
      <div class='col-md-6'>
            <h3><?php _e('New Customers','zerobs'); ?></h3>
      </div>
      <div class='month-selector'>
        <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
            <span></span> <b class="caret"></b>
        </div>
      </div>
    </div>
    <div class='container-fluid'>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales' style='height:437px'>
                          <div class='max_this'><span class='max_this_value'></span></div>
                          <div class='compare_this'>
                              <div class='which up'>
                                  <div class='by'>tbc</div>
                                  <div class='time-ago'>last month</div>
                              </div>
                          </div>
                        <svg id="gross" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row sales-look'>
                <div class='graph-box gross_sales status'>
                    <div class='col-md-3'>
                        <h4>Current Month</h4>
                        <div class='rev'><span class='wout-0'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Month</h4>
                        <div class='rev'><span class='wout-1'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Three Months Ago</h4>
                        <div class='rev'><span class='wout-4'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Year</h4>
                        <div class='rev'><span class='wout-12'></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales cust' style='height:437px'>
                     <div class='attr'><?php _e('Day of New Customers','zerobs'); ?></div>
                        <svg id="stacker" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
};

#} Total Customers Single View
add_action( 'wp_ajax_zero_bs_tot_refresh', 'zero_bs_tot_refresh' );
function zero_bs_tot_refresh(){
    //enqueues only on the Sales Dashboard Page..
    global $wpdb, $zbs;

    $zbs_days = (int)$_POST['d'];

    if($zbs_days > 100){
        $zbs_steps = 60*60*24*30;
    }else{
        $zbs_steps = 60*60*24;
    }

    $offset = 0;

    //move the above to run from the AJAX post... 
    $this_start     =   $_POST['s'];
    $this_end       =   $_POST['e'];
    $that_start     =   $_POST['ps'];

    //this_end we need to move to midnight that night
    $this_end = date('Y-m-d', strtotime('+1 day', strtotime($this_end)));

    //the end of that is the start of this..
    $that_end = $this_start;

    $r['start'] = $this_start;
    $r['end'] = $this_end;
    $r['prev'] = $that_start;

		$totes_at_start_last_period = $zbs->DAL->contacts->getContacts(array(
					'youngerThan' => strtotime($that_start),
					'olderThan' => strtotime($that_end),
					'count' => true,
					'ignoreowner' => true
			));
		$totes_at_start = $zbs->DAL->contacts->getContacts(array(
					'olderThan' => strtotime($this_start),
					'count' => true,
					'ignoreowner' => true
			));
		$totes_at_end2 = $zbs->DAL->contacts->getContacts(array(
					'olderThan' => strtotime($this_end),
					'count' => true,
					'ignoreowner' => true
			));


		$r = $zbs->DAL->contacts->getContacts(array(
					'youngerThan' => strtotime($this_start),
					'olderThan' => strtotime($this_end),
					'ignoreowner' => true,
					'withCustomFields' => false,
					'sortByField' => 'zbsc_created',
					'sortOrder'   => 'ASC'
			));

		$posts_times = array();

		foreach ($r as $post) {
				$post_time = $post['created'];
				$offset = $post_time % $zbs_steps;
				$post_time -= $offset;
				$posts_times[$post_time] = $posts_times[$post_time]+1;
		}

        $keys = array_keys($posts_times);

        $running_count = $totes_at_start;

        $d3users = array();
        $j = 0;
        for($i = $keys[0]; $i <= $keys[(count($keys)-1)]; $i += $zbs_steps) {
            $running_count += $posts_times[$i];
            $row['year'] = $i;
            if($j == 0){
              $min_customer_year = $i;
            }
            $max_customer_year = max($min_customer_year, $i);
            $max_in_a_day = max($max_in_a_day, $posts_times[$i]);
            $row['sale'] = $posts_times[$i];
            $d3users[] = $row;

            $row['sale'] = $running_count;
            $d3totalcust[] = $row;

            //all time

            $j++;
        }

        //change over period (customers)
        $this_time_customers_added = $running_count - $totes_at_start;
        $last_time_customers_added =  $totes_at_start_last_period;

        //total
        $totes_at_end = $totes_at_start + $running_count;

        if($this_time_customers_added > $last_time_customers_added){
            $cust_perc = round( (($this_time_customers_added / $last_time_customers_added) - 1) * 100, 1);
            $cust_type = 'up';
        }else{
            $cust_perc = round( (($last_time_customers_added / $this_time_customers_added) - 1) * 100, 1);
            $cust_type = 'down';         
        }

        //change in total customers (will always be trending up)..
        $cust_perc_tot = (( $totes_at_end2 / $totes_at_start) - 1) * 100;



    $zbstime = strtotime("first day of next month -1 year", time());
    $zbsdate = date("Y-m-d", $zbstime);
    $zbsnow = date("Y-m-d", time());
    #} query the transactions over the past year and group by $order['total'] matched by months..
    $query = "SELECT ID, post_date, post_title, DAY(post_date) as d, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_customer' AND post_date >= '$zbsdate' AND post_date <= '$zbsnow' ORDER by post_date ASC";
    $res['query2'] = $query;

    $r = $wpdb->get_results($query);
    $i=0;

    $posts_times = array();
    $gross_revenue = array();

    foreach ($r as $post) {
        $offset = 0;
        $first = mktime(0,0,0,$post->m,1,$post->y);

        $timestamp = strtotime($post->post_date);
        $day = date('D', $timestamp);

        $order = get_post_meta($post->ID,'zbs_transaction_meta', true);

        $gross_total = 1;
        #} Gross Revenue (Cumulative)
        $gross_revenue[$first] += $gross_total;     //start adding together rows that are the same day..
        $day_sum[$day] += $gross_total;
    }

    $barout = array();
    foreach($gross_revenue as $key => $value){
        $bar['year'] = $key;
        $bar['sale'] = $value;
        $barnf['year'] = $key;
        $barnf['sale'] = number_format($value,0);
        $barout[] = $bar;
        $baroutnf[] = $barnf;
    }

    $daysout = array();
    foreach($day_sum as $key => $value){
        $zbsday['name'] = $key;
        $zbsday['value'] = $value;
        $zbsdaynf['name'] = $key;
        $zbsdaynf['value'] = number_format($value,0);
        $zbsdayout[] = $zbsday;
        $zbsdayoutnf[] = $zbsdaynf;
    }    

            $res['wout']                  =   $barout;
            $res['woutnf']                =   $baroutnf;
            $res['dayout']                =   $zbsdayout;
            $res['dayoutnf']              =   $zbsdayoutnf;
            $res['days']                  =   $day_sum;
            $res['d3users']               =   $d3users;
            $res['min_custx']             =   $min_customer_year;
            $res['max_custx']             =   $max_customer_year;
            $res['max_customers']         =   $max_in_a_day;
            $res['cust_totes']            =   $running_count - $totes_at_start;
            $res['cust_at_start']         =   $totes_at_start;
            $res['cust_at_start_nf']      =   number_format($totes_at_start,0);
            $res['cust_at_end']           =   $totes_at_start + $running_count - $totes_at_start;
            $res['cust_at_end_nf']        =   number_format($totes_at_start + $running_count - $totes_at_start);
            $res['total_cust']            =   $d3totalcust;
            $res['this_start']            =   $this_start;
            $res['this_end']              =   $this_end;
            $res['cust_perc']             =   $cust_perc;
            $res['cust_type']             =   $cust_type;
            $res['customers_this_time']   =   number_format($this_time_customers_added,0);
            $res['customers_last_time']   =   number_format($last_time_customers_added,0);
            $res['cust_perc_tot']         =   round($cust_perc_tot,1);
            $res['totes_at_end']          =   $totes_at_end2;
            $res['totes_at_start']        =   $totes_at_start;
        
        echo json_encode($res);
        die();
}; 
function zerobscrm_tot(){
    global $wpdb,  $zbs;
    $query = "SELECT post_date, MONTH(post_date) as m, YEAR(post_date) as y FROM $wpdb->posts WHERE post_type = 'zerobs_transaction' AND post_date > '2013-01-01' GROUP by YEAR(post_date), MONTH(post_date)  ORDER by post_date DESC";
    $r = $wpdb->get_results($query);
  ?>
    <div class='sales-overview container-fluid'>
      <div class='col-md-6'>
            <h3><?php _e('Total Customers','zerobs'); ?></h3>
      </div>
      <div class='month-selector'>
        <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
            <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
            <span></span> <b class="caret"></b>
        </div>
      </div>
    </div>
    <div class='container-fluid'>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales' style='height:437px'>
                          <div class='max_this'><span class='max_this_value'></span></div>
                          <div class='compare_this'>
                              <div class='which up'>
                                  <div class='by'>tbc</div>
                                  <div class='time-ago'>last month</div>
                              </div>
                          </div>
                        <svg id="gross" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row sales-look'>
                <div class='graph-box gross_sales status'>
                    <div class='col-md-3'>
                        <h4>Current Month</h4>
                        <div class='rev'><span class='wout-0'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Month</h4>
                        <div class='rev'><span class='wout-1'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Three Months Ago</h4>
                        <div class='rev'><span class='wout-4'></span></div>
                    </div>
                    <div class='col-md-3'>
                        <h4>Last Year</h4>
                        <div class='rev'><span class='wout-12'></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class='sales-graph-wrappers gross-wrappers row'>
            <div class='row'>
                <div class='col-md-12'>
                    <div class='graph-box gross_sales cust' style='height:437px'>
                     <div class='attr'><?php _e('Customers added per month','zerobs'); ?></div>
                        <svg id="stacker" width="100%" height="345"></svg>
                        <div class="loading"><i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
};


function zbs_randomise_activity($type, $value, $meta){

    $zbs_curr = zeroBSCRM_getCurrencyChr();

    if($type == 'zerobs_transaction'){

    $trans = zeroBS_getTransaction($value->ID);
    $cust = zeroBS_getCustomer($trans['customerid']);

     $link = admin_url('admin.php?page=zerobscrm-add-edit-crm&action=view&zbsid=' . $cust['id']);

     //get the customer from the purchase...

      $order_random = array( 

        "Woop. <a target='_blank' href='".esc_url($link)."'><b>" . $cust['fname'] . " " . $cust['lname'] ."</b></a> just purchased ". $meta['item'] . " adding <b>" . $zbs_curr . round($meta['total']) . "</b> to your Sales",
        
        "Alrighttt. A sale has just been made to <a target='_blank' href='".esc_url($link)."'><b>" . $cust['fname'] . " " . $cust['lname'] ."</b></a> for <b>" . $zbs_curr . round($meta['total']) . "</b> who purchased " . $meta['item'] ,

        "Good Work. Another sale has come in. This time for " . $meta['item'] . " for <b>" . $zbs_curr . round($meta['total']) . "</b> say thanks to <a target='_blank' href='".esc_url($link)."'><b>" . $cust['fname'] . " " . $cust['lname'] ."</b></a>",
      );

      shuffle($order_random);
      echo $order_random[0];
    }else if($type == 'zerobs_customer'){


    $cust = zeroBS_getCustomer($value->ID);

    $link = admin_url('admin.php?page=zerobscrm-add-edit-crm&action=view&zbsid=' . $cust['id']);
    $fol_link = admin_url('admin.php?page=zerobscrm-send-email&zbsprefill=' . $cust['id']);

      $customer_random = array(
        "You've accquired a new contact. Awesome. Why not drop <a target='_blank' href='".esc_url($link)."'><b>" . $cust['fname'] . " " . $cust['lname'] ."</b></a> a line and see how they're getting on?",
        "<a target='_blank' href='".esc_url($link)."'><b>" . $cust['fname'] . " " . $cust['lname'] ."</b></a> is now on board. Do you need to <a target='_blank' href='".esc_url($fol_link) ."''>send them an email</a>?",
        "Spiffing. Another contact added <b>Yippee</b>. Why not give them a Discount on their next purchase? View <a target='_blank' href='".esc_url($link)."'><b>" . $cust['fname'] . " " . $cust['lname'] ."</b></a> here"
      );
      shuffle($customer_random);
      echo $customer_random[0];
    }else if($type == 'zerobs_invoice'){

        $inv = zeroBS_getInvoice($value->ID);
        $cust = zeroBS_getCustomer($inv['customerid']);


    $link = admin_url('admin.php?page=zerobscrm-add-edit-crm&action=view&zbsid=' . $cust['id']);
    $fol_link = admin_url('admin.php?page=zerobscrm-send-email&zbsprefill=' . $cust['id']);

        $invoice_random = array(
                "Wicked. You havve just created an Invoice for <a target='_blank' href='".esc_url($link)."'><b>" . $cust['fname'] . " " . $cust['lname'] ."</b></a>. Do you need to <a target='_blank' href='".esc_url($fol_link) ."''>Follow Up</a>",
          );
        shuffle($invoice_random);
        echo $invoice_random[0];

    }else if($type == 'zerobs_quote'){
        $quote_random = array(
            "<b>Woah</b>. Check out your awesome sorcery. You have created a Quote. Send it and make sure to follow up with a call",
          );
        shuffle($quote_random);
        echo $quote_random[0];

    }
}

function zerobscrm_total_customers(){
    zbs_total_trans();
}




#} #CORELOADORDER
// check core plugin installed
function zeroBSCRM_SalesDashCheckCore(){


    #} If no core found, deactivate this plugin!
    if (!defined('ZBSCRMCORELOADED')){

        if ( ! function_exists( 'deactivate_plugins' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        }

        #deactivate_plugin( '/zeroBSCRM_MailCampaigns/zeroBSCRM_MailCampaigns.php' );
        deactivate_plugins(  ZBSCRM_SALES_FILE  );  

        #} Stop plugin running
        define('ZBSCRMCORELOADFAILURE',true);

    }

}

function zbscompare_by_dates($a, $b) {

    $dateA = -1; $dateB = -1;
 
    // our objs vs wp
    if (is_array($a)) 
        $dateA = $a['created'];
    else 
        $dateA = (int)strtotime($a->post_date);

    if (is_array($b))
        $dateB = $b['created'];
    else 
        $dateB = (int)strtotime($b->post_date);

    $diff = $dateA - $dateB;
    return $diff;
    
}


?>