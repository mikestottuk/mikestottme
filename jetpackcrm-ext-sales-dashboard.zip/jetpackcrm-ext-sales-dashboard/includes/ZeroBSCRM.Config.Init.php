<?php
/*!
 * Jetpack CRM
 * https://jetpackcrm.com
 * V1.0
 *
 * Copyright 2017-2019+ Zero BS Software Limited
 */


	#} ================================================================================

		#} Define the default settings (these are the "initial" settings for your plugin)

	#} ================================================================================

		global $zeroBSCRM_extension_WooCommerce_defaults;
		$zeroBSCRM_extension_WooCommerce_defaults = array(

			#} Keypairs or multi-depth array items are fine :)
			#} Some examples
			'wcdomain' 	=> 'a',
			'wckey' 	=> 'b',
			'wcsecret' 	=> 'c',
			'wcprefix' 	=> 'd'

		);

	#} ================================================================================

	#} Mark as included :)
	#} SET THIS TO A UNIQUE VAL and then update your main plugin php (search #settingsInclude)
	define('ZBSCRM_INC_EXT_WOOCOMMERCE_CONFINIT',true);