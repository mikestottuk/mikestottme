v2.8.0 - 27 July 2023
----------------------
* Fixed: Menu item now grouped with all Jetpack CRM menu items
* Improved: Implemented Emerald-style content
* Removed: Recent activity section in favor of CRM dashboard activity log
* Added: Support for SCRIPT_DEBUG

v2.7.5 - 16 February 2022
----------------------
* Improved: Dashboard layout

v2.7.4 - 22 October 2021
-----------------------------
* Improved: Date picker and dashboard design tweaks

v2.7.3 - 22 October 2020
---------------------------
* Fixed: End date didn't include the actual full day.
* Fixed: If error in response show error message
* Fixed: Rare migration PHP error caused by missing function

v2.7.2 - 26 July 2020
------------------------------
* Fixed: v2.7.2 zip upload

v2.7.1 - 24 July 2020
------------------------------
* Fixed: Sales Dashboard to use date created again

v2.7 - 20 July 2020
------------------------------
* Improved: Rebrand

v2.6: 15 November 2019
-------------------------------
* Improved: Sales Dashboard performance with v3.0
* Improved: v3.0 compat check

v2.5.2 - 2 May 2019
----------------------------
* Fixed: PHP warnings if no data
* Fixed: Extra charts on hold until v3.0

v2.5.1 - 5 March 2019
-----------------------------
* Fixed: Extension Manager Load order

v2.5 - 4 February 2019
-------------------------------
* Fixed: Extension not activating
* Fixed: Recent Activity was backwards

v2.4.2 - 20 December 2018
----------------------------------
* Added: Auto update code (Jetpack CRM v2.97)

v2.4.1 - 30 October 2018
---------------------------------
* Improved: Update Core Clash

v2.4 - 15 September 2018
---------------------------------
* Added: Update Core Code Check