<?php
/*
Plugin Name: Jetpack CRM Extension: Sales Dashboard
Plugin URI: https://jetpackcrm.com
Description: Sales Dashboard lets you visualise your CRM and transaction information.
Version: 2.8.0
Author: Automattic
Author URI: https://jetpackcrm.com
*/


/*
let's do a global DEBUG mode for this plugin only
*/
global $zbs_salesdash_debug;

/* DEBUG mode - set to true to see messages about the sales figures...*/
$zbs_salesdash_debug = false;

define( 'ZBSCRM_SALES_FILE', __FILE__ );

/**
*The Core Version Checker
*
*
*  @since 2.4
*/
// post Jetpack CRM core settings, add slug + installed marker
function zeroBSCRM_salesdash_postInit() {
	global $zeroBSCRM_extensionsInstalledList;
	if ( ! is_array( $zeroBSCRM_extensionsInstalledList ) ) {
		$zeroBSCRM_extensionsInstalledList = array();
	}
	$zeroBSCRM_extensionsInstalledList[] = 'salesdash'; #woo #pay #env

	require_once __DIR__ . '/includes/learn-menus.php'; // learn menu
	require_once __DIR__ . '/includes/loader-v3.php'; // legacy catch-all file
	require_once __DIR__ . '/includes/salesdash.php'; // main page
}
add_action( 'after_zerobscrm_settings_init', 'zeroBSCRM_salesdash_postInit', 10 );

// Check for parent plugins
function jpcrm_salesdash_core_present() {
	if ( is_admin() && current_user_can( 'activate_plugins' ) ) {
		// Check which parent plugin is req.
		$meets_requirements = true;
		if ( ! class_exists( 'ZeroBSCRM' ) || ! defined( 'ZBSCRMCORELOADED' ) ) {
			$meets_requirements = false;
			add_action( 'admin_notices', 'jpcrm_salesdash_core_missing_notice' );
		} else {

			global $zbs;
			$meets_requirements = $zbs->dependency_checker->check_core_reqs(
				'Sales Dashboard',
				array(
					'req_core_ver' => '6.0',
					'req_DAL_ver'  => '3.0',
				)
			);
		}
		if ( ! $meets_requirements ) {
			// Nope.
			deactivate_plugins( plugin_basename( __FILE__ ) );
			if ( isset( $_GET['activate'] ) ) {
				unset( $_GET['activate'] );
			}
		}
	}
}
add_action( 'admin_init', 'jpcrm_salesdash_core_present' );

function jpcrm_salesdash_core_missing_notice() {
	?><div class="error"><p>The Sales Dashboard extension for Jetpack CRM requires the <a href="https://wordpress.org/plugins/zero-bs-crm/" target="_blank">Jetpack CRM</a> WordPress plugin. Please install and activate Jetpack CRM first!</p>
	<?php // Needs installing or activating? - not perfect
	$pluginDir = 'zero-bs-crm/ZeroBSCRM.php';
	if( file_exists( WP_PLUGIN_DIR . '/' . $pluginDir ) ) {
		?>
		<p>Jetpack CRM seems to be installed. <strong>Please activate the core CRM plugin first.</strong></p></div>
		<?php
	} else {
		?>
		<p><a href="<?php echo admin_url( 'plugin-install.php?tab=plugin-information&plugin=zero-bs-crm' ); ?>" class="button">Please click here</a> and then click install in the bottom right.</p></div>
		<?php
	}
}

function zeroBSCRM_extension_name_salesdash(){ return 'Sales Dashboard'; }
function zeroBSCRM_extension_file_salesdash(){ return  __FILE__; }

#} Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
