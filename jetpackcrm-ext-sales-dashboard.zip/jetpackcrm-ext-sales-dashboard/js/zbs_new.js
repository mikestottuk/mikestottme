jQuery(document).ready(function($){

zbsStrokeColor = zbsJS_admcolours.colors[0];

jQuery( ".activity select" ).change(function() {
   var filter = jQuery(this).val();
   if(filter == 'everything'){
       jQuery(".activity .everything").show();
   }else{
       jQuery(".activity .everything").hide();
       jQuery(".activity .list-"+filter).fadeIn(1000);
   }
});
  

});


function GrossChart(data, minx, maxx, max_this, zbs_days) {
    // var data = [{"sale":20.3,"year":"1462103580"},{"sale":119.6,"year":"1462107983"},{"sale":218.9,"year":"1462147998"},{"sale":244.08,"year":"1462168876"},{"sale":258.11,"year":"1462179892"},{"sale":276.36,"year":"1462198524"},{"sale":294.61,"year":"1462211203"},{"sale":318.76,"year":"1462224359"},{"sale":354.06,"year":"1462234850"},{"sale":383.51,"year":"1462235666"},{"sale":397.54,"year":"1462235668"},{"sale":481.42,"year":"1462236312"},{"sale":580.72,"year":"1462258875"},{"sale":615.02,"year":"1462266314"},{"sale":643.02,"year":"1462294747"},{"sale":677.32,"year":"1462326111"},{"sale":712.61,"year":"1462332994"},{"sale":736.75,"year":"1462344071"},{"sale":766.2,"year":"1462392318"},{"sale":885.5,"year":"1462402103"},{"sale":1063.5,"year":"1462428944"},{"sale":1157.75,"year":"1462433836"},{"sale":1182.99,"year":"1462479693"},{"sale":1271.98,"year":"1462483565"},{"sale":1429.98,"year":"1462501177"},{"sale":1529.28,"year":"1462505636"},{"sale":1564.57,"year":"1462517407"},{"sale":1594.56,"year":"1462550311"},{"sale":1629.86,"year":"1462565094"},{"sale":1659.31,"year":"1462581439"},{"sale":1673.34,"year":"1462581440"},{"sale":1698.52,"year":"1462582053"},{"sale":1731.41,"year":"1462674612"},{"sale":1758.03,"year":"1462716615"},{"sale":1781.21,"year":"1462743621"},{"sale":1804.39,"year":"1462751460"},{"sale":1832.42,"year":"1462805159"},{"sale":1856.41,"year":"1462817872"},{"sale":1875.5,"year":"1462821729"},{"sale":1897.9,"year":"1462823051"},{"sale":1920.35,"year":"1462823749"},{"sale":1938.6,"year":"1462833025"},{"sale":1956.85,"year":"1462847360"},{"sale":1970.88,"year":"1462847361"},{"sale":1996.06,"year":"1462880141"},{"sale":2036.66,"year":"1462881248"},{"sale":2066.11,"year":"1462907511"},{"sale":2080.14,"year":"1462907512"},{"sale":2164.02,"year":"1462949581"},{"sale":2302.02,"year":"1462973623"},{"sale":2376.02,"year":"1462976841"},{"sale":2405.02,"year":"1462988458"},{"sale":2428.17,"year":"1463013467"},{"sale":2451.32,"year":"1463077801"},{"sale":2479.35,"year":"1463077925"},{"sale":2503.37,"year":"1463090282"},{"sale":2528.36,"year":"1463093598"},{"sale":2552.51,"year":"1463104933"},{"sale":2581.96,"year":"1463105789"},{"sale":2681.26,"year":"1463108530"},{"sale":2780.56,"year":"1463112087"},{"sale":2810.01,"year":"1463123180"},{"sale":2839.46,"year":"1463124243"},{"sale":2880.06,"year":"1463181876"},{"sale":2914.36,"year":"1463182489"},{"sale":2940.95,"year":"1463183781"},{"sale":2973.84,"year":"1463183851"},{"sale":3003.29,"year":"1463185684"},{"sale":3021.59,"year":"1463190542"},{"sale":3039.89,"year":"1463207256"},{"sale":3063.07,"year":"1463227428"},{"sale":3156.1,"year":"1463248630"},{"sale":3314.1,"year":"1463249532"},{"sale":3472.1,"year":"1463261399"},{"sale":3630.1,"year":"1463306332"},{"sale":3729.4,"year":"1463316875"},{"sale":3828.7,"year":"1463338999"},{"sale":3921.7,"year":"1463360628"},{"sale":3956,"year":"1463362473"},{"sale":3990.33,"year":"1463362683"},{"sale":4009.24,"year":"1463363048"},{"sale":4023.27,"year":"1463363835"},{"sale":4042.41,"year":"1463369783"},{"sale":4251.4,"year":"1463418779"},{"sale":4455.28,"year":"1463419181"},{"sale":4467.47,"year":"1463452274"},{"sale":4553.78,"year":"1463453072"},{"sale":4641.93,"year":"1463460281"},{"sale":4665.08,"year":"1463460578"},{"sale":4738.08,"year":"1463461455"},{"sale":4817.38,"year":"1463479917"},{"sale":4850.98,"year":"1463479918"},{"sale":4871.98,"year":"1463479919"},{"sale":4889.67,"year":"1463500606"},{"sale":4978.66,"year":"1463501244"},{"sale":5066.81,"year":"1463517926"},{"sale":5085.11,"year":"1463526529"},{"sale":5108.29,"year":"1463530782"},{"sale":5142.62,"year":"1463533060"},{"sale":5183.22,"year":"1463536937"},{"sale":5217.55,"year":"1463568887"},{"sale":5240.68,"year":"1463604813"},{"sale":5308.78,"year":"1463612800"},{"sale":5372.66,"year":"1463629957"},{"sale":5386.69,"year":"1463638693"},{"sale":5416.14,"year":"1463681291"},{"sale":5449.74,"year":"1463701744"}];

var margin = {top: 20, right: 0, bottom: 60, left: 50},
    width = jQuery("#gross").width() - margin.left - margin.right,
    height = 375 - margin.top - margin.bottom;

var parseDate = d3.time.format("%d-%b-%y").parse;

// Mikes:
//var x = d3.time.scale().range([0, width]);
// here you're doing "range from date: 0 to xxx" (where xxx is a pixel width)
// This should probably be range([startingdate,endingdate])
// ALSO, why are you calling the second var in data "Year" when it's clearly a unix timestamp? (THIS WILL confuse you later)

// Grab starting + ending date
var startingDateUTS = null, endingDateUTS = null;
if (typeof data[0] !== "undefined") startingDateUTS = data[0].year;
if (data.length > 0) endingDateUTS = data[data.length - 1].year;
// because the following uses Date obj, need to pass them *1000 (unixtimestamp -> date obj) see http://stackoverflow.com/questions/847185/convert-a-unix-timestamp-to-time-in-javascript
// We need to pass D3 date objs, not timestamps...
var startingDate = new Date(startingDateUTS*1000);
var endingDate = new Date(endingDateUTS*1000);

// then one of these two:
//1) Simple range:
//var x = d3.time.scale().range([startingDate, endingDate]);

//2) Use Domains:
// Modified from
// http://jsfiddle.net/robdodson/KWRxW/
var x = d3.time.scale()
    .domain([startingDate, d3.time.day.offset(endingDate, 0)])
    .rangeRound([0, width - margin.left - margin.right]);


var y = d3.scale.linear().range([height, 0]);

// Mikes:
//var xAxis = d3.svg.axis()
//    .scale(x)
//    .orient("bottom");

// Modified ver as per 2) above
    if(zbs_days > 30 && zbs_days < 100){
var xAxis = d3.svg.axis()
    .scale(x)
    .orient('bottom')
    .ticks(d3.time.weeks, 1)      
    // ^^ presume this'll show all days, maybe try changing 1 to 7 ... actually, see here:
    // https://github.com/d3/d3/wiki/Time-Scales#ticks
    // You might want to do some sort of test above, and where there's more than 30 days, use "d3.time.weeks, 1" instead of days, or similar
    .tickFormat(d3.time.format('%d %b')) // as per above link - %a %d - for day boundaries, such as "Mon 07".
    .tickSize(0)
    .tickPadding(10);
}else if(zbs_days > 100){
var xAxis = d3.svg.axis()
    .scale(x)
    .orient('bottom')
    .ticks(d3.time.weeks, 6)      
    // ^^ presume this'll show all days, maybe try changing 1 to 7 ... actually, see here:
    // https://github.com/d3/d3/wiki/Time-Scales#ticks
    // You might want to do some sort of test above, and where there's more than 30 days, use "d3.time.weeks, 1" instead of days, or similar
    .tickFormat(d3.time.format('%d %b')) // as per above link - %a %d - for day boundaries, such as "Mon 07".
    .tickSize(0)
    .tickPadding(10);
}else{
    var xAxis = d3.svg.axis()
      .scale(x)
    .orient('bottom')
    .ticks(d3.time.days, 2)       
    // ^^ presume this'll show all days, maybe try changing 1 to 7 ... actually, see here:
    // https://github.com/d3/d3/wiki/Time-Scales#ticks
    // You might want to do some sort of test above, and where there's more than 30 days, use "d3.time.weeks, 1" instead of days, or similar
    .tickFormat(d3.time.format('%d %b')) // as per above link - %a %d - for day boundaries, such as "Mon 07".
    .tickSize(0)
    .tickPadding(10);
}


var yAxis = d3.svg.axis()
    .scale(y)
    .ticks(5)
    .orient("left");

var area = d3.svg.area().interpolate("basis")
    .x(function(d) { 
    // Mikes:
    // return x(d.year); 
    // WH: Think you might need to pass dates here for this to work with above, test this, though:
    return x(new Date(d.year*1000))

    })
    .y0(height)
    .y1(function(d) { return y(d.sale); });

var svg = d3.select("#gross").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


  // WH: This is further messing with the above, it should surely be set just after making "var = x" ... else you're gonna make it too complex to know what's going on
  // Mikes: x.domain(d3.extent(data, function(d) { return d.year; }));
  // WH: Test this without including the line (depending on 1) or 2) above) - if it's needed, it might need to reflect the other func I added:
  // x.domain(d3.extent(data, function(d) { return new Date(d.year*1000); }));
  y.domain([0, d3.max(data, function(d) { return d.sale; })]);

  svg.append("path")
      .datum(data)
      .attr("class", "area")
      .attr("d", area);

var pathContainers = svg.selectAll('g.area')
    .data(data);

    pathContainers.enter().append('g')
    .attr('class', 'line')

    pathContainers.selectAll('path')
    .data(function (d) { return [d]; }) // continues the data from the pathContainer
    .enter().append('path')
      .attr('d', d3.svg.line()
        // Mikes:
        //.x(function (d) { return d.year; })
        // WH: Again, this MIGHT or MIGHT NOT need to be as follows: 
        //.x(function (d) { return new Date(d.year*1000); })
        .y(function (d) { return d.sale; })
      );

    // add circles
    pathContainers.selectAll('g.line')
    .data(function (d) { return d; })
    .enter().append('circle')
    // Mikes:
    //.attr('cx', function (d) { return d.year; })
    // WH: Again, this MIGHT or MIGHT NOT need to be as follows: 
    //.attr('cx', function (d) { return new Date(d.year*1000); })    
    .attr('cy', function (d) { return d.sale; })
    .attr('r', 3); 



  svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

  svg.append("g")
      .attr("class", "y axis")
      .call(yAxis)
    .append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 4)
      .attr("dy", ".71em")
      .style("text-anchor", "end")
      .text("");


}

//datetime stuff
jQuery(function() {

    function cb(start, end) {
        zbsStrokeColor = zbsJS_admcolours.colors[0];
        jQuery('#reportrange span').html(start.format('MMM,D,Y') + ' - ' + end.format('MMM,D,Y'));
        s = start.format('Y-MM-DD');
        e = end.format('Y-MM-DD') ;

        zbs_days = Math.round((end-start)/60/60/24/1000);
        jQuery('.time-ago').html(zbs_days +' days ago');
        var current_start = moment(s); 
        var previous_start = current_start.clone().subtract(zbs_days, 'days'); 

        ps = previous_start.format('Y-MM-DD');

        zbs_days_p = Math.round((start-previous_start)/60/60/24/1000);


        var zbs_start_date = s;
        var zbs_end_date = e;
        var zbs_prev_start_date = ps;

        var visg = d3.select("#gross");
        visg.selectAll("path").remove();
        visg.selectAll("g").remove();

        jQuery('.loading').css('color', zbsStrokeColor).show();

        var t = {
                action: 'zero_bs_new_refresh',
                s: zbs_start_date,
                e: zbs_end_date,
                ps: zbs_prev_start_date,
                d: zbs_days
                }

            o = jQuery.ajax({
                url: ajaxurl,
                type: "POST",
                data: t,
                dataType: "json"
            });
            o.done(function(res) {

                
                GrossChart(res.d3users, res.minx, res.maxx, res.max_customers, zbs_days);
                jQuery('.loading').hide();

                jQuery('.gross_sales .max_this_value').html(res.cust_totes);

                //gross chart change
                if(res.cust_type == 'up'){
                    jQuery('.gross_sales .which').removeClass('down').addClass('up');
                    jQuery('.gross_sales .which .by').html('+' + res.cust_perc + '%');
                }else{
                    jQuery('.gross_sales .which').removeClass('up').addClass('down');
                    jQuery('.gross_sales .which .by').html('-'+res.cust_perc + '%');
                }

                //stacker it in here too
                StackerChart(res.dayout);

                jQuery('.wout-0').html(res.woutnf[11].sale);
                jQuery('.wout-1').html(res.woutnf[10].sale);
                jQuery('.wout-4').html(res.woutnf[8].sale);
                jQuery('.wout-12').html(res.woutnf[0].sale);

       
            })
            o.fail(function(res){
          
            });


    }


    cb(moment().subtract(30, 'days'), moment());

    jQuery('#reportrange').daterangepicker({
        ranges: {
           'Last 30 Days': [moment().subtract(30, 'days'), moment()],
           'Latest Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
           'Prior Month' : [moment().subtract(2, 'month').startOf('month'), moment().subtract(2, 'month').endOf('month')],
           'Last 3 Months': [moment().subtract(3, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
           'Last 6 Months': [moment().subtract(6, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
           'Last Year': [moment().subtract(1, 'year').startOf('month'), moment().subtract(1, 'month').endOf('month')],
         //  'All Time': [ window.zbs_min_trans_date , moment()],
        },
        maxDate: moment()
    }, cb);
});



function StackerChart(stack_data){


  var data = stack_data;


order = { Sun: 1, Mon: 2, Tue: 3, Wed: 4, Thu: 5, Fri: 6, Sat: 7 };

data.sort(function (a, b) {
    return order[a.name] - order[b.name];
});
// document.write('<pre>' + JSON.stringify(data, 0, 4) + '</pre>');


var margin = {top: 20, right: 30, bottom: 30, left: 40},
    width = jQuery('#stacker').width() - margin.left - margin.right,
    height = 380 - margin.top - margin.bottom;

var x = d3.scale.ordinal()
    .rangeRoundBands([0, width], .1);

var y = d3.scale.linear()
    .range([height, 0]);

var xAxis = d3.svg.axis()
    .scale(x)
    .orient("bottom");

var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left");

var chart = d3.select("#stacker")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");


  x.domain(data.map(function(d) { return d.name; }));
  y.domain([0, d3.max(data, function(d) { return d.value; })]);

  chart.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

  chart.append("g")
      .attr("class", "y axis")
      .call(yAxis);

  chart.selectAll(".bar")
      .data(data)
    .enter().append("rect")
      .attr("class", "bar")
      .attr("x", function(d) { return x(d.name); })
      .attr("y", function(d) { return y(d.value); })
      .attr("height", function(d) { return height - y(d.value); })
      .attr("width", x.rangeBand());


function type(d) {
  d.value = +d.value; // coerce to number
  return d;
}

}



function WorkStreamChart(){

    var width = jQuery("#work").width(),
        height = 300,
        radius = Math.min(width, height) / 2;

    var color = d3.scale.ordinal().domain(['#096484','#4796b3','#52accc','#74B6CE']);

    var pie = d3.layout.pie()
        .sort(null);

    var arc = d3.svg.arc()
        .innerRadius(radius - 100)
        .outerRadius(radius - 50);

    var svg = d3.select("#work").append("svg")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

    var path = svg.selectAll("path")
        .data(pie(dataset.workstream))
      .enter().append("path")
        .attr("fill", function(d, i) { return color.domain()[i] })
        .attr("d", arc);
}


