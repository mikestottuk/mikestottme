jQuery(document).ready(function($){

    zbsStrokeColor = zbsJS_admcolours.colors[0];
    
    jQuery( ".activity select" ).change(function() {
       var filter = jQuery(this).val();
       if(filter == 'everything'){
           jQuery(".activity .everything").show();
       }else{
           jQuery(".activity .everything").hide();
           jQuery(".activity .list-"+filter).fadeIn(1000);
       }
    });
      
    
    });
    
    //the chart drawing tools... 
    function TotCustomers(data, min_custx, max_custx, cust_at_end, cust_at_start){
    
        if(data === null){
            return false;
        }
    
    
        max_this = Number(cust_at_end);
    
    
        var vis = d3.select("#zbs_totcust"),
            WIDTH = jQuery("#zbs_totcust").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 10,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([min_custx, max_custx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([Number(cust_at_start), max_this]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
           
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    function NewCustomers(data,min_custx, max_custx, max_customers){
    
    
        if(data === null){
            return false;
        }
    
        max_this = Number(max_customers);
    
        var vis = d3.select("#zbs_newcust"),
            WIDTH = jQuery("#zbs_newcust").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 10,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([min_custx, max_custx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0, max_this]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
        
       
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    
    function RefundChart(data, minx, maxx, ref_max){
    
        if(data === null){
            return false;
        }
    
        max_this = Number(ref_max);
    
    
        var vis = d3.select("#zbs_ref"),
            WIDTH = jQuery("#zbs_ref").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 10,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([minx, maxx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0, max_this]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
       
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    
    function FailedChart(data, minx, maxx, fail_max){
    
        if(data === null){
            return false;
        }
    
        max_this = Number(fail_max);
    
    
        var vis = d3.select("#zbs_fail"),
            WIDTH = jQuery("#zbs_fail").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 10,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([minx, maxx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0, max_this]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
       
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    
    function FeeChart(data, minx, maxx, fee_max){
    
        if(data === null){
            return false;
        }
    
        max_this = Number(fee_max);
    
    
        var vis = d3.select("#zbs_fee"),
            WIDTH = jQuery("#zbs_fee").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 10,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([minx, maxx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0, max_this]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
       
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    function DisChart(data, minx, maxx, disc_max){
    
        if(data === null){
            return false;
        }
    
        max_this = Number(disc_max);
    
    
        var vis = d3.select("#zbsdisc");
        vis.selectAll("path").remove();
    
            WIDTH = jQuery("#zbsdisc").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([minx, maxx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0, max_this]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
    
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    function AveChart(data, minx, maxx, ave_max, ave_y_min, ave_y_max){
    
        if(data === null){
            return false;
        }
    
    
        min_y = Number(ave_y_min * 0.9);
        max_y = Number(ave_y_max * 1.1);
    
    
    
        var vis = d3.select("#ave"),
            WIDTH = jQuery("#ave").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([minx, maxx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([min_y, max_y]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
        
       
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    function NetChart(data, minx, maxx, net_max){
    
        if(data === null){
            return false;
        }
    
        max_this = Number(net_max * 1.1);  //add 10% to the top
    
        var vis = d3.select("#net");
        vis.selectAll("path").remove();  //clear the chart.. 
    
            WIDTH = jQuery("#net").width(),
            HEIGHT = 125,
            MARGINS = {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
            xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([minx, maxx]),
    
            yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0, max_this]),
            xAxis = d3.svg.axis()
            .scale(xScale),
            yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left");
        
       
        var area = d3.svg.area()
            .x(function(d) {
                return xScale(d.year);
            })
            .y(function(d) {
                return yScale(d.sale);
            })
            .interpolate("basis");
    
        vis.append('svg:path')
            .attr('d', area(data))
            .attr('stroke', zbsStrokeColor)
            .attr('stroke-width', 4)
            .attr('fill', 'none');
    }
    function GrossChart(data, minx, maxx, max_this) {
    
    
            if(data === null){
                return false;
            }
            max_this = Number(max_this) + Number(max_this * 0.1);
    
            var vis = d3.select("#gross");
    
            vis.selectAll("path").remove();
    
                WIDTH = jQuery("#gross").width(),
                HEIGHT = 125,
                MARGINS = {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
                xScale = d3.scale.linear().range([MARGINS.left, WIDTH - MARGINS.right]).domain([minx, maxx]),
                yScale = d3.scale.linear().range([HEIGHT - MARGINS.top, MARGINS.bottom]).domain([0, max_this]),
                xAxis = d3.svg.axis()
                .scale(xScale),
                yAxis = d3.svg.axis()
                .scale(yScale)
                .orient("left");
           
            var area = d3.svg.area()
                .x(function(d) {
                    return xScale(d.year);
                })
                .y(function(d) {
                    return yScale(d.sale);
                })
                .interpolate("basis");
    
            vis.append('svg:path')
                .attr('d', area(data))
                .attr('stroke', zbsStrokeColor)
                .attr('stroke-width', 4)
                .attr('fill', 'none');
    }
    
    //datetime stuff
    jQuery(function() {
    
        function cb(start, end) {
            zbsStrokeColor = zbsJS_admcolours.colors[0];
            jQuery('#reportrange span').html(start.format('MMM,D,Y') + ' - ' + end.format('MMM,D,Y'));
            s = start.format('Y-MM-DD');
            e = end.format('Y-MM-DD') ;
    
            zbs_days = Math.round((end-start)/60/60/24/1000);
            jQuery('.time-ago').html(zbs_days +' days ago');
            var current_start = moment(s); 
            var previous_start = current_start.clone().subtract(zbs_days, 'days'); 
    
            ps = previous_start.format('Y-MM-DD');
    
            zbs_days_p = Math.round((start-previous_start)/60/60/24/1000);
    
     
    
            var zbs_start_date = s;
            var zbs_end_date = e;
            var zbs_prev_start_date = ps;
    
            var visg = d3.select("#gross");
            visg.selectAll("path").remove();
            var visn = d3.select("#net");
            visn.selectAll("path").remove();
            var visd = d3.select("#zbsdisc");
            visd.selectAll("path").remove();
            var visf = d3.select("#zbs_fee");
            visf.selectAll("path").remove();
            var visf = d3.select("#ave");
            visf.selectAll("path").remove();
            var visf = d3.select("#zbs_newcust");
            visf.selectAll("path").remove();
            var visf = d3.select("#zbs_totcust");
            visf.selectAll("path").remove();
    
            var visf = d3.select("#zbs_ref");
            visf.selectAll("path").remove();
    
            var visf = d3.select("#zbs_fail");
            visf.selectAll("path").remove();
    
    
    
            jQuery('.loading').css('color', zbsStrokeColor).show();
    
            var t = {
                    action: 'zero_bs_sales_refresh',
                    s: zbs_start_date,
                    e: zbs_end_date,
                    ps: zbs_prev_start_date,
                    d: zbs_days
                    }
       
                o = jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: t,
                    dataType: "json"
                });
                o.done(function(res) {
    
          
                    console.log(res);
    
                    /*
                    jQuery.each(res.d3jsave, function(index, item) {
                        jQuery("#salesdebug").append("<tr><td>" + moment.unix(item.year).format("MMM DD") + "</td><td>" + item.sale + '</td></tr>');
                    });
                    */
                    
                    
                    GrossChart(res.d3js, res.minx, res.maxx, res.max_this);
                    NetChart(res.d3jsnet, res.minx, res.maxx, res.net_max);
                    DisChart(res.d3jsdis, res.minx, res.maxx, res.disc_max);
                    FeeChart(res.d3jsfee, res.minx, res.maxx, res.fee_max);
    
    
    
                    RefundChart(res.d3jsref, res.minx, res.maxx, res.ref_max);
                    FailedChart(res.d3jsfail, res.minx, res.maxx, res.fail_max);
    
    
                    NewCustomers(res.d3users, res.minx, res.maxx, res.max_customers);
                    TotCustomers(res.d3total, res.minx, res.maxx, res.total_at_end, res.total_at_start);
    
    
                    /*
                    if(res.dsjsave != null){
                    AveChart(res.d3jsave, res.minx, res.maxx, res.ave_max, res.ave_y_min, res.ave_y_max);
                    }
                    
                    NewCustomers(res.d3users, res.minx, res.maxx, res.max_customers);
                    TotCustomers(res.total_cust, res.minx, res.maxx, res.totes_at_end, res.cust_at_start);
                    
    
                    */
    
                    jQuery('.loading').hide();

                    jQuery('#hist').fadeIn(1000);
    
                    // GROSS SALES BOX (CURRENT PERIOD AND PREVIOUS PERIOD)
                    /*
                        These totals are for the boxes but do not draw the chart lines.
                        Re-think how best to draw the lines as currently it's quite
                        Messy with how it's all done and hard to change or expand upon
                        NEW DB2.0 makes these totals a single SQL statement for all the boxes
                        either from transactions or from contacts
    
                        Really ultilise the new data structure to make reporting on the 
                        ZBS CRM data easier. 
                    */
                    jQuery('.gross_sales .max_this_value').html(res.gross_total_current);
                    jQuery('.gross_sales .max_prev_value').html(res.gross_total_previous);
    
                    // NET SALES BOX (CURRENT PERIOD AND PREVIOUS PERIOD)
                    jQuery('.net_sales .max_this_value').html(res.net_total_current);
                    jQuery('.net_sales .max_prev_value').html(res.net_total_previous);
    
                    // DISCOUNT 
                    jQuery('.zbs_discounts .max_this_value').html(res.discount_total_current);
                    jQuery('.zbs_discounts .max_prev_value').html(res.discount_total_previous);
    
                    // FEES
                    jQuery('.zbs_fee .max_this_value').html(res.fee_total_current);
                    jQuery('.zbs_fee .max_prev_value').html(res.fee_total_previous);
    
                    // REFUNDS
                    jQuery('.zbs_refunds .max_this_value').html(res.refund_total_current);
                    jQuery('.zbs_refunds .max_prev_value').html(res.refund_total_previous);
    
                    // FAILED
                    jQuery('.zbs_failed .max_this_value').html(res.failed_total_current);
                    jQuery('.zbs_failed .max_prev_value').html(res.failed_total_previous);
    
                    // ARPU
                    jQuery('.ave_rev .max_this_value').html(res.avrpu_current);
                    jQuery('.ave_rev .max_prev_value').html(res.avrpu_previous);
    
                    // NEW CONTACTS ADDED 
                    jQuery('.zbs_newcust .max_this_value').html(res.customers_added_current);
                    jQuery('.zbs_newcust .max_prev_value').html(res.customers_added_previous);
                    
                    // TOTAL CONTACT COUNT
                    jQuery('.zbs_totcust .max_this_value').html(res.customers_current);
                    jQuery('.zbs_totcust .max_prev_value').html(res.customers_previous);
    
                    //gross chart change
                    if(res.type == 'up'){
                        jQuery('.gross_sales .which').removeClass('down').addClass('up');
                        jQuery('.gross_sales .which .by').html('+' + res.change + '%');
                    }else{
                        jQuery('.gross_sales .which').removeClass('up').addClass('down');
                        jQuery('.gross_sales .which .by').html('-'+res.change + '%');
                    }
    
                    //net chart change
                    if(res.nettype == 'up'){
                        jQuery('.net_sales .which').removeClass('down').addClass('up');
                        jQuery('.net_sales .which .by').html('+' + res.netchange + '%');
                    }else{
                        jQuery('.net_sales .which').removeClass('up').addClass('down');
                        jQuery('.net_sales .which .by').html('-'+ res.netchange + '%');
                    }
    
                    //discount chart change
                    if(res.distype == 'up'){
                        jQuery('.zbs_discounts .which').removeClass('down').addClass('up');
                        jQuery('.zbs_discounts .which .by').html('+' + res.dischange + '%');
                    }else{
                        jQuery('.zbs_discounts .which').removeClass('up').addClass('down');
                        jQuery('.zbs_discounts .which .by').html('-'+res.dischange + '%');
                    }
    
                    //fee chanrt change
                    if(res.feetype == 'up'){
                        jQuery('.zbs_fee .which').removeClass('down').addClass('up');
                        jQuery('.zbs_fee .which .by').html('+' + res.feechange + '%');
                    }else{
                        jQuery('.zbs_fee .which').removeClass('up').addClass('down');
                        jQuery('.zbs_fee .which .by').html('-'+res.feechange + '%');
                    }
    
                    //average revenue
                    if(res.ave_type == 'up'){
                        jQuery('.ave_rev .which').removeClass('down').addClass('up');
                        jQuery('.ave_rev .which .by').html('+' + res.ave_change + '%');
                    }else{
                        jQuery('.ave_rev .which').removeClass('up').addClass('down');
                        jQuery('.ave_rev .which .by').html('-' + res.ave_change + '%');    
                    }
    
    
                    //contacts added in period
                    if(res.cust_type == 'up'){
                        jQuery('.zbs_newcust .which').removeClass('down').addClass('up');
                        jQuery('.zbs_newcust .which .by').html('+' + res.cust_perc + '%');    
                    }else{
                        jQuery('.zbs_newcust .which').removeClass('up').addClass('down');
                        jQuery('.zbs_newcust .which .by').html('-'+ res.cust_perc + '%');
                    }
    
                    //total customers
                    if(res.cust_type_tot == 'up'){
                        jQuery('.zbs_totcust .which').removeClass('down').addClass('up');
                        jQuery('.zbs_totcust .which .by').html('+' + res.cust_perc_tot + '%');  
                    }else{
                        jQuery('.zbs_totcust .which').removeClass('up').addClass('down');
                        jQuery('.zbs_totcust .which .by').html('-' + res.cust_perc_tot + '%');  
                    }
    
    
                    //refunds
                    if(res.refund_type == 'up'){
                        jQuery('.zbs_refunds .which').removeClass('down').addClass('up');
                        jQuery('.zbs_refunds .which .by').html('+' + res.refund_perc + '%');  
                    }else{
                        jQuery('.zbs_refunds .which').removeClass('up').addClass('down');
                        jQuery('.zbs_refunds .which .by').html('-' + res.refund_perc + '%');  
                    }
    
    
                    //failed
                    if(res.failed_type == 'up'){
                        jQuery('.zbs_failed .which').removeClass('down').addClass('up');
                        jQuery('.zbs_failed .which .by').html('+' + res.failed_perc + '%');  
                    }else{
                        jQuery('.zbs_failed .which').removeClass('up').addClass('down');
                        jQuery('.zbs_failed .which .by').html('-' + res.failed_perc + '%');  
                    }
    
          
                })
                o.fail(function(res){
    
                });
    
    
        }
    
    
        cb(moment().subtract(30, 'days'), moment());
    
        jQuery('#reportrange').daterangepicker({
            ranges: {
               'Last 30 Days': [moment().subtract(30, 'days'), moment()],
               'Latest Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
               'Prior Month' : [moment().subtract(2, 'month').startOf('month'), moment().subtract(2, 'month').endOf('month')],
               'Last 3 Months': [moment().subtract(3, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
               'Last 6 Months': [moment().subtract(6, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
               'Last Year': [moment().subtract(1, 'year').startOf('month'), moment().subtract(1, 'month').endOf('month')]
             //  'All Time': [ window.zbs_min_trans_date , moment()],
            },
            maxDate: moment()
        }, cb);
    
    });
    