<?php /*  
Plugin Name: Opinion8
Plugin URI: http://www.epicplugins.com
Description: Opinion8 is a powerful user engagement plugin which lets you gather the opinions of your website visitors.
Version: 1.2
Author: Epic Plugins
http://www.epicplugins.com
*/

if ( ! defined( 'ABSPATH' ) ) exit;

if (version_compare(phpversion(), '5.4', '<')) {
                    echo '<div style="font-family: \'Open Sans\',sans-serif;">Opinion8 Requires PHP Version 5.4 or above, please ask web hosting provider to update your PHP!</div>';
	exit();	

}



        register_activation_hook(__FILE__,'op8_32d592d');
    register_deactivation_hook(__FILE__,'op8_0d');
    
    	add_action('init', 			'op8_35e0ac609');
    add_action('admin_menu', 	'op8_b63f'); 

global 	$opinion8_db_version,$opinion8_version;
		$opinion8_db_version 			= "1.0";
		$opinion8_version 				= "1.2";

global 	$opinion8_urls;
		$opinion8_urls['home'] 			= 'http://www.epicplugins.com';
		$opinion8_urls['support']		= 'http://epicplugins.com/help/';
		$opinion8_urls['docs'] 			= 'http://www.epicplugins.com'; 		$opinion8_urls['products'] 		= 'http://www.epicplugins.com';
		$opinion8_urls['affurlstem']	= 'http://codecanyon.net/item/opinion8-wordpress-polling-plugin/13747820';
		$opinion8_urls['affurldirect']  = 'http://opinion8plugin.com/';

global	$opinion8_slugs;
		$opinion8_slugs['home'] 		= "opinion8-plugin";
		$opinion8_slugs['app'] 			= "opinion8-app";
		$opinion8_slugs['settings'] 	= "opinion8-plugin-settings";
		$opinion8_slugs['whlang']		= "opinion8-whlang";
		$opinion8_slugs['whstyles']		= "opinion8-whstyles";
		$opinion8_slugs['pollmanager']	= "opinion8-pollmanager";

global  $opinion8_instances;
		$opinion8_instances['c'] = 0;
		$opinion8_instances['instances'] = array();


global $whLangsupport;
	   $whLangsupport['opinion8'] = 'opinion8_Settings'; 

define( 'OPINION8_PATH', plugin_dir_path(__FILE__) );
define( 'OPINION8_URL', plugin_dir_url(__FILE__) );

global $wpo8_bgimggalleryimgs;
$wpo8_bgimggalleryimgs = array(

		array(
				'url' => OPINION8_URL.'i/bgsets/blur-1.jpg',
				'name' => 'Blur #1'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/blur-2.jpg',
				'name' => 'Blur #2'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/blur-3.jpg',
				'name' => 'Blur #3'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/blur-4.jpg',
				'name' => 'Blur #4'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/blur-5.jpg',
				'name' => 'Blur #5'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/blur-6.jpg',
				'name' => 'Blur #6'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-1.jpg',
				'name' => 'Poly #1'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-2.jpg',
				'name' => 'Poly #2'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-3.jpg',
				'name' => 'Poly #3'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-4.jpg',
				'name' => 'Poly #4'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/pattern-1.jpg',
				'name' => 'Patterned #1'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/pattern-2.jpg',
				'name' => 'Patterned #2'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/pattern-3.jpg',
				'name' => 'Patterned #3'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/pattern-4.jpg',
				'name' => 'Patterned #4'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-wild-1.jpg',
				'name' => 'Wild Poly #1'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-wild-2.jpg',
				'name' => 'Wild Poly #2'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-wild-3.jpg',
				'name' => 'Wild Poly #3'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-wild-4.jpg',
				'name' => 'Wild Poly #4'
			),

		array(
				'url' => OPINION8_URL.'i/bgsets/poly-wild-5.jpg',
				'name' => 'Wild Poly #5'
			),
		

	);

if(!class_exists('Opinion8Settings')) require_once(OPINION8_PATH . 'includes/Opinion8.Options.php');
if(!class_exists('Opinion8Widget')) require_once(OPINION8_PATH . 'includes/Opinion8.Widget.php');
if(!function_exists('opinion8__Metabox')) require_once(OPINION8_PATH . 'includes/Opinion8.MetaBoxes.php');
if(!function_exists('op8_1633b0')) require_once(OPINION8_PATH . 'includes/wh.langsupport.lib.php');
if(!function_exists('op8_6669b77f34')) require_once(OPINION8_PATH . 'includes/wh.styles.lib.php');

global $opinion8_Settings; $opinion8_Settings = new Opinion8Settings();

function op8_32d592d(){
	
	global $opinion8_version, $opinion8_db_version, $opinion8_Settings;	
						if (!is_array($opinion8_Settings->getAll())){
			
			add_action('admin_notices','op8_4e32639f');function op8_4e32639f(){echo '<div class="error"><p>Opinion8 Plugin Could not create its options object!</p></div>';}
			
		}
				
}


function op8_0d(){

		global $opinion8_Settings;		
}



function op8_35e0ac609(){
  
	global $opinion8_slugs, $opinion8_Settings; 
		$settings = $opinion8_Settings->getAll();

		op8_3d1dfed20b();
			
			wp_enqueue_script("jquery");
	
		if (!is_admin()){

						
				wp_enqueue_script('opinion8pubjs',		plugins_url('/js/Opinion8.min.js',__FILE__),array('jquery'));
		wp_enqueue_style('opinion8pubcss', 	plugins_url('/css/Opinion8.min.css',__FILE__) );

				wp_localize_script( 'opinion8pubjs', 'op8AJAX', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));  

		
				
						wp_enqueue_style('wh-fa-v4-4-0-css', plugins_url('/css/font-awesome.min.css',__FILE__) );

						wp_enqueue_script('wh-cookies-v1-2-2-js',		plugins_url('/js/cookies.min.js',__FILE__),array('jquery'));


	} else {
	
				if (op8_53b()) {

						wp_enqueue_style('wh-fa-v4-4-0-css', plugins_url('/css/font-awesome.min.css',__FILE__) );
			wp_enqueue_style('opinion8admcss', 	plugins_url('/css/Opinion8Admin.min.css',__FILE__) );

						
						wp_enqueue_script('wh-spectrum-v1-5-1-js',		plugins_url('/js/spectrum.min.js',__FILE__),array('jquery'));
			wp_enqueue_style('wh-spectrum-v1-5-1-css', 	plugins_url('/css/spectrum.min.css',__FILE__) );

		}	

				if (op8_1b8()){

						

									if (
				(isset($_GET['post_type']) && $_GET['post_type'] == 'opinion8') || 
				(isset($_GET['post']) && get_post_type($_GET['post']) == 'opinion8')
				) {

								wp_enqueue_style('opinion8admeditcss', 	plugins_url('/css/Opinion8Admin.editpage.min.css',__FILE__) );
				wp_enqueue_style('wh-fa-v4-4-0-css', plugins_url('/css/font-awesome.min.css',__FILE__) );

								wp_enqueue_media();

								
								wp_enqueue_script('wh-spectrum-v1-5-1-js',		plugins_url('/js/spectrum.min.js',__FILE__),array('jquery'));
				wp_enqueue_style('wh-spectrum-v1-5-1-css', 		plugins_url('/css/spectrum.min.css',__FILE__) );

												add_filter( 'post_updated_messages', 'op8_8a65de2888' );

			}

		} else {
		
		
		}

		

		if ( get_user_option('rich_editing') == 'true') {
			
			
		}

	}
	
		
		if(!class_exists('opinion8__pollList')) require_once(OPINION8_PATH . 'includes/Opinion8.pollList.php');
		

		op8_c1fa();

}

add_action('plugins_loaded', 'op8_2f0b4');
function op8_2f0b4() {
	load_plugin_textdomain( 'opinion8', false, dirname( plugin_basename(__FILE__) ) . '/lang/' );
}


add_action( 'wp_footer', 'op8_34' );
function op8_34(){
   
		global $opinion8_instances, $opinion8_Settings;

	$settings = $opinion8_Settings->getAll();

		if (function_exists('op8_adf29')) echo '<script>'.op8_adf29('opinion8','opinion8_Settings').'</script>';

		if (count($opinion8_instances['c']) > 0){ 
			echo '<style type="text/css">';

						echo op8_e39ec();

					    if (isset($settings['css_override']) && !empty($settings['css_override'])) echo op8_4e413affef($settings['css_override']);

	    	echo '</style>';

	}

}

function op8_793f138(){

	global $opinion8_Settings;	
	$settings = $opinion8_Settings->getAll();

	$showOpenSans = $settings['opensans'];

		if ($showOpenSans) ?><link rel='stylesheet' id='open-sans-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&#038;subset=latin%2Clatin-ext&#038;ver=4.1' type='text/css' media='all' /><?php

}
add_action('wp_head','op8_793f138');


function op8_b63f() {

	global $opinion8_slugs; 	add_menu_page( 'Opinion8 Plugin ', 'Opinion8', 'manage_options', $opinion8_slugs['home'], 'op8_b05', plugins_url('i/icon.png',__FILE__));
    add_submenu_page( $opinion8_slugs['home'], 'Settings', 'Settings', 'manage_options', $opinion8_slugs['settings'], 'op8_a933bd310' );
    
        add_submenu_page( $opinion8_slugs['home'], 'Styles', 'Styles', 'manage_options', $opinion8_slugs['whstyles'], 'op8_5e40e74d' );
    add_submenu_page( $opinion8_slugs['home'], 'Language', 'Language', 'manage_options', $opinion8_slugs['whlang'], 'op8_b7a108b975' );
    

    	$allPollsPage = remove_submenu_page( 'edit.php?post_type=opinion8', 'edit.php?post_type=opinion8' );

        add_submenu_page( 'edit.php?post_type=opinion8', op8_922f3('Manage Polls','opinion8'), op8_922f3('Manage Polls','opinion8'), 'manage_options', $opinion8_slugs['pollmanager'], 'op8_4bae136536' );
    
            
    	    	global $submenu;

    	    	
    		    $arr = array();
	    $arr[] = $submenu['edit.php?post_type=opinion8'][16];
	    $arr[] = $submenu['edit.php?post_type=opinion8'][10];
	    $arr[] = $submenu['edit.php?post_type=opinion8'][15];
	    $submenu['edit.php?post_type=opinion8'] = $arr;


}





function op8_3d1dfed20b() {


	
	  	  $labels = array(
	    'name' => op8_c7e( 'Poll Tags', 'Poll Tags', 'opinion8' ),
	    'singular_name' => op8_c7e( 'Poll Tag', 'Poll Tag', 'opinion8' ),
	    'search_items' =>  op8_922f3( 'Search Poll Tags', 'opinion8' ),
	    'popular_items' => op8_922f3( 'Popular Poll Tags', 'opinion8' ),
	    'all_items' => op8_922f3( 'All Poll Tags', 'opinion8' ),
	    'parent_item' => null,
	    'parent_item_colon' => null,
	    'edit_item' => op8_922f3( 'Edit Poll Tag', 'opinion8' ), 
	    'update_item' => op8_922f3( 'Update Poll Tag', 'opinion8' ),
	    'add_new_item' => op8_922f3( 'Add New Poll Tag' , 'opinion8'),
	    'new_item_name' => op8_922f3( 'New Poll Tag Name' , 'opinion8'),
	    'separate_items_with_commas' => op8_922f3( 'Separate Poll Tags with commas', 'opinion8' ),
	    'add_or_remove_items' => op8_922f3( 'Add or remove Poll Tags' , 'opinion8'),
	    'choose_from_most_used' => op8_922f3( 'Choose from the most used Poll Tags', 'opinion8' ),
	    'menu_name' => op8_922f3( 'Poll Tags', 'opinion8' ),
	  ); 

	  register_taxonomy('opinion8tag','opinion8',array( 
	    'hierarchical' => false,
	    'labels' => $labels,
	    'show_ui' => true,
	    'update_count_callback' => '_update_post_term_count',
	    'query_var' => true,
	    'rewrite' => array( 'slug' => 'tag' ),
	  ));



	$labels = array(
		'name'                => op8_c7e( 'Opinion8 Polls', 'Opinion8 Polls', 'opinion8' ),
		'singular_name'       => op8_c7e( 'Opinion8 Poll', 'Opinion8 Poll', 'opinion8' ),
		'menu_name'           => op8_922f3( 'Opinion8 Polls', 'opinion8' ),
		'name_admin_bar'      => op8_922f3( 'Opinion8 Polls', 'opinion8' ),
		'parent_item_colon'   => op8_922f3( 'Parent Opinion8 Poll:', 'opinion8' ),
		'all_items'           => op8_922f3( 'All Opinion8 Polls', 'opinion8' ),
		'add_new_item'        => op8_922f3( 'Add New Opinion8 Poll', 'opinion8' ),
		'add_new'             => op8_922f3( 'Add New', 'opinion8' ),
		'new_item'            => op8_922f3( 'New Opinion8 Poll', 'opinion8' ),
		'edit_item'           => op8_922f3( 'Edit Opinion8 Poll', 'opinion8' ),
		'update_item'         => op8_922f3( 'Update Opinion8 Poll', 'opinion8' ),
		'view_item'           => op8_922f3( 'View Opinion8 Poll', 'opinion8' ),
		'search_items'        => op8_922f3( 'Search Opinion8 Polls', 'opinion8' ),
		'not_found'           => op8_922f3( 'No Opinion8 Polls Found', 'opinion8' ),
		'not_found_in_trash'  => op8_922f3( 'Opinion8 Poll Not found in Trash', 'opinion8' ),
	);
	$args = array(
		'label'               => op8_922f3( 'Opinion8 Poll', 'opinion8' ),
		'description'         => op8_922f3( 'Opinion8 Opinion8 Poll', 'opinion8' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'taxonomies'),
		'hierarchical'        => false,
		'public'              => false, 
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => plugins_url('/i/icon.png', __FILE__),		'show_in_admin_bar'   => true,
		'show_in_nav_menus'   => false,
		'can_export'          => false,
		'has_archive'         => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => false,
		'capability_type'     => 'page',
		'taxonomies' 			=> array('opinion8tag')
	);
	register_post_type( 'opinion8', $args );
	
}




function op8_481da8($subpage=''){

	global $wpdb, $opinion8_urls, $opinion8_version,$opinion8_Settings;		
	if (!current_user_can('manage_options'))  { wp_die( op8_922f3('You do not have sufficient permissions to access this page.','opinion8') ); }
    
    
?>
<div id="sgpBody">
    <div class="wrap"> 
	    <div id="icon-sb" class="icon32"><br /></div><h2>Opinion8<?php if (!empty($subpage)) echo ': '.$subpage; ?></h2> 
    </div>
    <div id="sgpHeader">
		<a href="<?php echo $opinion8_urls['home']; ?>" title="Opinion8 Plugin Homepage" target="_blank">Opinion8 Plugin</a> | 
		<?php if (!empty($opinion8_urls['support'])) { ?><a href="<?php echo $opinion8_urls['support']; ?>" title="Opinion8 Plugin <?php op8_9ede5841ed('Support Page','opinion8'); ?>" target="_blank"><?php op8_9ede5841ed('Support','opinion8'); ?></a> | <?php } ?>
		<!--<?php if (!empty($opinion8_urls['docs'])) { ?><a href="<?php echo $opinion8_urls['docs']; ?>" title="View Documentation" target="_blank">Documentation</a> | <?php } ?>-->
		<?php if (!empty($opinion8_urls['products'])) { ?><a href="<?php echo $opinion8_urls['products']; ?>" title="<?php op8_9ede5841ed('More Plugins','opinion8'); ?>" target="_blank"><?php op8_9ede5841ed('More Plugins','opinion8'); ?></a> | <?php } ?>
		<?php $ulj = $opinion8_Settings->get('updatelistjoin'); if (!empty($opinion8_urls['updatelist']) && empty($ulj)) { ?><a href="<?php echo $opinion8_urls['updatelist']; ?>" title="<?php op8_9ede5841ed('Get Notified About Updates','opinion8'); ?>" target="_blank"><?php op8_9ede5841ed('Get Notified About Updates','opinion8'); ?></a> | <?php } ?>
	
        Version <?php echo $opinion8_version; ?>        
    </div>
    <div id="Opinion8AdminPage">
    <?php 	
	
			
}


function op8_37dd7(){
    
	?></div><?php 	
	
}


function op8_b05() {
	
	global $wpdb, $opinion8_urls, $opinion8_version;		
	if (!current_user_can('manage_options'))  { wp_die( op8_922f3('You do not have sufficient permissions to access this page.','opinion8') ); }
    
	    op8_481da8();

		op8_b9a9(); 

		op8_37dd7();

?>
</div>
<?php 
}


function op8_a933bd310() {
	
	global $wpdb, $opinion8_urls, $opinion8_version;		
	if (!current_user_can('manage_options'))  { wp_die( op8_922f3('You do not have sufficient permissions to access this page.','opinion8') ); }
    
	    op8_481da8('Settings');
	
		op8_1143989b74();
	
		op8_37dd7();

?>
</div>
<?php 
}



function op8_b7a108b975() {
	
	global $opinion8_urls, $opinion8_version;		
	if (!current_user_can('manage_options'))  { wp_die( op8_922f3('You do not have sufficient permissions to access this page.','opinion8') ); }
    
	    op8_481da8('Language Overrides');
	
		echo op8_18af('opinion8','opinion8_Settings','Opinion8');
	
		op8_37dd7();

?>
</div>
<?php 
}


function op8_5e40e74d() {
	
	global $opinion8_urls, $opinion8_version;		
	if (!current_user_can('manage_options'))  { wp_die( op8_922f3('You do not have sufficient permissions to access this page.','opinion8') ); }
    
	    op8_481da8('Styles');
	
		echo op8_6669b77f34('opinion8','opinion8_Settings','Opinion8');
	
		op8_37dd7();

?>
</div>
<?php 
}



function op8_b9a9(){
	
	global $wpdb, $opinion8_Settings, $opinion8_db_version, $opinion8_version, $opinion8_urls, $opinion8_slugs;	
		$showFull = true; ?>
            
        <div id="sbSubPage" style="width:600px">
        <?php 

        if ($showFull) { 
        ?><h2 class="sbhomep"><?php op8_9ede5841ed('Welcome to Opinion8','opinion8'); ?></h2>
        	<p class="sbhomep"><?php op8_9ede5841ed('Opinion8 is the ultimate interactive poll builder. Using Opinion8 you can drive up engagement, while getting to know your audience!','opinion8'); ?></p>
        	<p class="sbhomep">To get started, check over <a href="?page=<?php echo $opinion8_slugs['settings']; ?>">the settings</a>, and then you can <a href="post-new.php?post_type=opinion8">build your first Poll</a>, insert it into a post or page via shortcode, and start polling!</p>
        	
        	<p class="sbhomep">
        		<strong><?php op8_9ede5841ed('Get Started:','opinion8'); ?></strong><br /><br />
            	<button type="button" class="button button-primary button-large" onclick="javascript:window.location='?page=<?php echo $opinion8_slugs['settings']; ?>';"><?php op8_9ede5841ed('View Settings','opinion8'); ?></button>&nbsp;&nbsp;
            	<button type="button" class="button button-primary button-large" onclick="javascript:window.location='edit.php?post_type=opinion8&page=opinion8-pollmanager';"><?php op8_9ede5841ed('Manage Polls','opinion8'); ?></button>&nbsp;&nbsp;
            	<button type="button" class="button button-success button-large" onclick="javascript:window.location='post-new.php?post_type=opinion8';"><?php op8_9ede5841ed('Create Poll','opinion8'); ?></button>&nbsp;&nbsp;
            </p>
		</div><?php 

		} 
}



function op8_1143989b74(){
    	
	global $wpdb, $opinion8_Settings, $opinion8_db_version, $opinion8_version, $opinion8_urls, $opinion8_slugs;	
	$confirmAct = false;
	$settings = $opinion8_Settings->getAll();

		if (isset($_POST['editwplf'])){

				$updatedSettings = array();

				$updatedSettings['opensans'] = -1; if (isset($_POST['wpo8_opensans'])) $updatedSettings['opensans'] = 1;

				$updatedSettings['css_override'] = ''; if (isset($_POST['wpo8_css_override'])) $updatedSettings['css_override'] = op8_9b0cb4f6($_POST['wpo8_css_override']);

				$updatedSettings['sharefb'] = -1; if (isset($_POST['wpo8_sharefb'])) $updatedSettings['sharefb'] = 1;
		$updatedSettings['sharetw'] = -1; if (isset($_POST['wpo8_sharetw'])) $updatedSettings['sharetw'] = 1;
		$updatedSettings['sharepin'] = -1; if (isset($_POST['wpo8_sharepin'])) $updatedSettings['sharepin'] = 1;
		$updatedSettings['sharegp'] = -1; if (isset($_POST['wpo8_sharegp'])) $updatedSettings['sharegp'] = 1;


				$updatedSettings['fbappid'] = ''; if (isset($_POST['wpo8_fbappid'])) $updatedSettings['fbappid'] = sanitize_text_field($_POST['wpo8_fbappid']);
		
				$updatedSettings['twvia'] = ''; if (isset($_POST['wpo8_twvia'])) $updatedSettings['twvia'] = sanitize_text_field($_POST['wpo8_twvia']);

				$updatedSettings['logviews'] = -1; if (isset($_POST['wpo8_logviews'])) $updatedSettings['logviews'] = 1;
		
				$updatedSettings['poweredby'] = -1; if (isset($_POST['wpo8_poweredby'])) $updatedSettings['poweredby'] = 1;
		$updatedSettings['poweredbyuser'] = ''; if (isset($_POST['wpo8_poweredbyuser'])) $updatedSettings['poweredbyuser'] = sanitize_text_field($_POST['wpo8_poweredbyuser']);


				foreach ($updatedSettings as $k => $v) $opinion8_Settings->update($k,$v);

				$sbupdated = true;

				$settings = $opinion8_Settings->getAll();
			
	}

		if (isset($_GET['resetsettings'])) if ($_GET['resetsettings']==1){


		if (!isset($_GET['imsure'])){

								$confirmAct = true;
				$actionStr 				= 'resetsettings';
				$actionButtonStr 		= op8_922f3('Reset Settings to Defaults?','opinion8');
				$confirmActStr 			= op8_922f3('Reset All Opinion8 Settings?','opinion8');
				$confirmActStrShort 	= op8_922f3('Are you sure you want to reset these settings to the defaults?','opinion8');
				$confirmActStrLong 		= op8_922f3('Once you reset these settings you cannot retrieve your previous settings.','opinion8');

			} else {


				if (wp_verify_nonce( $_GET['_wpnonce'], 'resetclearopinion8' ) ){

												$opinion8_Settings->resetToDefaults();

												$settings = $opinion8_Settings->getAll();

												$sbreset = true;

				}

			}

	} 


	if (!$confirmAct){

	?>
    
        <p id="sbDesc"><?php op8_9ede5841ed('Below you can choose global settings for Opinion8.','opinion8'); ?></p>

        <?php if (isset($sbupdated)) if ($sbupdated) { echo '<div style="width:500px; margin-left:20px;" class="wmsgfullwidth">'; op8_b7b7(0,op8_922f3('Settings Updated','opinion8')); echo '</div>'; } ?>
        <?php if (isset($sbreset)) if ($sbreset) { echo '<div style="width:500px; margin-left:20px;" class="wmsgfullwidth">'; op8_b7b7(0,op8_922f3('Settings Reset','opinion8')); echo '</div>'; } ?>
        
        <div id="sbA">
        	<!--<pre><?php ?></pre>-->

        		<form method="post" action="?page=<?php echo $opinion8_slugs['settings']; ?>">
        			<input type="hidden" name="editwplf" id="editwplf" value="1" />
        			 <table class="table table-bordered table-striped wtab" style="width:780px;margin:10px;">
	               
	                   <thead>
	                    
	                        <tr>
	                            <th colspan="2" class="wmid"><?php op8_9ede5841ed('Social Share Settings','opinion8'); ?>:</th>
	                        </tr>

	                    </thead>
	                    
	                    <tbody>

	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_sharefb"><?php op8_9ede5841ed("Enable Facebook Sharing",'opinion8'); ?></label> <i class="fa fa-facebook-square"></i><br />
	                    			<?php op8_9ede5841ed("Show option to share via Facebook in Sharebox (shown after voting on a poll)",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="checkbox" class="form-control winput" name="wpo8_sharefb" id="wpo8_sharefb"<?php if (isset($settings['sharefb']) && $settings['sharefb'] == 1) echo ' checked="checked"'; ?> value="1" /></td>
	                    	</tr>

	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_fbappid"><?php op8_9ede5841ed("Facebook App ID",'opinion8'); ?></label> <i class="fa fa-facebook-square"></i><br />
	                    			<?php op8_9ede5841ed("To use Facebook Sharing for your polls, you'll need to create a facebook App <a href=\"https://developers.facebook.com\">here</a> and enter the ID here.",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="text" class="form-control winput" name="wpo8_fbappid" id="wpo8_fbappid" value="<?php if (isset($settings['fbappid'])) echo $settings['fbappid']; ?>" placeholder="e.g. 1552932821645200" style="font-size: 30px;line-height: 30px;height: 50px;width: 300px;" /></td>
	                    	</tr>

	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_sharetw"><?php op8_9ede5841ed("Enable Twitter Sharing",'opinion8'); ?></label> <i class="fa fa-twitter-square"></i><br />
	                    			<?php op8_9ede5841ed("Show option to share via Twitter in Sharebox (shown after voting on a poll)",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="checkbox" class="form-control winput" name="wpo8_sharetw" id="wpo8_sharetw"<?php if (isset($settings['sharetw']) && $settings['sharetw'] == 1) echo ' checked="checked"'; ?> value="1" /></td>
	                    	</tr>

	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_twvia"><?php op8_9ede5841ed("Tweet @via",'opinion8'); ?></label> <i class="fa fa-twitter-square"></i><br />
	                    			<?php op8_9ede5841ed("Add a '@via' handle here and then all poll tweet-outs will be via @yourhandle.",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="text" class="form-control winput" name="wpo8_twvia" id="wpo8_twvia" value="<?php if (isset($settings['twvia'])) echo $settings['twvia']; ?>" placeholder="e.g. @epicplugins" style="font-size: 30px;line-height: 30px;height: 50px;width: 300px;" /></td>
	                    	</tr>


	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_sharepin"><?php op8_9ede5841ed("Enable Pinterest Sharing",'opinion8'); ?></label> <i class="fa fa-pinterest-square"></i><br />
	                    			<?php op8_9ede5841ed("Show option to share via Pinterest in Sharebox (shown after voting on a poll)",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="checkbox" class="form-control winput" name="wpo8_sharepin" id="wpo8_sharepin"<?php if (isset($settings['sharepin']) && $settings['sharepin'] == 1) echo ' checked="checked"'; ?> value="1" /></td>
	                    	</tr>


	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_sharegp"><?php op8_9ede5841ed("Enable Google+ Sharing",'opinion8'); ?></label> <i class="fa fa-google-plus-square"></i><br />
	                    			<?php op8_9ede5841ed("Show option to share via Google+ in Sharebox (shown after voting on a poll)",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="checkbox" class="form-control winput" name="wpo8_sharegp" id="wpo8_sharegp"<?php if (isset($settings['sharegp']) && $settings['sharegp'] == 1) echo ' checked="checked"'; ?> value="1" /></td>
	                    	</tr>


	                    </tbody>

	                </table>
        			 <table class="table table-bordered table-striped wtab" style="width:780px;margin:10px;">
	               
	                   <thead>
	                    
	                        <tr>
	                            <th colspan="2" class="wmid"><?php op8_9ede5841ed('General Settings','opinion8'); ?>:</th>
	                        </tr>

	                    </thead>
	                    
	                    <tbody>

	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_opensans"><?php op8_9ede5841ed("Auto-include of Open Sans Font",'opinion8'); ?></label><br />
	                    			<?php op8_9ede5841ed("If you'd like your polls to use the font 'Open Sans', checking this box will add a reference to Google Fonts within the header of your website and Polls will automatically use this font.",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="checkbox" class="form-control winput" name="wpo8_opensans" id="wpo8_opensans"<?php if (isset($settings['opensans']) && $settings['opensans'] == 1) echo ' checked="checked"'; ?> value="1" /></td>
	                    	</tr>

	                    	<tr>
	                    		<td class="wfieldname" style="width:300px"><label for="wpo8_css_override"><?php op8_9ede5841ed("CSS Override",'opinion8'); ?></label><br />
	                    		<?php op8_9ede5841ed("Any custom CSS you enter here will be included in the footer, after all Opinion8 styles. This lets you override the plugins built-in CSS if you, (or your developer), needs to.",'opinion8'); ?>
	                    	</td>
	                    		<td><textarea class="form-control" style="height:100px" name="wpo8_css_override" id="wpo8_css_override"><?php if (isset($settings['css_override'])) echo $settings['css_override']; ?></textarea></td>
	                    	</tr>


	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_logviews"><?php op8_9ede5841ed("Enable View Count Logging",'opinion8'); ?></label><br />
	                    			<?php op8_9ede5841ed("Log view counts for any page loaded which includes an Opinion8 Poll.",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="checkbox" class="form-control winput" name="wpo8_logviews" id="wpo8_logviews"<?php if (isset($settings['logviews']) && $settings['logviews'] == 1) echo ' checked="checked"'; ?> value="1" /></td>
	                    	</tr>

	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_poweredby"><?php op8_9ede5841ed("Enable 'Powered By' logo",'opinion8'); ?></label><br />
	                    			<?php op8_9ede5841ed("Enable the Opinion8 logo, and enter your username below and start earning Affiliate money with Envato",'opinion8'); ?>
	                    		</td>
	                    		<td><input type="checkbox" class="form-control winput" name="wpo8_poweredby" id="wpo8_poweredby"<?php if (isset($settings['poweredby']) && $settings['poweredby'] == 1) echo ' checked="checked"'; ?> value="1" /></td>
	                    	</tr>


	                    	<tr>
	                    		<td class="wfieldname" style="width:300px">
	                    			<label for="wpo8_poweredbyuser"><?php op8_9ede5841ed("Envato Username",'opinion8'); ?></label><br />
	                    			<?php op8_9ede5841ed("Add your Envato username here to earn money with the Envato Affiliate scheme.",'opinion8'); ?> (<a href="http://codecanyon.net/affiliate_program" target="_blank"><?php op8_9ede5841ed('Read More','opinion8'); ?></a>)
	                    		</td>
	                    		<td><input type="text" class="form-control winput" name="wpo8_poweredbyuser" id="wpo8_poweredbyuser" value="<?php if (isset($settings['poweredbyuser'])) echo $settings['poweredbyuser']; ?>" placeholder="e.g. epicplugins" style="font-size: 30px;line-height: 30px;height: 50px;width: 300px;" /></td>
	                    	</tr>



	                    </tbody>

	                </table>

	                <table class="table table-bordered table-striped wtab" style="width:780px;margin:10px;">
	               		<tbody>

	                    	<tr>
	                    		<td colspan="2" class="wmid"><button type="submit" class="button button-primary button-large"><?php op8_9ede5841ed('Save Settings','opinion8'); ?></button></td>
	                    	</tr>

	                    </tbody>
	                </table>

	            </form>


	            <table class="table table-bordered table-striped wtab" style="width:780px;margin:10px;margin-top:40px;">
	               
	                   <thead>
	                        <tr>
	                            <th class="wmid">Opinion8 Plugin: <?php op8_9ede5841ed('Extra Tools','opinion8'); ?></th>
	                        </tr>
	                    </thead>
	                    
	                    <tbody>
	                    	<tr>
	                    		<td>
	                    			<p style="padding: 10px;text-align:center;">
		                    			<button type="button" class="button button-primary button-large" onclick="javascript:window.location='?page=<?php echo $opinion8_slugs['settings']; ?>&resetsettings=1';"><?php op8_9ede5841ed('Restore default settings','opinion8'); ?></button>
		                    		</p>
		                    	</td>
	                    	</tr>
	                    </tbody>
	            </table>
	            
   		</div><?php 
   		
   		} else {

   				?><div id="clpSubPage" class="whclpActionMsg six">
        		<p><strong><?php echo $confirmActStr; ?></strong></p>
            	<h3><?php echo $confirmActStrShort; ?></h3>
            	<?php echo $confirmActStrLong; ?><br /><br />
            	<button type="button" class="button button-primary button-large" onclick="javascript:window.location='<?php echo wp_nonce_url('?page='.$opinion8_slugs['settings'].'&'.$actionStr.'=1&imsure=1','resetclearopinion8'); ?>';"><?php echo $actionButtonStr; ?></button>
            	<button type="button" class="button button-large" onclick="javascript:window.location='?page=<?php echo $opinion8_slugs['settings']; ?>';"><?php op8_9ede5841ed("Cancel",'opinion8'); ?></button>
            	<br />
				</div><?php 
   		} 

}

function op8_a8d06($v){
	if (isset($v)) echo $v; 
}









add_action( 'wp_ajax_opinion8v', 'op8_7e' );
add_action( 'wp_ajax_nopriv_opinion8v', 'op8_7e' );
function op8_7e() {
	
	
		global $opinion8_Settings;
	$settings = $opinion8_Settings->getAll();

		check_ajax_referer( 'wpo8-ajax-nonce', 'sec' );

		if (isset($_POST['pollid']) && !empty($_POST['pollid'])){

				$res = array();

				$pollID = (int)sanitize_text_field($_POST['pollid']);
		$pageID = (int)sanitize_text_field($_POST['pid']);
		$answerID = (int)sanitize_text_field($_POST['aid']);
		$userIP = op8_1cc9ac1();

				$existingRes = op8_71($pollID);

		if (isset($existingRes['ippool']) && is_array($existingRes['ippool'])){

						if (!in_array($userIP,$existingRes['ippool'])){

								$newResults = $existingRes; $votedOn = false; $votedOnIndx = -1;
				if (isset($newResults['poll_c']['a'.$answerID])) {
					$newResults['poll_c']['a'.$answerID] = $newResults['poll_c']['a'.$answerID] + 1;
					$votedOn = $newResults['poll_c']['a'.$answerID];
					$votedOnIndx = 'a'.$answerID;
				} else {
										$newResults['poll_c']['a'.$answerID] = 1;
					$votedOnCount = $newResults['poll_c']['a'.$answerID];
					$votedOnIndx = 'a'.$answerID;
				}
								$newResults['ippool'][] = $userIP;

								if (isset($pageID) && !empty($pageID) && !in_array($pageID,$newResults['seenon'])) $newResults['seenon'][] = $pageID;
		
								$newResults['lastvote'] = time();

								$updatedState = op8_51c51($pollID,$newResults);

								$res['results'] = $newResults['poll_c'];
				$res['voted_on'] = $votedOn;
				$res['voted_on_indx'] = $votedOnIndx;


			} else {

								$res['results'] = $existingRes['poll_c'];
				$res['voted_on'] = false;
				$res['voted_on_indx'] = false;

			}

		} else {

						$res = array('error'=>'Results');

		}

	} else $res = array('error'=>'None');

	header('Content-Type: application/json');
	echo json_encode($res);
	exit();

}


add_action( 'wp_ajax_opinion8t', 'op8_a44aa51427' );
add_action( 'wp_ajax_nopriv_opinion8t', 'op8_a44aa51427' );
function op8_a44aa51427() {
	
	
		global $opinion8_Settings;
	$settings = $opinion8_Settings->getAll();

		check_ajax_referer( 'wpo8-ajax-nonce', 'sec' );

		$res = array();

		if (isset($_POST['pollid']) && !empty($_POST['pollid'])){

				$pollID = (int)sanitize_text_field($_POST['pollid']);
		$pageID = (int)sanitize_text_field($_POST['pid']);
		$responseText = sanitize_text_field(nl2br($_POST['at']));
		$userIP = op8_1cc9ac1();

				$pollObj = op8_24c7($pollID);

		if (isset($pollObj['id'])){

			$pollFeedbackTo = ''; if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['textrecipient'])) $pollFeedbackTo = $pollObj['p_meta']['textrecipient'];

			if (!empty($pollFeedbackTo)){

				$pollQuestion = ''; if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['pollquestion'])) $pollQuestion = $pollObj['p_meta']['pollquestion'];
				$pollName = ''; if (isset($pollObj['name'])) $pollQuestion = $pollObj['name'];
				$fromPageName = 'Unknown'; if (!empty($pageID)) $fromPageName = get_the_title($pageID);

								$subject = 'Opinion8: Text Feedback';
				$headers = "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

				$message = '<html><body>';
				$message .= '<h2>Text Feedback received from Opinion8 Poll on '.get_bloginfo('name').'</h2>';
				$message .= '<hr />';
				$message .= '<strong>Poll Question:</strong> '.$pollQuestion.'<br />';
				$message .= '<strong>Text Feedback:</strong> '.$responseText.'<br />';
				$message .= '<hr />';
				$message .= '<strong>From Poll:</strong> '.$pollName.'<br />';
				$message .= '<strong>On Page:</strong> '.$fromPageName.' (ID: '.$pageID.')<br />';
				$message .= '<strong>View/Edit Poll:</strong> <a href="'.admin_url( 'post.php?post='.$pollObj['id'].'&action=edit' ).'">'.admin_url( 'post.php?post='.$pollObj['id'].'&action=edit' ).'</a><br />';
				$message .= '<hr />';
				$message .= '<strong>Users IP:</strong> '.$userIP.'<br />';
				$message .= '<hr />';
				$message .= 'This enquiry was generated by a user entering text feedback into an Opinion8 Poll on '.op8_4c340b1d0(get_bloginfo('wpurl')).' at '.date("F j, Y, g:i a");		
				$message .= '</body></html>';

				$res = array('rec'=>wp_mail($pollFeedbackTo, $subject, $message, $headers));

			} else $res = array('error'=>'NoRec');

		} else $res = array('error'=>'NotLegit');
	
	} else $res = array('error'=>'None');

	header('Content-Type: application/json');
	echo json_encode($res);
	exit();

}


function op8_a61308b($pollID){

	if (isset($_COOKIE['op8voted_'.$pollID])) return true;
	return false;
	
}

function op8_fc655($pollID){

	if (isset($_COOKIE['op8voted_'.$pollID])) return (int)$_COOKIE['op8voted_'.$pollID];
	return false;
	
}










function op8_24c7($pid=-1,$withFullDetails=false,$withTags=false,$withResults=false,$withViewCount=false){

	if ($pid !== -1){

				$pObj = get_post( $pid ); 		
				$ret = array(
				'id' 			=> 	$pObj->ID,
				'name' 			=> 	$pObj->post_title,
				'p_meta'		=> 	get_post_meta($pObj->ID, 'p_meta', true),
				'p_choices'		=> 	get_post_meta($pObj->ID, 'p_choices', true)
			);

				if ($withTags)  $ret['p_tags'] = get_the_terms($pObj->ID,'opinion8tag');

				if ($withResults) $ret['p_results'] = get_post_meta($pObj->ID, 'p_results', true);

				if ($withViewCount) $ret['p_v'] = get_post_meta($pObj->ID, 'p_v', true);

		return $ret;

	} else return false;

}

function op8_71($pid=-1){

	if ($pid !== -1){
		
		return get_post_meta($pid, 'p_results', true);

	} else return false;

}


function op8_ac($withFullDetails=false,$perPage=10,$page=0){

				if ($perPage < 0) $perPage = 10; else $perPage = (int)$perPage;

		$args = array (
			'post_type'              => 'opinion8',
			'post_status'            => 'publish',
			'posts_per_page'         => $perPage,
			'order'                  => 'DESC',
			'orderby'                => 'post_date'
		);
		
				$actualPage = $page-1; if ($actualPage < 0) $actualPage = 0;
		if ($actualPage > 0) $args['offset'] = $perPage*$actualPage;

		$pollList = get_posts( $args );

		$ret = array();

		foreach ($pollList as $pollEle){

			$retObj = array(

				'id' => 	$pollEle->ID,
				'name' => 	$pollEle->post_title,
				'created' => $pollEle->post_date_gmt

			);

						if ($withFullDetails) {
				
				$retObj['p_meta'] 		= get_post_meta($pollEle->ID, 'p_meta', true);
				$retObj['p_choices'] 	= get_post_meta($pollEle->ID, 'p_choices', true);
				$retObj['p_tags'] 		= get_the_tags($pollEle->ID);
				$retObj['p_results'] 	= get_post_meta($pollEle->ID, 'p_results', true);
								$retObj['p_v'] 			= get_post_meta($pollEle->ID, 'p_v', true);

			}

			$ret[] = $retObj;

		}

		return $ret;

}

function op8_e8899fc08(){

	$counts = wp_count_posts('opinion8');

	if (isset($counts) && isset($counts->publish)) return (int)$counts->publish;

	return 0;

}

function op8_70742($pid=-1,$tags=-1,$noRelatedReq=3){

	$res = array(); $includedResIDS = array();

	
		if ($tags !== -1 && is_array($tags)){

				if (count($tags) > 0){

						$maxTries = 4; $tryCounter = 0;


						while (count($res) < $noRelatedReq && $tryCounter < $maxTries && isset($tags[$tryCounter])){

				
				$relatedPolls = op8_b68($tags[$tryCounter]->slug,$pid);

				if (count($relatedPolls) > 0) foreach ($relatedPolls as $rPoll){

										$pollLevelBlock = false; 
					if (
						(isset($rPoll['p_meta']) && isset($rPoll['p_meta']['increlated']) && $rPoll['p_meta']['increlated'] != 1) ||
						(isset($rPoll['p_meta']) && !isset($rPoll['p_meta']['increlated']))
						) $pollLevelBlock = true;

					if (!in_array($rPoll['id'],$includedResIDS) && $rPoll['id'] != $pid && count($res) < $noRelatedReq && !$pollLevelBlock){
						$res[] = $rPoll;
						$includedResIDS[] = $rPoll['id'];
					}

				}

				$tryCounter++;
			}


		}


	}
	
	return $res;
}

function op8_b68($tag,$excludePollID,$perPage=10,$page=0,$withFullDetails=false){


				if ($perPage < 0) $perPage = 10; else $perPage = (int)$perPage;

		$args = array (
			'post_type'              => 'opinion8',
			'post_status'            => 'publish',
			'posts_per_page'         => $perPage,
			'order'                  => 'DESC',
			'orderby'                => 'post_date',
			'tax_query' => array(
				array(
					'taxonomy' => 'opinion8tag',
					'field' => 'slug',
					'terms' => $tag
				)
			)
		);
		
				$actualPage = $page-1; if ($actualPage < 0) $actualPage = 0;
		if ($actualPage > 0) $args['offset'] = $perPage*$actualPage;

		$pollList = get_posts( $args );

		$ret = array();

		foreach ($pollList as $pollEle){

			$retObj = array(

				'id' => 	$pollEle->ID,
				'name' => 	$pollEle->post_title,

			);
			
						$retObj['p_meta'] 		= get_post_meta($pollEle->ID, 'p_meta', true);

						if ($withFullDetails) {
				
				$retObj['p_choices'] 	= get_post_meta($pollEle->ID, 'p_choices', true);
				$retObj['p_tags'] 		= get_the_tags($pollEle->ID);
				$retObj['p_results'] 	= get_post_meta($pollEle->ID, 'p_results', true);

								$retObj['p_v'] 			= get_post_meta($pollEle->ID, 'p_v', true);

			}

			$ret[] = $retObj;

		}

		return $ret;

}

function op8_51c51($pid=-1,$resObj=-1){

	if ($pid !== -1 && is_array($resObj)){

        return update_post_meta($pid, 'p_results', $resObj);

	} 

	return false;

}

function op8_4921($pid=-1,$pCount=-1){

	if ($pid !== -1 && $pCount !== -1){

        return update_post_meta($pid, 'p_v', $pCount);

	} 

	return false;

}


function op8_8a7f($attrs){

	global $opinion8_instances, $opinion8_Settings;

	$settings = $opinion8_Settings->getAll();

        $opID = -1; if (isset($attrs['pollid'])) $opID = (int)$attrs['pollid'];
        
                $opinion8Poll = op8_24c7($opID,true,true,true,true);

        $opinion8_instances['c']++;
    	$opinion8Instance = $opinion8_instances['c'];

        $opinion8HTML = '';
        

    if (isset($opinion8Poll) && isset($opinion8Poll['id'])){

                    	if (isset($settings['logviews']) && $settings['logviews'] == 1){

		        if (isset($opinion8Poll['p_v'])){
		        	
		        	$newViewCount = ((int)$opinion8Poll['p_v'])+1;

		        } else $newViewCount = 1;
		        op8_4921($opinion8Poll['id'],$newViewCount);

		}

		
			
						$userIP = op8_1cc9ac1();
						$existingRes = $opinion8Poll['p_results'];

			if (isset($existingRes['ippool']) && is_array($existingRes['ippool']) && in_array($userIP,$existingRes['ippool'])){

				
								$reloadAction = 'none'; if (isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['postvotereload'])) $reloadAction = $opinion8Poll['p_meta']['postvotereload'];

			} 				

															        	if (isset($attrs['raovr'])) $reloadAction = 'statshare';

    	
						if (
				(isset($reloadAction) && $reloadAction != 'hide') ||
				!isset($reloadAction)
				){


	    			    		$opinion8HTML = '<div class="opinion8poll" id="opinion8poll_'.$opID.'_'.$opinion8Instance.'" data-opinion8pollid="'.$opinion8Poll['id'].'">'; 
	    				    			if (isset($settings['poweredby']) && $settings['poweredby'] == 1){

	    				global $opinion8_urls;

	    				if (isset($settings['poweredbyuser']) && !empty($settings['poweredbyuser'])) 
	    					$poweredByURL = $opinion8_urls['affurlstem'].'?ref='.sanitize_text_field($settings['poweredbyuser']);
	    				else
	    					$poweredByURL = $opinion8_urls['affurldirect'];


	    					    				$opinion8HTML .= '<div class="opinion8PoweredBy"><a href="'.$poweredByURL.'" target="_blank">'.op8_922f3('Powered By','opinion8').' Op<div class="op8Logo">&infin;</div></a></div>';

	    			}

	    			
	    					    				$opBGImg = '';
	    				if (isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['bgimgurl']) && !empty($opinion8Poll['p_meta']['bgimgurl'])){

	    						    					if (substr($opinion8Poll['p_meta']['bgimgurl'],0,11) == 'background:'){

	    							    						
	    							    						$bgimgurl = substr($opinion8Poll['p_meta']['bgimgurl'],11);

	    							    						$opBGImg = '<img src="'.$bgimgurl.'" alt="Opinion8 Poll" />';

	    					} else $opBGImg = '<img src="'.$opinion8Poll['p_meta']['bgimgurl'].'" alt="Opinion8 Poll" />';
	    				}
	    				$opinion8HTML .= '<div class="opinion8BG">'.$opBGImg.'<div class="opinion8BGShade"></div></div>';

	    				    			$op8globfontstyles = ''; if (isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['textcolour'])) $op8globfontstyles = 'color:'.$opinion8Poll['p_meta']['textcolour'];
	    				    			$op8answerfontstyles = ''; if (isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['answerscolour'])) $op8answerfontstyles = 'color:'.$opinion8Poll['p_meta']['answerscolour'];
	    		
	    				    			$op8AlreadyVoted = false; if (op8_a61308b($opID)) $op8AlreadyVoted = true; 

	    								$op8ShareSettings = array('fb'=>false,'tw'=>false,'gp'=>false,'pin'=>false); 
					if (isset($settings['sharefb']) && $settings['sharefb'] == 1) {
						if (isset($settings['fbappid']) && !empty($settings['fbappid'])){
	    					$op8ShareSettings['fbappid'] = $settings['fbappid'];
	    					$op8ShareSettings['fb'] = true;
	    				}
					}
					if (isset($settings['sharetw']) && $settings['sharetw'] == 1) 	$op8ShareSettings['tw'] = true;
					if (isset($settings['sharepin']) && $settings['sharepin'] == 1) $op8ShareSettings['pin'] = true;
					if (isset($settings['sharegp']) && $settings['sharegp'] == 1) 	$op8ShareSettings['gp'] = true;


										$op8StyleOverridesForJS = array();

												$opinion8StyleOverrides = array(); 
						if (isset($settings['whstyles']) && isset($settings['whstyles']['useoverrides']) && $settings['whstyles']['useoverrides'] == 1) 
							if (isset($settings['whstyles']['overrides']) && count($settings['whstyles']['overrides']) > 0)
								$opinion8StyleOverrides = $settings['whstyles']['overrides'];

					if (count($opinion8StyleOverrides) > 0){

						$op8DefaultsStyleOvrs = array();			

												if (isset($opinion8StyleOverrides['choicebutton'])) $op8DefaultsStyleOvrs['choicebutton'] = $opinion8StyleOverrides['choicebutton']['v'];
						if (isset($opinion8StyleOverrides['submitbutton'])) $op8DefaultsStyleOvrs['submitbutton'] = $opinion8StyleOverrides['submitbutton']['v'];


						if (count($op8DefaultsStyleOvrs) > 0) $op8StyleOverridesForJS = $op8DefaultsStyleOvrs;
					} else {

												$op8DefaultsStyleOvrs['choicebutton'] = 'pure-button';
						$op8DefaultsStyleOvrs['submitbutton'] = 'pure-button';

					}

	    				    			$op8PollPageClasses = ''; if ($op8AlreadyVoted) $op8PollPageClasses = ' op8alreadyVoted';

	    				    			$opinion8HTML .= '<div class="opinion8PollPage'.$op8PollPageClasses.'">';

	    					    				$op8Q = ''; if (isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['pollquestion'])) $op8Q = $opinion8Poll['p_meta']['pollquestion'];
	    				$opinion8HTML .= '<div class="opinion8Question" style="'.$op8globfontstyles.'">'.op8_4e413affef($op8Q).'</div>';
	    				
	    					    				$op8BiLine = ''; if (isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['biline'])) $op8BiLine = $opinion8Poll['p_meta']['biline'];
	    				$opinion8HTML .= '<div class="opinion8Biline" style="'.$op8globfontstyles.'">'.op8_4e413affef($op8BiLine).'</div>';

	    					    				$op8Type = 'multi'; if (isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['type'])) $op8Type = $opinion8Poll['p_meta']['type'];

	    					    				$op8CustomHTMLDump = '';

	    				if ($op8Type == 'multi'){

	    					if ($op8AlreadyVoted){

	    							    						$opinion8HTML .= '<div class="opinion8NextPage"><div><i class="fa fa-share"></i></div></div>';

	    					} else {

		    							    					if (isset($opinion8Poll['p_choices']) && is_array($opinion8Poll['p_choices']) && count($opinion8Poll['p_choices']) > 0){

		    								    						$opinion8HTML .= '<div class="opinion8Choices">';

		    									    							$pChoiceIndx = 1;
		    							foreach ($opinion8Poll['p_choices'] as $pChoice){


		    										    								$pChoiceUID = 'opC_'.$opID.'_'.$opinion8Instance.'_'.$pChoiceIndx.'_custom';

		    										    								$pChoiceRedir = ''; if (isset($pChoice['redirurl']) && !empty($pChoice['redirurl'])) $pChoiceRedir = $pChoice['redirurl'];

		    										    								$choiceButtonClass = ''; if (isset($op8StyleOverridesForJS) && isset($op8StyleOverridesForJS['choicebutton'])) $choiceButtonClass = ' '.$op8StyleOverridesForJS['choicebutton'];

		    										    								$opinion8HTML .= '<div class="opinion8Choice'.$choiceButtonClass.'" data-op8cind="'.$pChoiceIndx.'" data-op8next="'.$pChoice['outcome'].'" data-op8outcomeid="'.$pChoiceUID.'"';
		    								if (!empty($pChoiceRedir)) $opinion8HTML .= ' data-op8redir="'.$pChoiceRedir.'"';
		    								$opinion8HTML .= '>';

		    									
		    											    									$opinion8HTML .= op8_4e413affef($pChoice['txt']);

		    											    									if (!empty($pChoice['customhtml'])) $op8CustomHTMLDump .= '<div id="'.$pChoiceUID.'" class="op8CustomOutcome">'.op8_4e413affef($pChoice['customhtml']).'</div>';


				    										    						$opinion8HTML .= '</div>';

				    						$pChoiceIndx++;

		    							}

		    								    						$opinion8HTML .= '<div class="wpo8Clr"></div></div>';


		    					} else $opinion8HTML .= '<div class="op8NonChoice">Opinion8: No choices found!</div>';

		    				}

	    				} else {

	    						    						
	    							    						$opinion8HTML .= '<div class="opinion8TextChoice">';

																		$textinpButtonClass = ''; if (isset($op8StyleOverridesForJS) && isset($op8StyleOverridesForJS['submitbutton'])) $textinpButtonClass = ' '.$op8StyleOverridesForJS['submitbutton'];

	    								    							$opinion8HTML .= '<textarea></textarea><br /><button type="button" class="button'.$textinpButtonClass.'">'.op8_922f3('Send Feedback','opinion8').'</button>';

	    							    						$opinion8HTML .= '<div class="wpo8Clr"></div></div>';


	    				}



	    			$opinion8HTML .= '<div class="wpo8Clr"></div></div>';

	    				    			$opinion8HTML .= '<div class="opinion8PollPageResults"><div class="opinion8PageWrap">';

	    				$op8ResultTitle = $op8Q; if (empty($op8ResultTitle)) $op8ResultTitle = op8_922f3('Poll Results','opinion8');

	    				$opinion8HTML .= '<div class="opinion8Title" style="'.$op8globfontstyles.'">'.$op8ResultTitle.'</div>';
	    				$opinion8HTML .= '<div class="opinion8ResultWrap">';

	    						    						    						    					if (isset($reloadAction) && $reloadAction == 'statshare'){

	    						
		    					if (isset($opinion8Poll['p_choices']) && is_array($opinion8Poll['p_choices']) && count($opinion8Poll['p_choices']) > 0){

		    						$votedOnIndex = op8_fc655($opinion8Poll['id']);

		    									    							$pResultIndx = 0; $totalVotes = 0; foreach ($opinion8Poll['p_choices'] as $pChoice){ if (isset($opinion8Poll['p_results']) && isset($opinion8Poll['p_results']['poll_c']) && isset($opinion8Poll['p_results']['poll_c']['a'.$pResultIndx])){ $totalVotes += (int)$opinion8Poll['p_results']['poll_c']['a'.$pResultIndx]; } $pResultIndx++; }

		    									    							$pResultIndx = 0;
		    							foreach ($opinion8Poll['p_choices'] as $pChoice){

		    										    								$voteCount = 0; $growthPerc = 0;
		    								if (isset($opinion8Poll['p_results']) && isset($opinion8Poll['p_results']['poll_c']) && isset($opinion8Poll['p_results']['poll_c']['a'.$pResultIndx])){
		    									
		    									$voteCount = (int)$opinion8Poll['p_results']['poll_c']['a'.$pResultIndx];
		    									if ($voteCount > 0 && $totalVotes > 0) $growthPerc = round((($voteCount/$totalVotes)*100),2);

		    								}

		    								$opinion8HTML .= '<div class="opinion8ResultBar';
		    										    								if ($votedOnIndex == $pResultIndx) $opinion8HTML .= ' opinion8Choosen';
		    								$opinion8HTML .= '" data-op8-growthfactor="'.$growthPerc.'" data-op8cid="'.$pResultIndx.'">';
		    								$opinion8HTML .= '<div class="opinion8BarGhost"></div>';
		    								$opinion8HTML .= '<div class="opinion8BarFill op8toGrowOrNotToGrow" style="width: 0%"></div>';
		    								$opinion8HTML .= '<div class="opinion8BarText">';
		    								$opinion8HTML .= '<div class="op8Label">'.op8_4e413affef($pChoice['txt']).'</div><span class="op8Perc">'.$growthPerc.'%</span></div></div>';



				    						$pResultIndx++;
				    					}



	        				}


	        			}

	    				$opinion8HTML .= '</div>';
	    				$opinion8HTML .= '<div class="opinion8NextPage"><div><i class="fa fa-share"></i></div></div>';

	    				    			$opinion8HTML .= '<div class="wpo8Clr"></div></div></div>';


	    				    			$opinion8HTML .= '<div class="opinion8PollPageShareRelated">';

	    					    				$opinion8HTML .= '<div class="opinion8PrevPage" style="display:none"><div><i class="fa fa-reply"></i></div></div>';
	    				
	    			$opinion8HTML .= '<div class="opinion8PageWrap">';

	    					    				if (
	    					$op8ShareSettings['fb'] ||
	    					$op8ShareSettings['tw'] || 
	    					$op8ShareSettings['pin'] ||
	    					$op8ShareSettings['gp']
	    					) {

	    						    					$opinion8HTML .= '<div class="opinion8ShareWrap">';

		    							    					$opinion8HTML .= '<div class="opinion8Title" style="'.$op8globfontstyles.'">'.op8_922f3('Your Opinion Counts!','opinion8').'</div><div class="opinion8peeps" style="'.$op8globfontstyles.'">'.op8_922f3('Share this poll to see what your friends think:','opinion8').'</div>';

		    							    						$op8pollshareData = array(
		    						
		    							'url' => get_permalink(),
		    							'title' => $op8Q, 		    							'twvia' => ''
		    						);
		    						if (isset($settings['twvia'])) $op8pollshareData['twvia'] = $settings['twvia'];
		    						if (empty($op8pollshareData['title'])) $op8pollshareData['title'] = get_the_title();

		    							    					$opinion8HTML .= '<div class="opinion8ShareButtons" data-op8s-url="'.$op8pollshareData['url'].'" data-op8s-title="'.$op8pollshareData['title'].'" data-op8s-twvia="'.$op8pollshareData['twvia'].'">';

		    						if ($op8ShareSettings['fb']) $opinion8HTML .= '<div class="opinion8ShareButton op8shareFB"><i class="fa fa-facebook"></i></div>';
		    						if ($op8ShareSettings['tw']) $opinion8HTML .= '<div class="opinion8ShareButton op8shareTW"><i class="fa fa-twitter"></i></div>';
		    						if ($op8ShareSettings['pin']) $opinion8HTML .= '<div class="opinion8ShareButton op8sharePIN"><i class="fa fa-pinterest-p"></i></div>';
		    						if ($op8ShareSettings['gp']) $opinion8HTML .= '<div class="opinion8ShareButton op8shareGP"><i class="fa fa-google-plus"></i></div>';


	    						$opinion8HTML .= '</div>';



		    					    					$opinion8HTML .= '<div class="wpo8Clr"></div></div>';


	    				}


	    				$opinion8HTML .= '<div class="opinion8Title opinion8TitleRelated" style="'.$op8globfontstyles.'">'.op8_922f3('Related Polls:','opinion8').'</div>';

	    					    				$opinion8HTML .= '<div class="opinion8RelatedPolls">';

	    						    					$relatedPolls = op8_70742($opID,$opinion8Poll['p_tags']);

	    					if (count($relatedPolls) > 0) { foreach ($relatedPolls as $relatedPoll){

	    						$relatedQ = ''; if (isset($relatedPoll['p_meta']) && isset($relatedPoll['p_meta']['pollquestion'])) $relatedQ = $relatedPoll['p_meta']['pollquestion'];
	    						$relatedBG = ''; if (isset($relatedPoll['p_meta']) && isset($relatedPoll['p_meta']['bgimgurl'])) $relatedBG = $relatedPoll['p_meta']['bgimgurl'];
	    						$relatedURL = '#'; if (isset($relatedPoll['p_meta']) && isset($relatedPoll['p_meta']['relatedurl'])) $relatedURL = $relatedPoll['p_meta']['relatedurl']; 

		    							    					if (substr($relatedBG,0,11) == 'background:'){

		    								    						
		    								    						$relatedBG = substr($relatedBG,11);

		    					} 

	    							    						if (!empty($relatedBG)) $relatedBGStyles = ' style="background:url('.$relatedBG.') 0 0 no-repeat;background-size: cover;"';

	    						$opinion8HTML .= '<div class="opinion8RelatedPoll"'.$relatedBGStyles.' data-op8-pollurl="'.$relatedURL.'"><div class="opinion8RelatedFade"></div><div class="opinion8RelatedTitle">'.op8_4e413affef($relatedQ).'</div></div>';

	    					} } else {

	    						$opinion8HTML .= '<div class="opinion8NoRelatedPoll">'.op8_922f3('No Related Polls!','opinion8').'</div>';

	    					}

							    				$opinion8HTML .= '<div class="wpo8Clr"></div></div>';


	    				    			$opinion8HTML .= '<div class="wpo8Clr"></div></div></div>';

	    				    			$opinion8HTML .= '<div class="opinion8PollPageCustom" style="'.$op8globfontstyles.'"><div class="opinion8PageWrap">'.$op8CustomHTMLDump.'<div class="wpo8Clr"></div></div></div>';



	    				    			if (
	    				isset($reloadAction) && $reloadAction == 'html' &&
	    				isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['postvotereload_customhtml'])
	    				){

	    				$postVoteCustomHTML = '<div id="opinion8PostVoteReloadCustomHTML_'.$opID.'_'.$opinion8Instance.'" class="opinion8PostVoteReloadCustomHTML">'.op8_4e413affef($opinion8Poll['p_meta']['postvotereload_customhtml']).'</div>';
	    				

	    				$opinion8HTML .= '<div class="opinion8PostVoteReloadPageCustom" style="'.$op8globfontstyles.'"><div class="opinion8PageWrap">'.$postVoteCustomHTML.'<div class="wpo8Clr"></div></div></div>';

	    			}



	    		
	    				    			$op8scriptExtra = ''; 
	    			$op8scriptClosingExtra = '';

	    					    				$op8scriptExtra = 'var wpo8globcfg = '.json_encode(array('share'=>$op8ShareSettings,'style'=>$op8StyleOverridesForJS)).';';

		    		
		    			if (isset($reloadAction)){
		    				$op8scriptExtra = 'if (typeof window.op8JSPostLoad == "undefined") var op8JSPostLoad = [];';

														switch ($reloadAction){

								case 'none':

									break;
								case 'statshare':

									#$op8scriptClosingExtra .= "function op8JS_postLoad(){op8_4f3ac9d('statshare','opinion8poll_".$opID."_".$opinion8Instance."');}";
									$op8scriptExtra .= "function op8JJSPL".$opID."_".$opinion8Instance."(){op8_4f3ac9d('statshare','opinion8poll_".$opID."_".$opinion8Instance."');}";
									$op8scriptExtra .= "window.op8JSPostLoad.push('op8JJSPL".$opID."_".$opinion8Instance."');";

									break;
								case 'share':

									#$op8scriptClosingExtra .= "function op8JS_postLoad(){op8_4f3ac9d('share','opinion8poll_".$opID."_".$opinion8Instance."');}";
									$op8scriptExtra .= "function op8JJSPL".$opID."_".$opinion8Instance."(){op8_4f3ac9d('share','opinion8poll_".$opID."_".$opinion8Instance."');}";
									$op8scriptExtra .= "window.op8JSPostLoad.push('op8JJSPL".$opID."_".$opinion8Instance."');";

									break;
								case 'html':

									#$op8scriptClosingExtra .= "function op8JS_postLoad(){op8_4f3ac9d('html','opinion8poll_".$opID."_".$opinion8Instance."');}";
									$op8scriptExtra .= "function op8JJSPL".$opID."_".$opinion8Instance."(){op8_4f3ac9d('html','opinion8poll_".$opID."_".$opinion8Instance."');}";
									$op8scriptExtra .= "window.op8JSPostLoad.push('op8JJSPL".$opID."_".$opinion8Instance."');";


									break;
								case 'redir':
									if (
					    				isset($opinion8Poll['p_meta']) && isset($opinion8Poll['p_meta']['postvotereload_redirurl'])
				    				){
										
										$op8scriptClosingExtra .= "window.location = '".op8_4e413affef($opinion8Poll['p_meta']['postvotereload_redirurl'])."'";
									}

									break;
								
									
							}

						}



	    				    			$opinion8HTML .= '<script type="text/javascript">'.$op8scriptExtra.'var wpo8PID = "'.get_the_ID().'";var wpo8AN = "'.wp_create_nonce( "wpo8-ajax-nonce" ).'";op8_baade4ac70(\'opinion8poll_'.$opID.'_'.$opinion8Instance.'\');'.$op8scriptClosingExtra.'</script>';

	    			    		$directCSSOverrides = '';
	    		if (!empty($op8answerfontstyles)){

	    			$directCSSOverrides .= '.opinion8poll .opinion8PollPageResults .opinion8PageWrap .opinion8ResultWrap .opinion8ResultBar .opinion8BarText div.op8Label {'.$op8answerfontstyles.'}';

	    		}
	    		if (!empty($directCSSOverrides)) $opinion8HTML .= '<style type="text/css">'.$directCSSOverrides.'</style>';

	    						$opinion8HTML .= '<div class="wpo8Clr"></div></div>';

		} else $opinion8HTML = ''; 
    } else $opinion8HTML .= '<div class="op8Error">Opinion8: No Poll Found with ID: '.$opID.'</div>';


    return $opinion8HTML;

}
add_shortcode( 'Opinion8', 'op8_8a7f' );




		function op8_72($attrs){

	global $opinion8_instances, $opinion8_Settings;

	$settings = $opinion8_Settings->getAll();

        $opID = -1; if (isset($attrs['pollid'])) $opID = (int)$attrs['pollid'];
        
        
    return do_shortcode('[Opinion8 pollid='.$opID.' raovr="true"]');

}
add_shortcode( 'Opinion8Results', 'op8_72' );

function op8_adabdd5ed5(){

		$polls = op8_ac(false,50);
	if (count($polls) > 0){

		shuffle($polls);

		return do_shortcode('[Opinion8 pollid='.$polls[0]['id'].']');

	}

	return '<div class="alert">Opinion8 for WordPress: No Polls Found';

}
add_shortcode( 'Opinion8Random', 'op8_adabdd5ed5' );












function op8_e39ec(){

	global $opinion8_Settings;

	$settings = $opinion8_Settings->getAll();

		if (isset($settings['whstyles']) && isset($settings['whstyles']['useoverrides']) && $settings['whstyles']['useoverrides'] == 1){

				if (isset($settings['whstyles']['overrides']) && count($settings['whstyles']['overrides']) > 0){

			
						$ovr = $settings['whstyles']['overrides'];

						$overrideCSS = '';
			
						$overrideCSS .= '.opinion8poll .opinion8BG .opinion8BGShade {'
						 . op8_c10f377268($ovr['bgoverlayopacity']['v'],true)
						 						 						 .'}';
			
			
						$overrideCSS .= '.opinion8poll .opinion8PollPageResults .opinion8PageWrap .opinion8ResultWrap .opinion8ResultBar .opinion8BarFill,'
						 . '.opinion8poll .opinion8PollPageResults .opinion8PageWrap .opinion8ResultWrap .opinion8ResultBar .opinion8BarGhost {'
						 . op8_5fec78e7c($ovr['barcolor']['v'],true)
						 .'}';
			$overrideCSS .= '.opinion8poll .opinion8PollPageResults .opinion8PageWrap .opinion8ResultWrap .opinion8ResultBar .opinion8BarText,'
						 . '.opinion8poll .opinion8PollPageResults .opinion8PageWrap .opinion8ResultWrap .opinion8ResultBar .opinion8BarText span {'
						 . op8_c6d8f06a($ovr['bartextcolor']['v'],true)
						 .'}';


						$overrideCSS .= '.opinion8poll .opinion8PollPageShareRelated .opinion8PageWrap .opinion8ShareWrap .opinion8ShareButtons .opinion8ShareButton {'
						 . op8_c6d8f06a($ovr['shareicocolor']['v'],true)
						 . op8_5fec78e7c($ovr['shareicobg']['v'],true)
						 .'}';
			$overrideCSS .= '.opinion8poll .opinion8PollPageShareRelated .opinion8PageWrap .opinion8ShareWrap .opinion8ShareButtons .opinion8ShareButton:hover {'
						 . op8_c6d8f06a($ovr['shareicohover']['v'],true)
						 . op8_5fec78e7c($ovr['shareicobghover']['v'],true)
						 .'}';






												$overrideCSS .= '@-webkit-keyframes LOADING {'
			  				. '	0%   {'
			  				. 'transform: scale(0.5);'
			  				. op8_5fec78e7c($ovr['loadinganibg2']['v'])
			  				. '  }'
			  				. '  50%   { '
			  				. 'transform: scale(1);'
			  				. op8_5fec78e7c($ovr['loadinganibg']['v'])
			  				. '  }'
			  				. '  100% { '
			  				. 'transform: scale(0.5);'
			  				. op8_5fec78e7c($ovr['loadinganibg2']['v'])
			  				. '  }'
			  				. '}'

			  				. '@-webkit-keyframes LOADINGREV {'
			    				. '0%   { '
			  				. 'transform: scale(0.5);'
			  				. op8_5fec78e7c($ovr['loadinganibg']['v'])
			  				. '  }'
			  				. '  50%   { '
			  				. 'transform: scale(1);'
			  				. op8_5fec78e7c($ovr['loadinganibg2']['v'])
			  				. '  }'
			  				. '  100% { '
			  				. 'transform: scale(0.5);'
			  				. op8_5fec78e7c($ovr['loadinganibg']['v'])
			  				. '  }'
			  				. '}';


						$overrideCSS .= '.op8LoadingWrap .op8LoadingEle li {' . op8_bd60010032($ovr['loadinganiborder']['v']) .'}';

						$overrideCSS .= '.op8LoadingBG {' 
						. op8_c10f377268($ovr['loadingbgopacity']['v'],true)
						. op8_5fec78e7c($ovr['loadingbg']['v']) 
						.'}';


			return $overrideCSS;

		}

	} 

	return '';

}





function op8_13c69666a5( $buttons ) {
   array_push($buttons, "opinion8");
   return $buttons;
}
function op8_971f( $plugin_array ) {
   $plugin_array['opinion8'] = OPINION8_URL.'js/Opinion8AdminBar.js'; 
   return $plugin_array;
}

add_action('admin_head', 'op8_15605');
function op8_15605() {
    global $typenow;
        if ( !current_user_can('edit_posts') && !current_user_can('edit_pages') ) {
   	return;
    }
        if( ! in_array( $typenow, array( 'post', 'page' ) ) )
        return;
		if ( get_user_option('rich_editing') == 'true') {
		add_filter("mce_external_plugins", 'op8_971f');
		add_filter('mce_buttons', 'op8_13c69666a5');

			}
}

		function op8_87a2b3( $buttons ) {
	   array_push($buttons, "opinion8Results");
	   return $buttons;
	}
	function op8_ff74df5( $plugin_array ) {
	   $plugin_array['opinion8Results'] = OPINION8_URL.'js/Opinion8AdminBarResults.js'; 
	   return $plugin_array;
	}

	add_action('admin_head', 'op8_bd4c');
	function op8_bd4c() {
	    global $typenow;
	    	    if ( !current_user_can('edit_posts') && !current_user_can('edit_pages') ) {
	   	return;
	    }
	    	    if( ! in_array( $typenow, array( 'post', 'page' ) ) )
	        return;
				if ( get_user_option('rich_editing') == 'true') {
			add_filter("mce_external_plugins", 'op8_ff74df5');
			add_filter('mce_buttons', 'op8_87a2b3'); 
		}
	}
	function op8_c7( $buttons ) {
	   array_push($buttons, "opinion8Random");
	   return $buttons;
	}
	function op8_14( $plugin_array ) {
	   $plugin_array['opinion8Random'] = OPINION8_URL.'js/Opinion8AdminBarRandom.js'; 
	   return $plugin_array;
	}

	add_action('admin_head', 'op8_2abdfc');
	function op8_2abdfc() {
	    global $typenow;
	    	    if ( !current_user_can('edit_posts') && !current_user_can('edit_pages') ) {
	   	return;
	    }
	    	    if( ! in_array( $typenow, array( 'post', 'page' ) ) )
	        return;
				if ( get_user_option('rich_editing') == 'true') {
			add_filter("mce_external_plugins", 'op8_14');
			add_filter('mce_buttons', 'op8_c7'); 
		}
	}

function op8_23b352080(){

	if (op8_1b8()){

		
						$objArr = op8_ac(); 

						echo '<script type="text/javascript" id="wpo8settings">var wpo8URL = "'.OPINION8_URL.'";var wpop8URL = "'.OPINION8_URL.'";var wpopinion8WYSIWYGList = '.json_encode($objArr).';</script>';


	}

}
add_action('admin_head', 'op8_23b352080');








function op8_8a65de2888( $messages )
{
    unset($messages['post'][1]);
    unset($messages['post'][4]);
    unset($messages['post'][6]);
    return $messages;
}







function op8_1b8($new_edit = null){
    global $pagenow;
        if (!is_admin()) return false;


    if($new_edit == "edit")
        return in_array( $pagenow, array( 'post.php',  ) );
    elseif($new_edit == "new")         return in_array( $pagenow, array( 'post-new.php' ) );
    else         return in_array( $pagenow, array( 'post.php', 'post-new.php' ) );
}

function op8_53b(){
	
	global $opinion8_slugs;
	
	$isOurPage = false;	
	if (isset($_GET['page'])) if (in_array($_GET['page'],$opinion8_slugs)) $isOurPage = true; 
	
	return $isOurPage;
	
}

function op8_8cf51f904c($i){
	
	if ((int)$i > 999){
		return number_format($i);	
	} else {
		if (op8_74d5($i) > 2) return round($i,2); else return $i;	
	}
	
}

function op8_b0b84db($size) {
    $size = preg_replace('/[^0-9]/','',$size);
    $sizes = array("", "k", "m");
    if ($size == 0) { return('n/a'); } else {
    return (round($size/pow(1000, ($i = floor(log($size, 1000)))), 0) . $sizes[$i]); }
}


function op8_74d5($value)
{
	if ((int)$value == $value)
	{
		return 0;
	}
	else if (! is_numeric($value))
	{
		return false;
	}

	return strlen($value) - strrpos($value, '.') - 1;
}

function op8_5cc34fa2e($emailAddr){

	if (filter_var($emailAddr, FILTER_VALIDATE_EMAIL)) return true;

	return false;

}



function op8_3b2d(){
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}     

function op8_1cc9ac1()
{
		if (!empty($_SERVER['HTTP_CLIENT_IP']))
	{
		$ip=$_SERVER['HTTP_CLIENT_IP'];
	}
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
	{
		$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	}
	else
	{
		$ip=$_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}

function op8_30($key){

	global $opinion8_Settings;
	return $opinion8_Settings->get($key);

}


function op8_b7b7($flag,$msg,$includeExclaim=false){
	
    if ($includeExclaim){ $msg = '<div id="sgExclaim">!</div>'.$msg.''; }
    

    if ($flag == -1){
		echo '<div class="fail wrap whAlert-box">'.$msg.'</div>';
	} 
	if ($flag == 0){
		echo '<div class="success wrap whAlert-box">'.$msg.'</div>';	
	}
	if ($flag == 1){
		echo '<div class="warn wrap whAlert-box">'.$msg.'</div>';	
	}
    if ($flag == 2){
        echo '<div class="info wrap whAlert-box">'.$msg.'</div>';
    }

    
}


function op8_9b0cb4f6($title){
	return htmlentities(stripslashes($title),ENT_QUOTES,'UTF-8');
} 
function op8_4e413affef($title){
	return html_entity_decode($title,ENT_QUOTES,'UTF-8');
} 




function op8_310b2f34($html,$first,$nextStr,$fallbackCloser='</'){

	$f1 = strpos($html,$first);
	$f1end = $f1 + strlen($first);
	if ($f1){
		$f2 = strpos(substr($html,$f1end),$nextStr);
		if (!$f2){
						$f2 = strpos(substr($html,$f1end),$fallbackCloser);
		}
		if (!$f2) $f2 = strlen(substr($html,$f1end));
		return substr($html,$f1end,$f2);
	}

		return '';
}


function op8_4c340b1d0($url){

	$parsed = parse_url($url);
	if (isset($parsed['host'])) 
		$justDom = $parsed['host'];
	else
		$justDom = '';
		if (!isset($justDom) && !empty($parsed['path'])) 
		$justDom = $parsed['path'];

		$protos = array('http://','https://');
	$justDom = str_replace($protos,'',$justDom);

	return $justDom;

}


?>