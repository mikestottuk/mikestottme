<?php /* !
 * WH Plugin Styles Support
 * V1.0
 *
 * Copyright 2015, Epic Plugins, StormGate Ltd.
 *
 * Date: 25/09/15

	25/10/15 - added "opacity" option

 */







function op8_6669b77f34($dom,$settingsStr,$pluginName){

	

	global $$settingsStr;

	
		
		if (isset($$settingsStr) && isset($_POST['goUpdate'])){

			$whPStyleSettings = $$settingsStr->getAll();

						if (is_array($whPStyleSettings) && isset($whPStyleSettings['whstyles'])){

				
				$styleChanges = 0;

				
				$styleModule = $whPStyleSettings['whstyles'];

				
				
										if (isset($_POST['whs_basestyle'])){

						
						if ($_POST['whs_basestyle'] != $styleModule['basestyle']['v']) {
							$styleModule['basestyle']['v'] = sanitize_text_field($_POST['whs_basestyle']);
							$styleChanges++;
						}

					}

								
										if (isset($_POST['whs_useStyleOverrides']) && !$styleModule['useoverrides']){

						$styleModule['useoverrides'] = true;
						$styleChanges++;					

					}
					if (!isset($_POST['whs_useStyleOverrides']) && $styleModule['useoverrides']){

						$styleModule['useoverrides'] = false;
						$styleChanges++;					

					}
					 


				
				if (count($whPStyleSettings['whstyles']['overrides']) > 0) foreach ($whPStyleSettings['whstyles']['overrides'] as $styleOverrideKey => $styleOverrideObj){


						switch ($styleOverrideObj['opts']){

							case 'color':
							case 'textarea':
							case 'button':
							case 'opacity': 

								

																		if (isset($_POST['whs_ovr_'.$styleOverrideKey])){

										

										
										if ($_POST['whs_ovr_'.$styleOverrideKey] != $styleModule['overrides'][$styleOverrideKey]['v']) {
											$styleModule['overrides'][$styleOverrideKey]['v'] = op8_b0136c21($_POST['whs_ovr_'.$styleOverrideKey]);
											$styleChanges++;
										}
									}
							

								break;

							case 'font':

								
								if ( 
									isset($_POST['whs_ovr_'.$styleOverrideKey.'_1']) && 
									isset($_POST['whs_ovr_'.$styleOverrideKey.'_2']) 
									){

									
									$newVStr = sanitize_text_field($_POST['whs_ovr_'.$styleOverrideKey.'_1']).'|'.sanitize_text_field($_POST['whs_ovr_'.$styleOverrideKey.'_2']);

									
									if ($styleModule['overrides'][$styleOverrideKey]['v'] != $newVStr){
										$styleModule['overrides'][$styleOverrideKey]['v'] = $newVStr;
										$styleChanges++;
									}

								}

								break;

							case 'border':

								
								if ( 
									isset($_POST['whs_ovr_'.$styleOverrideKey.'_1']) && 
									isset($_POST['whs_ovr_'.$styleOverrideKey.'_2']) &&
									isset($_POST['whs_ovr_'.$styleOverrideKey.'_3'])
									){

									
									$newVStr = sanitize_text_field($_POST['whs_ovr_'.$styleOverrideKey.'_1']).'|'.sanitize_text_field($_POST['whs_ovr_'.$styleOverrideKey.'_2']).'|'.sanitize_text_field($_POST['whs_ovr_'.$styleOverrideKey.'_3']);

									
									if ($styleModule['overrides'][$styleOverrideKey]['v'] != $newVStr){
										$styleModule['overrides'][$styleOverrideKey]['v'] = $newVStr;
										$styleChanges++;
									}

								}

								break;


					}

				}

								if ($styleChanges > 0){

					
					$$settingsStr->update('whstyles',$styleModule);
					$whStyleUpdateStr = 'Styles Successfully Updated!';


				}

			} 

		} 


		
		if (isset($$settingsStr) && isset($_POST['loadstylesettings'])){

			

				$whStylesDefaultOverridesToLoad = sanitize_text_field($_POST['loadstylesettings']);

				
				$whPStyleSettings = $$settingsStr->getAll();

								if (is_array($whPStyleSettings) && isset($whPStyleSettings['whstyles'])){

										if (isset($whPStyleSettings['whstyles']['defaultoverridesvar']) && !empty($whPStyleSettings['whstyles']['defaultoverridesvar'])){

						
						$whPStylesDefaultOverridesVarName = $whPStyleSettings['whstyles']['defaultoverridesvar'];
						global $$whPStylesDefaultOverridesVarName;

						
						echo 'LOADING STYLES: '.$whStylesDefaultOverridesToLoad.'!<br />';

						$overridesDefaultsLocalised = $$whPStylesDefaultOverridesVarName;

						if (
							isset($overridesDefaultsLocalised['defaultoverrides']) &&
							isset($overridesDefaultsLocalised['defaultoverrides'][strtolower($whStylesDefaultOverridesToLoad)])
							){


							
							$whPStylesOverridesToLoad = $overridesDefaultsLocalised['defaultoverrides'][strtolower($whStylesDefaultOverridesToLoad)];

							
							$styleModule = $whPStyleSettings['whstyles'];
							$styleModule['useoverrides'] = true;
							$$settingsStr->update('whstyles',$styleModule);

						}


					}

				}

		}
			



	


	
	$retStr = '<div id="whStyleLibEditPage"><form method="post" id="whStyleForm"><input type="hidden" name="goUpdate" value="1" />';

				if (isset($whStyleUpdateStr)){

			$retStr .= op8_aa3069376(0,$whStyleUpdateStr);

		}

		
		$retStr .= '<p>Here you can choose an overall style for '.$pluginName.', or specifically override the styles for most front-end elements.</p>';

		
		$retStr .= '<table class="table table-bordered table-striped wtab" id="whStyleLibEditPageTab" style="display:none"><tbody>';


			
			if (isset($$settingsStr)){

				$whPStyleSettings = $$settingsStr->getAll();

								if (is_array($whPStyleSettings) && isset($whPStyleSettings['whstyles'])){


					
					if (isset($whPStyleSettings['whstyles']['basestyle']) && isset($whPStyleSettings['whstyles']['basestyle']['opts']) && count($whPStyleSettings['whstyles']['basestyle']['opts']) > 0){

						
						$retStr .= '<tr><th colspan="2" class="wmid">'.op8_922f3('Base Style',$dom).':</th></tr>';

						
						$cssPerc = round(100/(count($whPStyleSettings['whstyles']['basestyle']['opts'])+1),2);

						
						$retStr .= '<tr><td colspan="2"><div class="whStyleSelect">';


							$baseI = 1;
							foreach ($whPStyleSettings['whstyles']['basestyle']['opts'] as $opt){

								
								
								
								$retStr .= '<div class="whStyleOption whStyle-'.strtolower($opt).'" onclick="javascript:jQuery(\'#whs_basestyle_'.$baseI.'\').click();" style="width:'.( $cssPerc - 3 ).'%"></div>';

								$baseI++;
							}

							
							
							
							
							$retStr .= '<div class="whStyleOption whStyle-custom" onclick="javascript:jQuery(\'#whs_basestyle_custom\').click();" style="width:'.( $cssPerc - 3 ).'%"></div>';


						$retStr .= '</div></td></tr>';

						
						$retStr .= '<tr><td colspan="2"><div class="whStyleSelect">';

							$baseI = 1;
							foreach ($whPStyleSettings['whstyles']['basestyle']['opts'] as $opt){

								
								
								
								$retStr .= '<div class="whStyleOptionTitle" style="width:'.( $cssPerc - 3 ).'%"><span>'.$opt.'</span><br /><input type="radio" name="whs_basestyle" id="whs_basestyle_'.$baseI.'" value="'.$opt.'"';
								if ($whPStyleSettings['whstyles']['basestyle']['v'] == $opt) $retStr .= ' checked="checked"';
								$retStr .= ' /></div>';

								$baseI++;

							}

							
							
							
							
							$retStr .= '<div class="whStyleOptionTitle" style="width:'.( $cssPerc - 3 ).'%"><span>Custom</span><br /><input type="radio" name="whs_basestyle" id="whs_basestyle_custom" value="custom"';
							if ($whPStyleSettings['whstyles']['basestyle']['v'] == 'custom') $retStr .= ' checked="checked"';
							$retStr .= ' /></div>';

						$retStr .= '</div></td></tr>';


					} 

					
					$retStr .= '</tbody></table><table class="table table-bordered table-striped wtab" id="whStyleLibEditPageTab2" style="display:none"><tbody>';

					
					$retStr .= '<tr class="whStyleShow"><th colspan="2" class="whStyleCatHead">'.op8_922f3('Style Overrides',$dom).':';

					
						$retStr .= '<div style="text-align:right;line-height:26px;float:right;font-size:14px;width:200px;"><label for="useStyleOverrides" style="margin-bottom:3px;">Use Style Overrides</label> <input type="checkbox" id="useStyleOverrides" name="whs_useStyleOverrides" value="1"';
						$useStyleOverridesOnLoad = false; $useStyleOverrideClass = ''; 
						if (isset($whPStyleSettings['whstyles']['useoverrides']) && $whPStyleSettings['whstyles']['useoverrides'] == "1") {
							$retStr .= ' checked="checked"';
							$useStyleOverridesOnLoad = true;
							$useStyleOverrideClass = 'useOverrides';
						}
						$retStr .= ' class="form-control" style="margin:0;" /></div>';

					$retStr .= '</th></tr>';
					
					$retStr .= '<tr class="'.$useStyleOverrideClass.'"><th colspan="2"><div style="text-align:right;">Load Styles From: <select id="loadOverridesFrom">';
							$retStr .= '<option value="" disabled="disabled">----</option>';

							


							
							$retStr .= '<option value="custom"';
							
								$retStr .= ' selected="selected"';
							$retStr .='>Custom</option>';

							if (isset($whPStyleSettings['whstyles']) && isset($whPStyleSettings['whstyles']['basestyle']) && isset($whPStyleSettings['whstyles']['basestyle']['opts']) && count($whPStyleSettings['whstyles']['basestyle']['opts']) > 0)
							foreach ($whPStyleSettings['whstyles']['basestyle']['opts'] as $opt){
								$retStr .= '<option value="'.$opt.'"';
								
								$retStr .= '>'.$opt.'</option>';
							}
						$retStr .= '</select></div>';
					$retStr .= '</th></tr>';

					


						
						$overridesList = array('general'=>array('title'=>'General','items'=>array()));

						
						if (count($whPStyleSettings['whstyles']['overrides']) > 0) foreach ($whPStyleSettings['whstyles']['overrides'] as $styleOverrideKey => $styleOverrideObj){

														$cat = 'General'; if (isset($styleOverrideObj['cat'])) $cat = $styleOverrideObj['cat'];
							switch ($cat){

								
								case 'General':

									
									$overridesList['general']['items'][$styleOverrideKey] = $styleOverrideObj;

									break;

								
								default:

									
									$catmd5 = md5($cat);
									if (!isset($overridesList[$catmd5])) $overridesList[$catmd5] = array('title'=>$cat,'items'=>array());

									
									$overridesList[$catmd5]['items'][$styleOverrideKey] = $styleOverrideObj;								

									break;

							}

						}


						
						$whSBorderTypes = array('none','dotted','dashed','solid','double','groove','ridge','inset','outset');
						
						$whSFontSizes = array('32px','36px','48px','60px','72px','1em','1.1em','1.2em','1.3em','1.4em','1.5em','1.7em','2em');
						
						$whSButtons = array('pure-button','pure-button pure-button-active','pure-button pure-button-primary'
							,'pure-button pure-button-success'
							,'pure-button pure-button-error'
							,'pure-button pure-button-warning'
							,'pure-button pure-button-secondary'
							,'pure-button pure-button-purple'
							,'pure-button pure-button-brownround'
							,'pure-button pure-button-apple' );

						
						if (count($overridesList) > 0) foreach ($overridesList as $catKey => $cat) {

							if (count($cat['items']) > 0){

								
								$retStr .= '<tr class="'.$useStyleOverrideClass.'"><th colspan="2" class="whStyleCatHead whStyleCat-'.$catKey.'">'.op8_922f3($cat['title'],$dom).':</th></tr>';

								
								if (count($cat['items']) > 0) foreach ($cat['items'] as $ovrKey => $ovrItem){

									
									$ovrItemValue = ''; if (isset($ovrItem['v'])) $ovrItemValue = $ovrItem['v'];
									if (isset($whPStylesOverridesToLoad)){

										
										$ovrItemValue = $whPStylesOverridesToLoad[$ovrKey]['v'];

									}


									
									switch ($ovrItem['opts']){

										
										case 'textarea':

											$retStr .= '<tr class="'.$useStyleOverrideClass.'"><td class="whSOvrKey">'.$ovrItem['t'].'</td>';
											$retStr .= '<td><textarea name="whs_ovr_'.$ovrKey.'" class="styleOverride form-control">'.op8_dea0ad157($ovrItemValue).'</textarea></td></tr>';

											break;

										
										case 'color':

											$retStr .= '<tr class="'.$useStyleOverrideClass.'"><td class="whSOvrKey">'.$ovrItem['t'].'</td>';
											$retStr .= '<td><input name="whs_ovr_'.$ovrKey.'" id="whs_ovr_'.$ovrKey.'" class="styleOverride whsSpectrum" value="'.$ovrItemValue.'" /></td></tr>';

											break;

										
										case 'button':

											$retStr .= '<tr class="'.$useStyleOverrideClass.'"><td class="whSOvrKey">'.$ovrItem['t'].'</td>';
											$retStr .= '<td>';

												$buttonI = 1;
												if (count($whSButtons) > 0) foreach ($whSButtons as $buttonClass){

													$retStr .= '<div class="whSButtonChoice"><button type="button" class="'.$buttonClass.'" onclick="javascript:jQuery(\'#whs_ovr_'.$ovrKey.'_'.$buttonI.'\').click();">Button '.$buttonI.'</button><br />';
													$retStr .= '<input type="radio" name="whs_ovr_'.$ovrKey.'" id="whs_ovr_'.$ovrKey.'_'.$buttonI.'" value="'.$buttonClass.'"';
													if ($buttonClass == $ovrItemValue) $retStr .= ' checked="checked"';
													$retStr .= ' /></div>';

													$buttonI++;
												}

											$retStr .= '</td></tr>';

											break;

										
										case 'font':

											
											$ovrItemVals = array('',''); if (isset($ovrItemValue) && !empty($ovrItemValue) && strpos($ovrItemValue,'|')) $ovrItemVals = explode('|',$ovrItemValue);

											$retStr .= '<tr class="'.$useStyleOverrideClass.'"><td class="whSOvrKey">'.$ovrItem['t'].'</td>';
											$retStr .= '<td>';

					            				
					            				$retStr .='<select name="whs_ovr_'.$ovrKey.'_1" id="whs_ovr_'.$ovrKey.'_1">';
					            					
													
					            					for ($i = 8; $i <= 30; $i++) {
					            						$retStr .= '<option value="'.$i.'px"';
					            						if ($ovrItemVals[0] == $i.'px') $retStr .= ' selected="selected"';
					            						$retStr .='>'.$i.'px</option>'; 
					            					}
					            					
					            					foreach ($whSFontSizes as $fontSize) {
					            						$retStr .= '<option value="'.$fontSize.'"';
					            						if ($ovrItemVals[0] == $fontSize) $retStr .= ' selected="selected"';
					            						$retStr .='>'.$fontSize.'</option>';
					            					}

					            				$retStr .= '</select>';

												
												$retStr .= '<input name="whs_ovr_'.$ovrKey.'_2" id="whs_ovr_'.$ovrKey.'_2" class="styleOverride whsSpectrum" value="'.$ovrItemVals[1].'" />';



											$retStr .= '</td></tr>';

											break;

										
										case 'border':

											
											$ovrItemVals = array('','',''); if (isset($ovrItemValue) && !empty($ovrItemValue) && strpos($ovrItemValue,'|')) $ovrItemVals = explode('|',$ovrItemValue);

											$retStr .= '<tr class="'.$useStyleOverrideClass.'"><td class="whSOvrKey">'.$ovrItem['t'].'</td>';
											$retStr .= '<td>';

												
												$retStr .= '<select name="whs_ovr_'.$ovrKey.'_1" id="whs_ovr_'.$ovrKey.'_1">';

																		            					for ($i = 0; $i <= 20; $i++) {
					            						$retStr .= '<option value="'.$i.'"';
					            						if ($ovrItemVals[0] == $i) $retStr .= ' selected="selected"';
					            						$retStr .='>'.$i.'px</option>'; 
					            					}

					            				$retStr .= '</select>';

					            				
					            				$retStr .='<select name="whs_ovr_'.$ovrKey.'_2" id="whs_ovr_'.$ovrKey.'_2">';
					            					
					            					
					            					foreach ($whSBorderTypes as $borderType) {
					            						$retStr .= '<option value="'.$borderType.'"';
					            						if ($ovrItemVals[1] == $borderType) $retStr .= ' selected="selected"';
					            						$retStr .='>'.ucfirst($borderType).'</option>';
					            					}

					            				$retStr .= '</select>';

												
												$retStr .= '<input name="whs_ovr_'.$ovrKey.'_3" id="whs_ovr_'.$ovrKey.'_3" class="styleOverride whsSpectrum" value="'.$ovrItemVals[2].'" />';

											$retStr .= '</td></tr>';


											break;

										
										case 'opacity':

											$retStr .= '<tr class="'.$useStyleOverrideClass.'"><td class="whSOvrKey">'.$ovrItem['t'].'</td>';
											$retStr .= '<td>';

					            				
					            				$retStr .='<select name="whs_ovr_'.$ovrKey.'" id="whs_ovr_'.$ovrKey.'">';
					            					
					            					
					            					for ($opacityNo = 1; $opacityNo <= 10; $opacityNo++) {
					            						
					            						if ($opacityNo < 10) $opacityNoStr = '0.'.$opacityNo; else $opacityNoStr = '1';
					            						$retStr .= '<option value="'.$opacityNoStr.'"';
					            						if ($ovrItemValue == '0.'.$opacityNo || ($opacityNo == 10 && $ovrItemValue == 1)) $retStr .= ' selected="selected"';
					            						$retStr .='>'.($opacityNo*10).'%</option>';
					            					}

					            				$retStr .= '</select>';
											$retStr .= '</td></tr>';

											break;



									}



								}


						}

					}	


				} else $retStr .= '<tr><td colspan="2" style="text-align:center;padding:40px;">Styles could not be loaded for "'.$pluginName.'" (502)</td></tr>';

			} else $retStr .= '<tr><td colspan="2" style="text-align:center;padding:40px;">Styles could not be loaded for "'.$pluginName.'" (501)</td></tr>';



		
		$retStr .= '</tbody></table>';


		
			$retStr .= '<table class="table table-bordered table-striped wtab" id="whStyleLibEditPageTab3"><tbody>';
			
			$retStr .= '<tr class="'.$useStyleOverrideClass.'"><td colspan="2" style="text-align:center;padding:40px;"><button type="submit" class="button button-success">Save Style Changes</button></td></tr>';
			
			$retStr .= '</tbody></table>';


		
		$retStr .= '<script type="text/javascript">jQuery(document).ready(function(){jQuery(".whsSpectrum").spectrum({showInput:!0,preferredFormat:"hex"}),jQuery("#whStyleLibEditPageTab, #whStyleLibEditPageTab2").slideDown(),jQuery("#useStyleOverrides").click(function(){jQuery("#useStyleOverrides:checked").length?jQuery("#whStyleLibEditPageTab2 tr").addClass("useOverrides"):jQuery("#whStyleLibEditPageTab2 tr").removeClass("useOverrides")}),jQuery("#loadOverridesFrom").change(function(){jQuery("#loadstylesettings").val(jQuery(this).val()),jQuery("#whStylePostBox").submit()}),jQuery("input:radio[name=whs_basestyle]").change(function(){jQuery("#whStyleForm").submit()})});</script>';



		
		$retStr .= '<style type="text/css">#whStyleLibEditPage{width:780px;margin:10px}#whStyleLibEditPage p{padding:14px;background:#FFF}#whStyleLibEditPage table.wtab tr td .whStyleSelect{text-align:center}#whStyleLibEditPage table.wtab tr td .whStyleSelect .whStyleOption{display:inline-block;border:0;margin:0 1%;padding:0;min-height:140px}#whStyleLibEditPage table.wtab tr td .whStyleSelect .whStyleOption:hover{cursor:pointer}#whStyleLibEditPage table.wtab tr td .whStyleSelect .whStyleOptionTitle{display:inline-block;border:0;margin:0 1%;padding:0;text-align:center;font-weight:800}#whStyleLibEditPage table.wtab tr th.whStyleCatHead{text-align:left;font-size:20px;padding-top:36px}#whStyleLibEditPage table.wtab tr td input,#whStyleLibEditPage table.wtab tr td select{margin-right:4px}#whStyleLibEditPage table.wtab tr td textarea.styleOverride{min-height:80px}#whStyleLibEditPage table.wtab tr td.whSOvrKey span{font-size:11px}#whStyleLibEditPage table.wtab tr td div.whSButtonChoice{width:76px;height:64px;display:inline-block;margin:8px 4px 4px;padding:10px;text-align:center}#whStyleLibEditPageTab2 tr td,#whStyleLibEditPageTab2 tr th{display:none}#whStyleLibEditPageTab2 tr.useOverrides td,#whStyleLibEditPageTab2 tr.useOverrides th,#whStyleLibEditPageTab2 tr.whStyleShow td,#whStyleLibEditPageTab2 tr.whStyleShow th{display:table-cell}</style>';

		
		
		$retStr .= '<style type="text/css">.pure-button{display:inline-block;zoom:1;line-height:normal;white-space:nowrap;vertical-align:middle;text-align:center;cursor:pointer;-webkit-user-drag:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;font-family:inherit;font-size:100%;padding:.5em 1em;color:#444;color:rgba(0,0,0,.8);border:1px solid #999;border:none transparent;background-color:#E6E6E6;text-decoration:none;border-radius:2px}.pure-button-hover,.pure-button:focus,.pure-button:hover{filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=\'#00000000\', endColorstr=\'#1a000000\', GradientType=0);background-image:-webkit-gradient(linear,0 0,0 100%,from(transparent),color-stop(40%,rgba(0,0,0,.05)),to(rgba(0,0,0,.1)));background-image:-webkit-linear-gradient(transparent,rgba(0,0,0,.05) 40%,rgba(0,0,0,.1));background-image:-moz-linear-gradient(top,rgba(0,0,0,.05) 0,rgba(0,0,0,.1));background-image:-o-linear-gradient(transparent,rgba(0,0,0,.05) 40%,rgba(0,0,0,.1));background-image:linear-gradient(transparent,rgba(0,0,0,.05) 40%,rgba(0,0,0,.1))}.pure-button:focus{outline:0}.pure-button-active,.pure-button:active{box-shadow:0 0 0 1px rgba(0,0,0,.15)inset,0 0 6px rgba(0,0,0,.2)inset}.pure-button-disabled,.pure-button-disabled:active,.pure-button-disabled:focus,.pure-button-disabled:hover,.pure-button[disabled]{border:none;background-image:none;filter:progid:DXImageTransform.Microsoft.gradient(enabled=false);filter:alpha(opacity=40);-khtml-opacity:.4;-moz-opacity:.4;opacity:.4;cursor:not-allowed;box-shadow:none}.pure-button-hidden{display:none}.pure-button::-moz-focus-inner{padding:0;border:0}.pure-button-primary,.pure-button-selected,a.pure-button-primary,a.pure-button-selected{background-color:#0078e7;color:#fff}.pure-button-error,.pure-button-purple,.pure-button-secondary,.pure-button-success,.pure-button-warning{color:#fff;border-radius:4px;text-shadow:0 1px 1px rgba(0,0,0,.2)}.pure-button-success{background:#1cb841}.pure-button-error{background:#ca3c3c}.pure-button-warning{background:#df7514}.pure-button-secondary{background:#42b8dd}.pure-button-purple{background:#581158}.pure-button-brownround{background:#560e0e;color:#E2D50C;border-radius:10px;text-shadow:0 1px 1px rgba(0,0,0,.2)}.pure-button-apple{background:#0e5636;color:#0CE2A0;border-radius:19px;text-shadow:0 1px 1px rgba(0,0,0,.2)}</style>';


		








	
	$retStr .= '</div></form>';

	
	$retStr .= '<form method="post" id="whStylePostBox"><input type="hidden" name="loadstylesettings" id="loadstylesettings" value="" /></form>';


	

	return $retStr;

}












function op8_bd60010032($v='',$importantFlag=true){


	$ret = '';
	if (!empty($v)){

		
		$vArr = array('','',''); if (strpos($v,'|')) $vArr = explode('|',$v);

				if (count($vArr) == 3 && $vArr[0] != ''){

			$ret = 'border:'.$vArr[0].'px '.$vArr[1].' '.$vArr[2];
			if ($importantFlag) $ret .= ' !important';
			$ret .= ';';

		}


	}
	return $ret;

}




function op8_5fec78e7c($v='',$importantFlag=true){

	$ret = '';
	if (!empty($v)){

		$ret = 'background:'.$v;
		if ($importantFlag) $ret .= ' !important';
		$ret .= ';';		

	}
	return $ret;

}


function op8_b48($v='',$importantFlag=true){

	$ret = '';
	if (!empty($v)){

		$ret = 'background-color:'.$v;
		if ($importantFlag) $ret .= ' !important';
		$ret .= ';';		

	}
	return $ret;

}




function op8_c10f377268($v='',$importantFlag=true){

	$ret = '';
	if (!empty($v)){

		$ret = 'opacity:'.$v;
		if ($importantFlag) $ret .= ' !important';
		$ret .= ';';		

	}
	return $ret;

}


function op8_7e97697e73($v='',$importantFlag=true){

	$ret = '';
	if (!empty($v)){

		
		$vArr = array('',''); if (strpos($v,'|')) $vArr = explode('|',$v);

				if (count($vArr) == 2 && $vArr[0] != ''){

			
			$ret .= 'font-size:'.$vArr[0];
			if ($importantFlag) $ret .= ' !important';
			$ret .= ';';

			
			$ret .= 'color:'.$vArr[1];
			if ($importantFlag) $ret .= ' !important';
			$ret .= ';';

		}


	}
	return $ret;

}



function op8_c6d8f06a($v='',$importantFlag=true){

	$ret = '';
	if (!empty($v)){

		$ret = 'color:'.$v;
		if ($importantFlag) $ret .= ' !important';
		$ret .= ';';		

	}
	return $ret;

}






function op8_b0136c21($title){
	return htmlentities(stripslashes($title),ENT_QUOTES,'UTF-8');
} 
function op8_dea0ad157($title){
	return html_entity_decode($title,ENT_QUOTES,'UTF-8');
} 



function op8_aa3069376($flag,$msg,$includeExclaim=false){
	
    if ($includeExclaim){ $msg = '<div id="sgExclaim">!</div>'.$msg.''; }
    

    if ($flag == -1){
		echo '<div class="fail wrap whAlert-box">'.$msg.'</div>';
	} 
	if ($flag == 0){
		echo '<div class="success wrap whAlert-box">'.$msg.'</div>';	
	}
	if ($flag == 1){
		echo '<div class="warn wrap whAlert-box">'.$msg.'</div>';	
	}
    if ($flag == 2){
        echo '<div class="info wrap whAlert-box">'.$msg.'</div>';
    }

    
}