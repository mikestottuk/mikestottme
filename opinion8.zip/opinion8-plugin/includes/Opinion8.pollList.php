<?php /* !
 * Opinion8
 * http://www.epicplugins.com
 * V1.0
 *
 * Copyright 2014, Epic Plugins, StormGate Ltd.
 *
 * Date: 26/10/15
 */



if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class opinion8__pollList extends WP_List_Table {

    
    public function __construct() {

        parent::__construct( [
            'singular' => op8_922f3( 'Poll', 'opinion8' ), 
            'plural'   => op8_922f3( 'Polls', 'opinion8' ), 
            'ajax'     => false         ] );

    }


    
    public static function get_polls( $per_page = 10, $page_number = 1 ) {

        
        return op8_ac(true,$per_page,$page_number);

    }


    
    public static function delete_poll( $id ) {

        
        wp_delete_post($id);

    }


    
    public static function record_count() {
      
        
        return op8_e8899fc08();

    }


    
    public function no_items() {

        op8_9ede5841ed( 'No Polls avaliable.', 'opinion8' );

    }


    
    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            
            
            
            default:
                return print_r( $item, true ); 
        }
    }

    
    function column_cb( $item ) {
        return sprintf(
            '<input type="checkbox" name="bulk-delete[]" value="%s" />', $item['id']
        );
    }

    
    function column_pollname( $item ) {
        
        $colStr = '<a href="post.php?post='.$item['id'].'&action=edit">'.$item['name'].'</a>';

        $pollQuestion = '';
        if (isset($item['p_meta']) && isset($item['p_meta']['pollquestion'])) $pollQuestion = $item['p_meta']['pollquestion'];
        if (!empty($pollQuestion)) $colStr .= '<br />Question: '.$pollQuestion;
        

        return $colStr;

    }

    
    function column_choicecount( $item ) {
        
        $retStr = '-';
        if (isset($item['p_choices']) && count($item['p_choices']) > 0) $retStr = op8_8cf51f904c(count($item['p_choices']));
        
        return $retStr;

    }

    
    function column_pollquestion( $item ) {
        
        $retStr = '-';
        if (isset($item['p_meta']) && isset($item['p_meta']['pollquestion'])) $retStr = $item['p_meta']['pollquestion'];
        
        return $retStr;

    }

    
    function column_pollviews( $item ) {

        $pollTotalViews = 0;
        if (isset($item['p_v'])) $pollTotalViews = (int)$item['p_v'];

        return op8_8cf51f904c($pollTotalViews);

    }

    
    function column_pollvotes( $item ) {

        $pollTotalVotes = 0;
        if (isset($item['p_results']) && isset($item['p_results']['poll_c'])) 
            foreach ($item['p_results']['poll_c'] as $pollVoteCount) $pollTotalVotes+=$pollVoteCount;

        $retStr = op8_8cf51f904c($pollTotalVotes);
        
        return $retStr;

    }

    
    function column_polltype( $item ) {
        
        $retStr = 'Multi-choice';
        if (isset($item['p_meta']) && isset($item['p_meta']['type']) && $item['p_meta']['type'] == 'text') $retStr = 'Textbox';
        
        return $retStr;
        

    }

    
    function column_polllastvote( $item ) {

        $retStr = '-'; 
        if (isset($item['p_results']) && isset($item['p_results']['lastvote']) && !empty($item['p_results']['lastvote']) && $item['p_results']['lastvote'] !== -1) $retStr = date('d-m-Y',$item['p_results']['lastvote']);
        
        return $retStr;

    }

    
    function column_pollcreated( $item ) {

        $retStr = '-'; 
        if (isset($item['created']) && !empty($item['created']) && $item['created'] !== -1) $retStr = date('d-m-Y', strtotime($item['created']));
        
        return $retStr;

    }

    
    function column_status( $item ) {

        

        return '';
    }


    
    function get_columns() {

    global $opinion8_Settings;

    $logViews = $opinion8_Settings->get('logviews');

        
        if (isset($logViews) && $logViews == 1) {

                $columns = [
                    'cb'      => '<input type="checkbox" />',
                    'pollname'    => op8_922f3( 'Poll Name', 'opinion8' ),
                    
                    'polltype'    => op8_922f3( 'Type', 'opinion8' ),
                    'choicecount' => op8_922f3( 'No# Choices', 'opinion8' ),
                    'pollviews' => op8_922f3( 'Views', 'opinion8' ),
                    'pollvotes' => op8_922f3( 'Votes', 'opinion8' ),
                    'polllastvote' => op8_922f3( 'Last Vote Received', 'opinion8' ),
                    'pollcreated' => op8_922f3( 'Poll Created', 'opinion8' ),
                    
                ];


        } else {

                $columns = [
                    'cb'      => '<input type="checkbox" />',
                    'pollname'    => op8_922f3( 'Poll Name', 'opinion8' ),
                    
                    'polltype'    => op8_922f3( 'Type', 'opinion8' ),
                    'choicecount' => op8_922f3( 'No# Choices', 'opinion8' ),
                    'pollvotes' => op8_922f3( 'Votes', 'opinion8' ),
                    'polllastvote' => op8_922f3( 'Last Vote Received', 'opinion8' ),
                    'pollcreated' => op8_922f3( 'Poll Created', 'opinion8' ),
                    
                ];

        }

        return $columns;
    }


    
    public function get_sortable_columns() {
        $sortable_columns = array(
            'pollname' => array( 'pollname', true ),
            'pollvotes' => array( 'pollvotes', true ),
            'polllastvote' => array( 'polllastvote', true ),
            'pollcreated' => array( 'pollcreated', true ),
            'status' => array( 'status', false )
        );

        return $sortable_columns;
    }

    
    public function get_bulk_actions() {
        $actions = [
            'bulk-delete' => 'Delete'
        ];

        return $actions;
    }


    
    public function prepare_items() {

        
        

        
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array($columns, $hidden, $sortable);
        

        
        $this->process_bulk_action();

        $per_page     = $this->get_items_per_page( 'polls_per_page', 10 );
        $current_page = $this->get_pagenum();
        $total_items  = self::record_count();

        $this->set_pagination_args( [
            'total_items' => $total_items, 
            'per_page'    => $per_page 
        ] );

        $this->items = self::get_polls( $per_page, $current_page );

    }

    public function process_bulk_action() {

        
        if ( 'delete' === $this->current_action() ) {

            
            $nonce = esc_attr( $_REQUEST['_wpnonce'] );

            if ( ! wp_verify_nonce( $nonce, 'op8_delete_poll' ) ) {
                die( '!' ); 
            }
            else {

                self::delete_poll( absint( $_GET['op8poll'] ) );

                wp_redirect( esc_url( add_query_arg() ) );
                exit;
            }

        }

        
        if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'bulk-delete' )
             || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'bulk-delete' )
        ) {

            global $deletedPollCount; $deletedPollCount = 0;

            $delete_ids = esc_sql( $_POST['bulk-delete'] );

            
            foreach ( $delete_ids as $id ) {

                self::delete_poll( $id );
                $deletedPollCount++;

            }

            
            wp_redirect( esc_url( add_query_arg() ) );
            exit;
        }
    }

}



function op8_c1fa(){

    if (
        is_admin() && 
        isset($_GET['post_type']) && $_GET['post_type'] == 'opinion8' && 
        isset($_GET['page']) && $_GET['page'] == 'opinion8-pollmanager'
        ){


            if (!current_user_can('manage_options'))  { wp_die( op8_922f3('You do not have sufficient permissions to access this page.','opinion8') ); }

                
                    if ( ( isset( $_POST['action'] ) && $_POST['action'] == 'bulk-delete' )
                         || ( isset( $_POST['action2'] ) && $_POST['action2'] == 'bulk-delete' )
                    ) {

                        global $deletedPollCount; $deletedPollCount = 0;

                        $delete_ids = esc_sql( $_POST['bulk-delete'] );

                        
                        foreach ( $delete_ids as $id ) {

                            
                            wp_delete_post($id);
                            $deletedPollCount++;

                        }

                        
                        
                        wp_redirect( 'edit.php?post_type=opinion8&page=opinion8-pollmanager&del='.$deletedPollCount );
                        exit;
                    }

    }
}



function op8_4bae136536(){

    global $opinion8_slugs;
    $op8ListTable = new opinion8__pollList();
    $op8ListTable->prepare_items();

    $option = 'per_page';
    $args   = [
        'label'   => 'Polls',
        'default' => 10,
        'option'  => 'polls_per_page'
    ];

    add_screen_option( $option, $args );
    
   
        
        op8_481da8(op8_922f3('Manage Polls','opinion8'));
        
                $normalLoad = true; 
        
        if ($normalLoad){

            if (isset($_GET['del']) && !empty($_GET['del'])) {
                $pS = ''; $pC = (int)$_GET['del']; 
                if ($pC > 1) $pS = 's';
                echo op8_b7b7(0,$pC.' Poll'.$pS.' deleted.');
            }
            
    ?>
        <div id="poststuff">
            <div id="post-body" class="metabox-holder columns-2">
                <div id="post-body-content">
                    <div class="meta-box-sortables ui-sortable">
                        <form method="post">
                            <?php
                            $op8ListTable->display(); ?>
                        </form>
                    </div>
                </div>
            </div>
            <br class="clear">
        </div>
        
        </div>
    <?php
    
        }
}
