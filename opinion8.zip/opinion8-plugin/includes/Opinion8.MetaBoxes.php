<?php /* !
 * Opinion8
 * http://www.epicplugins.com
 * V1.0
 *
 * Copyright 2014, Epic Plugins, StormGate Ltd.
 *
 * Date: 26/10/15
 */


class opinion8__Metabox {

    static $instance;
    private $postType;

    public function __construct( $plugin_file ) {
            
        self::$instance = $this;

        
        $this->postType = 'opinion8';

        add_action( 'add_meta_boxes', array( $this, 'create_meta_box' ) );
        add_filter( 'save_post', array( $this, 'save_meta_box' ), 10, 2 );
    }

    public function create_meta_box() {

        

        add_meta_box(
            'opinion8_details',
            op8_922f3( 'Opinion8 Poll Details', 'opinion8' ),
            array( $this, 'print_meta_box' ),
            $this->postType,
            'normal',
            'high'
        );
    }

    public function print_meta_box( $post, $metabox ) {


        
        $pollObj = op8_24c7($post->ID,true,true,true,true);

        

        ?>
            <input type="hidden" name="meta_box_ids[]" value="<?php echo $metabox['id']; ?>" />
            <?php wp_nonce_field( 'save_' . $metabox['id'], $metabox['id'] . '_nonce' ); ?>

            <table class="form-table" id="wpo8MetaBoxMainItem">

                <?php

                    
                    if (isset($_GET['wpo8resetres'])){

                        
                        op8_51c51($post->ID,array('poll_c'=>array(),'ippool'=>array(),'lastvote'=>-1));

                        
                        $pollObj = op8_24c7($post->ID,true,true,true);

                        
                        ?><tr><td colspan="2"><?php echo op8_b7b7(0,op8_922f3('Successfully reset results.','opinion8')); ?></td></tr><?php
                        
                    }

                    if (isset($pollObj) && isset($pollObj['p_results']) && isset($pollObj['p_results']['poll_c']) && is_array($pollObj['p_results']['poll_c']) && count($pollObj['p_results']['poll_c']) > 0) {

                        $pollHasResults = true;
                        $pollTotalVotes = 0;
                        if (isset($pollObj['p_results']['poll_c'])) foreach ($pollObj['p_results']['poll_c'] as $pollVoteCount) $pollTotalVotes+=$pollVoteCount;
                ?>

                <tr class="wh-large"><th><label><?php op8_9ede5841ed('Results:','opinion8'); ?></label></th>
                <td>
                    <?php 
                        
                    ?>
                    <div id="wpo8ResultsWrap"></div>
                    <hr />
                    <?php

                                                $seenOnStr = ''; if (isset($pollObj) && isset($pollObj['p_results']) && isset($pollObj['p_results']['seenon']) && count($pollObj['p_results']['seenon']) > 0) foreach ($pollObj['p_results']['seenon'] as $seenOn){

                            $pageName = get_the_title($seenOn);
                            if (!empty($pageName)){
                                $pageURL = get_permalink($seenOn);
                                if (!empty($pageURL)){
                                    if (!empty($seenOnStr)) $seenOnStr .= ', ';
                                    $seenOnStr .= '<a href="'.$pageURL.'" target="_blank">'.$pageName.'</a>';
                                }
                            }

                        }

                        if (!empty($seenOnStr)) {

                            if (!empty($pollTotalVotes)) echo op8_8cf51f904c($pollTotalVotes). ' ';
                            op8_9ede5841ed('Votes Received from pages','opinion8'); echo ': '.$seenOnStr;

                                                                global $opinion8_Settings;  $logViews = $opinion8_Settings->get('logviews');
                                if (isset($logViews) && $logViews == 1) {
                                    $pollViews = 0;
                                    if (isset($pollObj['p_v']) && !empty($pollObj['p_v'])) $pollViews = (int)$pollObj['p_v'];
                                    echo ' ('.op8_8cf51f904c($pollViews).' views)';
                                }

                            echo '<hr />';

                        }

                    ?>
                    <div style="text-align:right;">
                        <a class="button" href="post.php?post=<?php echo $post->ID; ?>&action=edit&wpo8resetres=true"><i class="fa fa-file-image-o"></i> <?php op8_9ede5841ed('Reset Results (Restart Poll)','opinion8'); ?></a>
                    </div>
                </td></tr>

                <tr class="wh-large"><td colspan="2"><hr /></td></tr>

                <tr class="wh-large"><td colspan="2">
                    <div style="text-align:center;font-weight:800"><?php op8_9ede5841ed('Note: Making changes to this poll will effectively restart it, resetting all voting results.','opinion8'); ?></div>
                    <input type="hidden" name="forceresetresults" value="1" />
                </td></tr>

                <tr class="wh-large"><td colspan="2"><hr /></td></tr>

                <?php } ?>

                <tr class="wh-large"><th><label for="wpo8_question"><?php op8_9ede5841ed( 'Question', 'opinion8' ); ?></label></th>
                <td>
                    <!-- input or text area? <input name="wpo8_question" type="text" id="wpo8_question" value="<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['pollquestion'])) ?>" class="regular-text">-->
                    <textarea name="wpo8_question" type="text" id="wpo8_question" class="regular-text"><?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['pollquestion'])) echo $pollObj['p_meta']['pollquestion']; ?></textarea>
                </td></tr>

                <tr class="wh-large"><th><label for="wpo8_biline"><?php op8_9ede5841ed( 'Biline', 'opinion8' ); ?></label></th>
                <td><input name="wpo8_biline" type="text" id="wpo8_biline" value="<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['biline'])) echo $pollObj['p_meta']['biline']; ?>" class="regular-text"></td></tr>


                <tr class="wh-large"><th><label for="wpo8_increlated"><?php op8_9ede5841ed( 'Include in Related Polls', 'opinion8' ); ?></label></th>
                <td>
                    <input name="wpo8_increlated" type="checkbox" id="wpo8_increlated"<?php if (
                            (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['increlated']) && $pollObj['p_meta']['increlated'] == 1) ||
                            (isset($pollObj['p_meta']) && !isset($pollObj['p_meta']['increlated']))
                            ) echo ' checked="checked"'; ?> value="1" style="height:17px">
                </td></tr>

                <tr class="wh-large whIncRelatedOptionHide<?php 
                        if (
                            (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['increlated']) && $pollObj['p_meta']['increlated'] == 1) ||
                            (isset($pollObj['p_meta']) && !isset($pollObj['p_meta']['increlated']))
                            ) echo ' whIncRelatedOptionShow'; ?>"><th><label for="wpo8_relatedurl"></label></th>
                <td>
                    <label for="wpo8_relatedurl"><?php op8_9ede5841ed( 'Related Poll URL', 'opinion8' ); ?></label>
                    <div style="padding:4px;"><?php op8_9ede5841ed('If this poll is to show up under "Related Polls" on other polls, what URL should it link too? (This is usually the URL of the page where you intend to show this poll.)','opinion8'); ?></div>
                    <input name="wpo8_relatedurl" type="text" id="wpo8_relatedurl" value="<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['relatedurl'])) echo $pollObj['p_meta']['relatedurl']; ?>" class="regular-text">    
                </td></tr>




                <tr class="wh-large"><td colspan="2"><hr /></td></tr>

                <tr class="wh-large"><th><label for="wpo8_bgimgurl"><?php op8_9ede5841ed( 'Background', 'opinion8' ); ?></label></th>
                <td>
                    <div id="wpo8_bgimgselect">
                        <input name="wpo8_bgimgurl" type="text" id="wpo8_bgimgurl" style="width: 180px;font-size: 14px;" value="<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['bgimgurl'])) echo $pollObj['p_meta']['bgimgurl']; ?>" class="regular-text">
                        <button class="button" type="button" id="wpo8_bgimgurlupload" style="height: 36px;"><i class="fa fa-file-image-o"></i> <?php op8_9ede5841ed( 'Upload Background Image', 'opinion8' ); ?></button>
                        or <button class="button" type="button" id="wpo8_bgimgchoose" style="height: 36px;"><i class="fa fa-bookmark-o"></i> <?php op8_9ede5841ed( 'Choose Background', 'opinion8' ); ?></button>
                        <div id="wpo8_bgimggallery"><?php

                            global $wpo8_bgimggalleryimgs;
                            foreach ($wpo8_bgimggalleryimgs as $wpo8img){

                                echo '<div class="wpo8_bgimgchoice" data-iurl="'.$wpo8img['url'].'"><div style="background:url('.$wpo8img['url'].') 0 0 no-repeat;background-size:cover;"></div>'.$wpo8img['name'].'</div>';

                            }

                        ?></div>
                    </div>
                    <div id="wpo8_bgimgdemo"></div>
                </td></tr>

                <tr class="wh-large"><th><label for="wpo8_textcolour"><?php op8_9ede5841ed( 'Text Colour', 'opinion8' ); ?></label></th>
                <td><input name="wpo8_textcolour" type="text" id="wpo8_textcolour" value="<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['textcolour'])) echo $pollObj['p_meta']['textcolour'];  ?>" class="whsSpectrum"></td></tr>

                <tr class="wh-large"><th><label for="wpo8_answerscolour"><?php op8_9ede5841ed( 'Answers Colour', 'opinion8' ); ?></label></th>
                <td><input name="wpo8_answerscolour" type="text" id="wpo8_answerscolour" value="<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['answerscolour'])) echo $pollObj['p_meta']['answerscolour'];  ?>" class="whsSpectrum"></td></tr>

                <tr class="wh-large"><td colspan="2"><hr /></td></tr>

                <tr class="wh-large"><th><label for="wpo8_type"><?php op8_9ede5841ed( 'Type', 'opinion8' ); ?></label></th>
                <td id="wpo8_type_group">
                    <input type="radio" class="form-control" name="wpo8_type" id="wpo8_type_multi" value="multi" <?php 
                    if (
                        (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['type']) && $pollObj['p_meta']['type'] != 'text') ||
                        (isset($pollObj['p_meta']) || isset($pollObj['p_meta']['type']))
                        )
                        echo ' checked="checked"'; ?> />
                    <label for="wpo8_type_multi"><?php op8_9ede5841ed( 'Multiple Selection', 'opinion8' ); ?></label><br />
                    
                    <input type="radio" class="form-control" name="wpo8_type" id="wpo8_type_text" value="text" <?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['type']) && $pollObj['p_meta']['type'] == 'text') echo ' checked="checked"'; ?> />
                    <label for="wpo8_type_text"><?php op8_9ede5841ed( 'Text Feedback', 'opinion8' ); ?></label>
                </td></tr>

                <tr class="wh-large whTypeOptionTextHide<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['type']) && $pollObj['p_meta']['type'] == 'text') echo ' whTypeOptionText'; ?>"><th><label for="wpo8_textrecipient"><?php op8_9ede5841ed( 'Text Feedback Recipient', 'opinion8' ); ?></label></th>
                <td><input name="wpo8_textrecipient" type="text" id="wpo8_textrecipient" value="<?php if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['textrecipient'])) echo $pollObj['p_meta']['textrecipient'];  ?>" class="form-control" placeholder="e.g. your@email.com"></td></tr>



                <tr class="wh-large whTypeOptionMultiHide<?php 
                if (
                    (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['type']) && $pollObj['p_meta']['type'] != 'text') ||
                    (!isset($pollObj['p_meta']) || !isset($pollObj['p_meta']['type']))
                    ) echo ' whTypeOptionMulti'; ?>"><th><label for="wpo8_choices"><?php op8_9ede5841ed( 'Choices', 'opinion8' ); ?></label></th>
                <td>
                    <div id="wpo8_choice_controldeck"><span></span><button class="button" type="button" id="wpo8_addChoice"><i class="fa fa-plus-square"></i> <?php op8_9ede5841ed( 'Add Choice', 'opinion8' ); ?></button></div>
                    <hr />
                    <div id="wpo8_choices">
                    </div>
                    <div id="wpo8_choice_controls">
                        
                    </div>
                    <script type="text/javascript">var whOp8choices = <?php 
                    $choiceArr = array(); if (isset($pollObj['p_choices']) && is_array($pollObj['p_choices']) && count($pollObj['p_choices']) > 0) $choiceArr = $pollObj['p_choices']; 
                    echo json_encode($choiceArr ); ?>; var whOp8Results = <?php 
                    $resArr = array(); if (isset($pollObj['p_results']) && is_array($pollObj['p_results'])) $resArr = $pollObj['p_results']; 
                    echo json_encode($resArr ); ?>;</script>
                </td></tr>




                <tr class="wh-large"><td colspan="2"><hr /></td></tr>

                <tr class="wh-large"><th><label for="wpo8_postvotereload"><?php op8_9ede5841ed( 'Post Vote Reload Outcome', 'opinion8' ); ?></label></th>
                <td>
                    <?php $pvropt = ''; if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['postvotereload']) && !empty($pollObj['p_meta']['postvotereload'])) $pvropt = $pollObj['p_meta']['postvotereload']; ?>
                    <select name="wpo8_postvotereload" id="wpo8_postvotereload" class="form-control">
                        <option value="none"<?php if ($pvropt == 'none') echo ' selected="selected"'; ?> >None, (Re-show)</option>
                        <option value="statshare"<?php if ($pvropt == 'statshare' || empty($pvropt)) echo ' selected="selected"'; ?>>Show Stats, then Share Box</option>
                        <option value="share"<?php if ($pvropt == 'share') echo ' selected="selected"'; ?>>Show Share Box</option>
                        <option value="html"<?php if ($pvropt == 'html') echo ' selected="selected"'; ?>>Show Custom HTML</option>
                        <option value="redir"<?php if ($pvropt == 'redir') echo ' selected="selected"'; ?>>Redirect to Custom URL</option>
                        <option value="hide"<?php if ($pvropt == 'hide') echo ' selected="selected"'; ?>>Hide Opinion8</option>
                    </select>
                    <p>This option defines what will be shown to a user after they have voted, left the webpage, and returned at a later date.<br />(Some Opinion8 users do this to 'check-in' on a vote result at a later date.)</p>
                    <div class="wpo8_postvotereloadCustomHTML" style="display:<?php if ($pvropt == 'html') echo 'block'; else echo 'none'; ?>;">
                        <hr />
                        <label for="wpo8_postvotereload_customhtml">Custom HTML:</label>
                        <textarea name="wpo8_postvotereload_customhtml" id="wpo8_postvotereload_customhtml" class="form-control"><?php 
                        if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['postvotereload_customhtml'])) echo $pollObj['p_meta']['postvotereload_customhtml']; 
                        ?></textarea>
                    </div>
                    <div class="wpo8_postvotereloadRedirURL" style="display:<?php if ($pvropt == 'redir') echo 'block'; else echo 'none'; ?>;">
                        <hr />
                        <label for="wpo8_postvotereload_redirul">Redirect URL:</label>
                        <input type="text" name="wpo8_postvotereload_redirurl" id="wpo8_postvotereload_redirurl" value="<?php 
                        if (isset($pollObj['p_meta']) && isset($pollObj['p_meta']['postvotereload_redirurl'])) echo $pollObj['p_meta']['postvotereload_redirurl']; 
                        ?>" class="form-control" placeholder="e.g. http://google.com"></div>
                </td></tr>

            </table>
           

            <script type="text/javascript">

                var wpo8Glob = { choicecount:0, purl: '<?php echo OPINION8_URL; ?>', hasResults: <?php if (isset($pollHasResults)) echo 'true'; else echo 'false'; ?> };

                jQuery(document).ready(function(){

                    // Results init
                    whOp8_loadRes();

                    // any loaded bg img
                    whOp8_loadImg();

                    // Spectrum Init
                    jQuery(".whsSpectrum").spectrum({showInput:!0,preferredFormat:"hex"});

                    // Choices manager Init
                    if (typeof window.whOp8choices != "undefined")
                        jQuery.each(window.whOp8choices,function(ind,ele){

                            // index
                            window.wpo8Glob.choicecount++; var indx = window.wpo8Glob.choicecount;

                            // Build html
                            var choiceHTML = whOp8ChoiceHTML(indx,ele);

                            // inject em :)
                            jQuery('#wpo8_choices').append(choiceHTML);

                            // bind delete choice
                            whOp8_bindCloseChoice();

                            // choice count
                        wpOp8_choiceCountUpdate();

                        });

                    jQuery('#wpo8_type_group input, #wpo8_type_group label').click(function(){

                        //console.log(jQuery('input[name=wpo8_type]:checked').val() );

                        if (jQuery('input[name=wpo8_type]:checked').val() == 'multi'){

                            jQuery('.whTypeOptionMultiHide').addClass('whTypeOptionMulti');
                            jQuery('.whTypeOptionTextHide').removeClass('whTypeOptionText');


                        } else {

                            jQuery('.whTypeOptionMultiHide').removeClass('whTypeOptionMulti');
                            jQuery('.whTypeOptionTextHide').addClass('whTypeOptionText');

                        }


                    });

                    jQuery('#wpo8_increlated').click(function(){

                        //console.log(jQuery('input[name=wpo8_type]:checked').val() );

                        if (jQuery('input[name=wpo8_increlated]:checked').length){

                            jQuery('.whIncRelatedOptionHide').addClass('whIncRelatedOptionShow');


                        } else {

                            jQuery('.whIncRelatedOptionHide').removeClass('whIncRelatedOptionShow');

                        }


                    });

                    


                    // Uploader
                    // http://stackoverflow.com/questions/17668899/how-to-add-the-media-uploader-in-wordpress-plugin (3rd answer)                    
                    jQuery('#wpo8_bgimgurlupload').click(function(e) {
                        e.preventDefault();
                        var image = wp.media({ 
                            title: 'Upload Image',
                            // mutiple: true if you want to upload multiple files at once
                            multiple: false
                        }).open()
                        .on('select', function(e){
                            // This will return the selected image from the Media Uploader, the result is an object
                            var uploaded_image = image.state().get('selection').first();
                            // We convert uploaded_image to a JSON object to make accessing it easier
                            // Output to the console uploaded_image
                            //console.log(uploaded_image);
                            var image_url = uploaded_image.toJSON().url;
                            // Let's assign the url value to the input field
                            jQuery('#wpo8_bgimgurl').val(image_url).show();

                            // Update loaded img
                            whOp8_loadImg();
                        });
                    });

                    // Add choice
                    jQuery('#wpo8_addChoice').click(function(e){

                            // index
                            window.wpo8Glob.choicecount++; var indx = window.wpo8Glob.choicecount;

                            // Build html
                            var choiceHTML = whOp8ChoiceHTML(indx,{outcome:'statshare',txt:'','customhtml':'','redirurl':''});

                            // inject em :)
                            jQuery('#wpo8_choices').append(choiceHTML);

                            // bind delete choice
                            whOp8_bindCloseChoice();

                            // choice count
                        wpOp8_choiceCountUpdate();

                    });

                    // Delete choice
                    whOp8_bindCloseChoice();

                    // BG Img choices
                    jQuery('#wpo8_bgimgchoose').click(function(){

                        // Show hide
                        if (!jQuery(this).hasClass('wpo8_bgimggalleryopen')) {
                            
                            // show gallery
                            jQuery('#wpo8_bgimggallery').show();

                            // add
                            jQuery(this).addClass('wpo8_bgimggalleryopen');

                            // bind
                            jQuery('#wpo8_bgimggallery .wpo8_bgimgchoice').unbind('click').click(function(){

                                // Set url
                                var thisUrl = jQuery(this).attr('data-iurl');
                                jQuery('#wpo8_bgimgurl').val('background:'+thisUrl).show();


                                // Update loaded img
                                whOp8_loadImg();

                                // hide gallery
                                jQuery('#wpo8_bgimggallery').hide();

                                // rem
                                jQuery('#wpo8_bgimgchoose').removeClass('wpo8_bgimggalleryopen');

                            });

                        } else {
                            
                            // hide gallery
                            jQuery('#wpo8_bgimggallery').hide();

                            // rem
                            jQuery(this).removeClass('wpo8_bgimggalleryopen');


                        }



                    });



        

                    // post vote reload outcome options
                    jQuery('#wpo8_postvotereload').change(function(){

                        var v = jQuery(this).val();

                        switch (v){

                            case 'html':
                                jQuery('.wpo8_postvotereloadRedirURL').hide();
                                jQuery('.wpo8_postvotereloadCustomHTML').show();
                                break;

                            case 'redir':
                                jQuery('.wpo8_postvotereloadRedirURL').show();
                                jQuery('.wpo8_postvotereloadCustomHTML').hide();
                                break;

                            default:
                                jQuery('.wpo8_postvotereloadRedirURL').hide();
                                jQuery('.wpo8_postvotereloadCustomHTML').hide();
                                break;

                        }


                    });



                });

                function wpOp8_choiceCountUpdate(){
                    var choiceCountStr = ''; if (jQuery('#wpo8_choices .wpo8_choice').length > 0) choiceCountStr = '(' + jQuery('#wpo8_choices .wpo8_choice').length + ' choices) '; jQuery('#wpo8_choice_controldeck span').html(choiceCountStr);
                }

                function whOp8_bindCloseChoice(){

                    // Delete choice
                    jQuery('#wpo8_choices .wpo8_choice .cullChoice').unbind('click').click(function(){

                        jQuery(this).closest('.wpo8_choice').remove();
                        
                        // choice count
                        wpOp8_choiceCountUpdate();

                    });

                    // outcome options
                    jQuery('#wpo8_choices .wpo8choiceOutcomeDrop').change(function(){

                        var v = jQuery(this).val();

                        switch (v){

                            case 'html':
                                jQuery('.wpo8choiceRedirURL',jQuery(this).closest('.wpo8_choice')).hide();
                                jQuery('.wpo8choiceCustomHTML',jQuery(this).closest('.wpo8_choice')).show();
                                break;

                            case 'redir':
                                jQuery('.wpo8choiceCustomHTML',jQuery(this).closest('.wpo8_choice')).hide();
                                jQuery('.wpo8choiceRedirURL',jQuery(this).closest('.wpo8_choice')).show();
                                break;

                            default:
                                jQuery('.wpo8choiceCustomHTML',jQuery(this).closest('.wpo8_choice')).hide();
                                jQuery('.wpo8choiceRedirURL',jQuery(this).closest('.wpo8_choice')).hide();
                                break;

                        }


                    });

                }

                function whOp8_loadRes(){

                    if (window.wpo8Glob.hasResults){

                    // Following originally lifted from front end v1.0
                    // Then modified :)

                        // Build results page html
                        var resHTML = '';

                          // get choices - save in array, build totals as we go
                          var voteTotal = 0; var choiceArr = []; jQuery.each(window.whOp8choices,function(ind,ele){

                            var thisTot = 0; if (typeof window.whOp8Results != "undefined" && typeof window.whOp8Results.poll_c != "undefined" && typeof window.whOp8Results.poll_c['a' + ind] != "undefined") thisTot = parseInt(window.whOp8Results.poll_c['a' + ind]);

                            // Store in easy access obj
                            choiceArr.push({
                                indx:'a'+ind,
                                str: ele.txt,
                                tot: thisTot
                            });

                            voteTotal += thisTot;

                          });

                          // Actual html
                          jQuery.each(choiceArr,function(ind,ele){

                            // calc width
                            var op8choiceWidth = 0; if (ele.tot > 0 && voteTotal > 0) op8choiceWidth = ((ele.tot/voteTotal)*100).toFixed(0);


                            // add html as we go
                            resHTML += '<div class="opinion8ResultBar" data-op8cid="' + ind + '"><div class="opinion8BarFill" style="width:' + op8choiceWidth + '%"></div><div class="opinion8BarText">' + ele.str + ' (' + ele.tot + ' votes - ' + op8choiceWidth + '%)</div></div>';

                          });

                          // Add the html
                          jQuery('#wpo8ResultsWrap').html(resHTML);


                    }
                }

                function whOp8_loadImg(){


                        // get
                        var imgURL = jQuery('#wpo8_bgimgurl').val();
                        if (typeof imgURL == "undefined" || imgURL == '') 
                            imgURL = window.wpo8Glob.purl+'/i/your-bg-here.jpg';
                        else {

                            // internal backgrounds
                            if (imgURL.substr(0,11) == 'background:'){

                                imgURL = imgURL.substr(11);

                            }

                        } 



                        jQuery('#wpo8_bgimgdemo').html('<img src="' + imgURL + '" alt="" />');

                }

                function whOp8ChoiceHTML(ind,ele){

                    var choiceHTML = '';
                    choiceHTML += '<div class="wpo8_choice">';

                    // add a HR if multi choices :)
                    //if (window.wpo8Glob.choicecount > 1) choiceHTML += '<hr />';

                        choiceHTML += '<div class="cullChoice"></div>';
                        choiceHTML += '<input type="hidden" name="wpo8_choice_' + ind + '" value="1">';
                        choiceHTML += '<label for="wpo8_choice_' + ind + '_text">Text:</label><input type="text" name="wpo8_choice_' + ind + '_text" id="wpo8_choice_' + ind + '_text" value="' + ele.txt + '" class="form-control" /><br />';
                        choiceHTML += '<label for="wpo8_choice_' + ind + '_outcome">Outcome:</label><br />';
                            choiceHTML += '<select name="wpo8_choice_' + ind + '_outcome" id="wpo8_choice_' + ind + '_outcome" class="form-control wpo8choiceOutcomeDrop">';
                            choiceHTML += whOp8ChoiceOptionHTML(ele.outcome);
                            choiceHTML += '</select><br />';
                        // V1.2 or so: Icon:
                            // choiceHTML += '<label for="wpo8_choice_' + ind + '_ico">Icon:</label><input type="text" name="wpo8_choice_' + ind + '_ico" id="wpo8_choice_' + ind + '_ico" class="form-control" /><br />';

                        // custom html input 
                        choiceHTML += '<div class="wpo8choiceCustomHTML"';
                            if (ele.outcome == 'html') choiceHTML += ' style="display:block"';
                        choiceHTML += '><label for="wpo8_choice_' + ind + '_customhtml">Custom HTML:</label><textarea name="wpo8_choice_' + ind + '_customhtml" id="wpo8_choice_' + ind + '_customhtml" class="form-control">' + ele.customhtml + '</textarea></div>';
                        
                        // custom redir out (to url)
                        choiceHTML += '<div class="wpo8choiceRedirURL"';
                            if (ele.outcome == 'redir') choiceHTML += ' style="display:block"';
                        choiceHTML += '><label for="wpo8_choice_' + ind + '_redirul">Redirect URL:</label><input type="text" name="wpo8_choice_' + ind + '_redirurl" id="wpo8_choice_' + ind + '_redirurl" value="' + ele.redirurl + '" class="form-control" placeholder="e.g. http://google.com" /></div>';

                    choiceHTML += '<div class="whClr"></div></div>';


                    return choiceHTML;
                }

                function whOp8ChoiceOptionHTML(v){

                    var opts = [
                        {v:'statshare',t:'Show Stats, then Share Box'},
                        {v:'share',t:'Show Share Box'},
                        {v:'html',t:'Show Custom HTML'},
                        {v:'redir',t:'Redirect to Custom URL'}
                        ];
                    var ret = '';
                    jQuery.each(opts,function(i,e){
                        ret += '<option value="' + e.v + '"';
                        if (e.v == v) ret += ' selected="selected"';
                        ret += '>' + e.t + '</option>';
                    });

                    return ret;

                }

            </script>

            <input type="hidden" name="<?php echo $metabox['id']; ?>_fields[]" value="subtitle_text" />
        <?php
    }

    public function save_meta_box( $post_id, $post ) {
        if( empty( $_POST['meta_box_ids'] ) ){ return; }
        foreach( $_POST['meta_box_ids'] as $metabox_id ){
            if( ! wp_verify_nonce( $_POST[ $metabox_id . '_nonce' ], 'save_' . $metabox_id ) ){ continue; }
            
            if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ){ continue; }

            if( $metabox_id == 'opinion8_details'  && $post->post_type == $this->postType){


                $pMeta = array();
                $pMeta['pollquestion'] = ''; if (isset($_POST['wpo8_question']) && !empty($_POST['wpo8_question'])) $pMeta['pollquestion'] = sanitize_text_field($_POST['wpo8_question']);
                $pMeta['biline'] = ''; if (isset($_POST['wpo8_biline']) && !empty($_POST['wpo8_biline'])) $pMeta['biline'] = sanitize_text_field($_POST['wpo8_biline']);

                
                $pMeta['type'] = 'multi'; if (isset($_POST['wpo8_type']) && !empty($_POST['wpo8_type']) && $_POST['wpo8_type'] == 'text') $pMeta['type'] = 'text';
                $pMeta['textrecipient'] = ''; if (isset($_POST['wpo8_textrecipient'])) $pMeta['textrecipient'] = sanitize_text_field($_POST['wpo8_textrecipient']);
                $pMeta['increlated'] = -1; if (isset($_POST['wpo8_increlated'])) $pMeta['increlated'] = 1;
                $pMeta['relatedurl'] = ''; if (isset($_POST['wpo8_relatedurl'])) $pMeta['relatedurl'] = sanitize_text_field($_POST['wpo8_relatedurl']);




                
                $pMeta['textcolour'] = ''; if (isset($_POST['wpo8_textcolour'])) $pMeta['textcolour'] = sanitize_text_field($_POST['wpo8_textcolour']);
                $pMeta['bgimgurl'] = ''; if (isset($_POST['wpo8_bgimgurl'])) $pMeta['bgimgurl'] = sanitize_text_field($_POST['wpo8_bgimgurl']);


                
                $pMeta['postvotereload'] = ''; if (isset($_POST['wpo8_postvotereload'])) $pMeta['postvotereload'] = sanitize_text_field($_POST['wpo8_postvotereload']);
                $pMeta['postvotereload_customhtml'] = ''; if (isset($_POST['wpo8_postvotereload_customhtml'])) $pMeta['postvotereload_customhtml'] = op8_9b0cb4f6($_POST['wpo8_postvotereload_customhtml']);
                $pMeta['postvotereload_redirurl'] = ''; if (isset($_POST['wpo8_postvotereload_redirurl'])) $pMeta['postvotereload_redirurl'] = sanitize_text_field($_POST['wpo8_postvotereload_redirurl']);

                
                $pMeta['answerscolour'] = ''; if (isset($_POST['wpo8_answerscolour'])) $pMeta['answerscolour'] = sanitize_text_field($_POST['wpo8_answerscolour']);
                



                
                update_post_meta($post_id, 'p_meta', $pMeta);

                
                $pChoices = array();

                    
                    for ($x = 1; $x <= 20; $x++){

                        if (isset($_POST['wpo8_choice_'.$x]) && !empty($_POST['wpo8_choice_'.$x])){

                            
                            $choiceOpt = array('txt'=>'','outcome'=>'','customhtml'=>'','redirurl'=>''); 

                            
                            if (isset($_POST['wpo8_choice_'.$x.'_text']) && !empty($_POST['wpo8_choice_'.$x.'_text'])) $choiceOpt['txt'] = sanitize_text_field($_POST['wpo8_choice_'.$x.'_text']);
                            if (isset($_POST['wpo8_choice_'.$x.'_outcome']) && !empty($_POST['wpo8_choice_'.$x.'_outcome'])) $choiceOpt['outcome'] = sanitize_text_field($_POST['wpo8_choice_'.$x.'_outcome']);
                            if (isset($_POST['wpo8_choice_'.$x.'_customhtml']) && !empty($_POST['wpo8_choice_'.$x.'_customhtml'])) $choiceOpt['customhtml'] = op8_9b0cb4f6($_POST['wpo8_choice_'.$x.'_customhtml']);
                            if (isset($_POST['wpo8_choice_'.$x.'_redirurl']) && !empty($_POST['wpo8_choice_'.$x.'_redirurl'])) $choiceOpt['redirurl'] = sanitize_text_field($_POST['wpo8_choice_'.$x.'_redirurl']);

                            
                            $pChoices[] = $choiceOpt;

                        }

                    }

                update_post_meta($post_id, 'p_choices', $pChoices);

                
                
                
                    $pResults = array('poll_c'=>array(),'ippool'=>array(),'lastvote'=>-1,'seenon'=>array());
                    update_post_meta($post_id, 'p_results', $pResults);

                



            }
        }

        return $post;
    }
}

$opinion8_MetaBox = new opinion8__Metabox( __FILE__ );

?>