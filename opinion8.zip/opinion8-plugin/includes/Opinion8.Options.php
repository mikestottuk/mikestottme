<?php /* !
 * Opinion8
 * http://www.epicplugins.com
 * V1.0
 *
 * Copyright 2014, EpicPlugins, StormGate Ltd.
 *
 * Date: 26/10/15
 */

	class Opinion8Settings {
		
		
		private $settings;
		private $settingsKey = 'opinion8settings';
		private $settingsVer = 'v1.0//26.10.15';
		private $settingsDefault = array( 

										
										'opensans' => 				1,
										'css_override' => 			'',
										'fbappid' => 				'',
										'sharefb' => 				1,
										'sharetw' => 				1,
										'twvia' => 					'',
										'sharepin' => 				1,
										'sharegp' => 				1,

										
										'logviews' => 				1,
										'poweredby' => 				1,
										'poweredbyuser' => 			'',



										
										
										'whstyles' => array(

											
											'basestyle' => array(

													'v' => 'Default', 

													'opts' => array('Default') 

											),
											
											
											'useoverrides' => false, 
											
											
											
											
											'defaultoverridesvar' => 'opinion8StyleDefaults', 

											
											'overrides' => array(

												
												
												
												
													

														
														
														
														'bgoverlayopacity'		=> array('v'=>'0.6','opts'=>'opacity','t'=>'Background Overlay Opacity','cat' => 'Global Styles'),

														
														'choicebutton' 			=> array('v'=>'pure-button','opts'=>'button','t'=>'Vote Button Style','cat' => 'Poll Voting'),
														'submitbutton' 			=> array('v'=>'pure-button','opts'=>'button','t'=>'Submit Button Style','cat' => 'Text Input Polls'),

														
														'loadinganibg' 			=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Loading Animation Starting Colour','cat' => 'Loading Dialog'),
														'loadinganibg2' 		=> array('v'=>'#2b8ccd','opts'=>'color','t'=>'Loading Animation Ending Colour','cat' => 'Loading Dialog'),
														'loadinganiborder'		=> array('v'=>'3|solid|#2b8ccd','opts'=>'border','t'=>'Loading Animation Circles: Border','cat' => 'Loading Dialog'),
														'loadingbg' 			=> array('v'=>'#E4E4E4','opts'=>'color','t'=>'Loading Blocker Background','cat' => 'Loading Dialog'),
														'loadingbgopacity'		=> array('v'=>'0.3','opts'=>'opacity','t'=>'Loading Blocker Background Opacity','cat' => 'Loading Dialog'),
														
														
														'barcolor' 			=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Bar Colour','cat' => 'Result Bars'),
														'bartextcolor' 		=> array('v'=>'#000000','opts'=>'color','t'=>'Bar Text Colour','cat' => 'Result Bars'),
														
														
														'shareicocolor' 	=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Share Icon Colour','cat' => 'Share Buttons'),
														'shareicobg' 		=> array('v'=>'#69BD69','opts'=>'color','t'=>'Share Icon BG Colour','cat' => 'Share Buttons'),
														'shareicohover' 	=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Share Icon Colour (Hover)','cat' => 'Share Buttons'),
														'shareicobghover' 	=> array('v'=>'#94CE94','opts'=>'color','t'=>'Share Icon BG Colour (Hover)','cat' => 'Share Buttons'),

											)		

										), 




										
										'whlang' => array(


												

												'6f97affc01668e2b1d9bb6175e012d83' => array("","Send Feedback"),
												'fa7d6e6feaeaba8badc2b35af839160f' => array("","Poll Results"),
												'5f116cf369c2231925d7184cab6d8a77' => array("","Your Opinion Counts!"),
												'414a7d818fb90b58742e2ef9fff2c97f' => array("","Share this poll to see what your friends think:"),
												'b43949cb7d2628eac322e88cdde5880b' => array("","Related Polls:"),
												'59cac242424a26568eb82229cc127c99' => array("","No Related Polls!"),
												'25bd6551aff1d8efa79bad27e886276b' => array("","Results:")


										) 


		);
		
		
		
		function Opinion8Settings() {
			
			
			$this->loadFromDB();
			
			
			$this->validateAndUpdate();
			
			
			if (empty($this->settings)) $this->initCreate();
			
		}
		
		
		function validateAndUpdate(){
			$defaultsAdded = 0;
			foreach ($this->settingsDefault as $key => $val) 
				if (!isset($this->settings[$key])) {
					$this->settings[$key] = $val;
					$defaultsAdded++;
				}
			
			if ($defaultsAdded > 0) $this->saveToDB();
		}
		
		
		function initCreate(){
			
			global $socialBuzzPlugin_db_version, $socialBuzzPlugin_version;
			
			
			$defaultOptions = $this->settingsDefault;
			$defaultOptions['settingsID'] = $this->settingsVer; 
			$defaultOptions['db_version'] = $socialBuzzPlugin_db_version; 
			$defaultOptions['version'] = $socialBuzzPlugin_version; 
			$this->settings = $defaultOptions;
			$this->saveToDB();
			
		}

		
		function resetToDefaults(){
			
			global $socialBuzzPlugin_db_version, $socialBuzzPlugin_version;
			
			
			$this->settings = $this->settingsDefault;
			$this->saveToDB();

		}
		
		
		function getAll(){
			
			return $this->settings;
			
		}
		
		
		function get($key){
			
			if (empty($key) === true) return false;
			
			if (isset($this->settings[$key]))
				return $this->settings[$key];
			else
				return false;
			
		}
		
		
		function update($key,$val=''){
			
			if (empty($key) === true) return false;
			
						$this->settings[$key] = $val;		
			
			
			$this->saveToDB();
		}		
		
		
		function delete($key){
			
			if (empty($key) === true) return false;
			
			$newSettings = array();
			foreach($this->settings as $k => $v)
				if ($k != $key) $newSettings[$k] = $v;
				
			
			$this->settings = $newSettings;
						
		}
		
		
		function saveToDB(){
		
			return update_option($this->settingsKey, $this->settings);				
			
		}
		
		
		function loadFromDB(){
			
			$this->settings = get_option($this->settingsKey);
			return $this->settings;
			
		}		
		
		
		function uninstall(){
			
			
			$this->settings['uninstall'] = time();
			
			
			$this->createBackup('Pre-UnInstall Backup');
			
			
			$this->settings = NULL;
			
			
			return delete_option($this->settingsKey);
			
		}
		
		
		function createBackup($backupLabel=''){
			
			$existingBK = get_option($this->settingsKey.'_bk'); if (!is_array($existingBK)) $existingBK = array();
			$existingBK[time()] = $this->settings; 
			if (!empty($backupLabel)) $existingBK[time()]['backupLabel'] = sanitize_text_field($backupLabel); 
			update_option($this->settingsKey.'_bk',$existingBK);
			return $existingBK[time()];
			
		}
		
		
		function killBackups(){
		
			return delete_option($this->settingsKey.'_bk');
			
		}
		
		
		function getBKs(){
			
			$x = get_option($this->settingsKey.'_bk');
			
			if (is_array($x)) return $x; else return array();
			
		}
		
		
		function reloadFromBK($bkkey){
		
			$backups = get_option($this->settingsKey.'_bk');
			
			if (isset($backups[$bkkey])) if (is_array($backups[$bkkey])) {
				
				
				$this->settings = $backups[$bkkey];
				
				
				$this->saveToDB();
			
				return true;	
				
			} 
			
			return false;
				
			
		}
		
		
		
	}



global $opinion8StyleDefaults;

$opinion8StyleDefaults = array(	
				'defaultoverrides' => array(

						
						'default' => array(	

														
														'bgoverlay'				=> array('v'=>'#000000','opts'=>'color','t'=>'Background Overlay','cat' => 'Global Styles'),
														'bgoverlayopacity'		=> array('v'=>'0.3','opts'=>'opacity','t'=>'Background Overlay Opacity','cat' => 'Global Styles'),

														
														'choicebutton' 			=> array('v'=>'pure-button','opts'=>'button','t'=>'Vote Button Style','cat' => 'Poll Voting'),
														'submitbutton' 			=> array('v'=>'pure-button','opts'=>'button','t'=>'Submit Button Style','cat' => 'Text Input Polls'),

														
														'loadinganibg' 		=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Loading Animation Starting Colour','cat' => 'Loading Dialog'),
														'loadinganibg2' 	=> array('v'=>'#2b8ccd','opts'=>'color','t'=>'Loading Animation Ending Colour','cat' => 'Loading Dialog'),
														'loadinganiborder'	=> array('v'=>'3|solid|#2b8ccd','opts'=>'border','t'=>'Loading Animation Circles: Border','cat' => 'Loading Dialog'),
														'loadingbg' 		=> array('v'=>'#E4E4E4','opts'=>'color','t'=>'Loading Blocker Background','cat' => 'Loading Dialog'),
														'loadingbgopacity'		=> array('v'=>'0.3','opts'=>'opacity','t'=>'Loading Blocker Background Opacity','cat' => 'Loading Dialog'),
														
														
														'barcolor' 			=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Bar Colour','cat' => 'Result Bars'),
														'bartextcolor' 		=> array('v'=>'#000000','opts'=>'color','t'=>'Bar Text Colour','cat' => 'Result Bars'),
														
														
														'shareicocolor' 	=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Share Icon Text Colour','cat' => 'Share Buttons'),
														'shareicobg' 		=> array('v'=>'#69BD69','opts'=>'color','t'=>'Share Icon BG Colour','cat' => 'Share Buttons'),
														'shareicohover' 	=> array('v'=>'#FFFFFF','opts'=>'color','t'=>'Share Icon Text Colour (Hover)','cat' => 'Share Buttons'),
														'shareicobghover' 	=> array('v'=>'#94CE94','opts'=>'color','t'=>'Share Icon BG Colour (Hover)','cat' => 'Share Buttons'),
										)
				)
			);

	
?>