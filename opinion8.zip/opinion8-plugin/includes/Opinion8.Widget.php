<?php /* !
 * Opinion8
 * http://www.pluginbeast.com
 * V1.0
 *
 * Copyright 2014, Epic Plugins, StormGate Ltd.
 *
 * Date: 26/10/15
 */


class Opinion8Widget extends WP_Widget
{
  public function __construct() {
    parent::__construct(
      'opinion8ResWidget', 
      op8_922f3( 'Opinion8 Results Widget', 'opinion8' ), 
      array( 'description' => op8_922f3( 'Displays Opinion8 Results as Widget', 'opinion8' ), ) 
    );
  }
 
  public function form($instance)
  {
    $pollid = ''; if (isset($instance['pollid']) && !empty($instance['pollid'])) $pollid = (int)$instance['pollid'];
    
    $pollList = op8_ac(false,100);
    ?>
    <p>
    <label for="<?php echo $this->get_field_id( 'pollid' ); ?>"><?php op8_9ede5841ed( 'Poll:', 'opinion8'); ?></label> 
    <?php if (count($pollList) > 0) { ?>
    <select id="<?php echo $this->get_field_id( 'pollid' ); ?>" name="<?php echo $this->get_field_name( 'pollid' ); ?>">
    <?php foreach ($pollList as $poll){ ?>
      <option value="<?php echo $poll['id']; ?>"<?php if ($pollid == $poll['id']) echo ' selected="selected"'; ?>><?php echo $poll['name']; ?></option>
    <?php } ?>
    </select>
    <?php } ?>
    </p>
    <?php 
  }
 
  public function update($new_instance, $old_instance)
  {
    $instance = $old_instance;
    $instance['pollid'] = $new_instance['pollid'];
    return $instance;
  }
 
  public function widget($args, $instance)
  {
    extract($args, EXTR_SKIP);
    
    $pollid = ''; if (isset($instance['pollid']) && !empty($instance['pollid'])) $pollid = (int)$instance['pollid'];
  
 	  if (!empty($pollid)) {
      echo $before_widget;
      echo do_shortcode('[Opinion8Results pollid="'.$pollid.'"]');
      echo $after_widget;
    }


  }
 
}
add_action( 'widgets_init', create_function('', 'return register_widget("Opinion8Widget");') );

?>