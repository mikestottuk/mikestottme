/*!
 * Opinion8
 * http://www.epicplugins.com
 * V1.2
 *
 * Copyright 2015, EpicPlugins.com, StormGate Ltd.
 *
 * Date: 07/12/15
 */
(function() {
    tinymce.PluginManager.add('opinion8Random', function( editor, url ) {
	    editor.addButton( 'opinion8Random', {
	            title: 'Opinion8 Random Poll',
	            image: window.wpop8URL + "i/WYSIWYG_icon_random.png",
	            
	            onclick: function () {
	              	tinymce.activeEditor.execCommand("mceInsertContent", false, '[Opinion8Random]')
	            }
	        });
    });
})();
