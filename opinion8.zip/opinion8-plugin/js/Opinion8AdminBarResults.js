/*!
 * Opinion8
 * http://www.epicplugins.com
 * V1.2
 *
 * Copyright 2015, EpicPlugins.com, StormGate Ltd.
 *
 * Date: 07/12/15
 */

(function() {
	
	
	var objVals = [];
	jQuery.each(window.wpopinion8WYSIWYGList,function(ind,ele){
		objVals.push({text:ele.name,value:ele.id});
	});
    tinymce.PluginManager.add('opinion8Results', function( editor, url ) {
	    editor.addButton( 'opinion8Results', {
	            title: 'Opinion8 Show Results',
	            image: window.wpop8URL + "i/WYSIWYG_icon_results.png",
	            
	            onclick: function () {
		            
		            editor.windowManager.open({
		                title: 'Select an Opinion8 Poll',
		                width:400,
		                height:80,
		                body: [
		                    
		                    {
		                    	type: 'listbox', 
							    name: 'whobjid', 
							    label: 'Select a Poll:', 
							    'values': objVals
		                    }
		                ],
		                onsubmit: function(e) {
		                	 tinymce.activeEditor.execCommand("mceInsertContent", false, '[Opinion8Results pollid="' + e.data.whobjid + '"]')
		                }
		            });
	            }
	        });
    });
})();
