<?php

/*
 * Plugin Name: TURN OFF PHP ERRORS FOR DEMO PURPOSES
 */

error_reporting(0);

?>