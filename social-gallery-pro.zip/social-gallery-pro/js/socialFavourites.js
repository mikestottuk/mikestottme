
jQuery(window).load(function() {
    mason = false;
    sgsdismiss = false;
    f();
    b();
    if (mason) {
        d()
    } else {
        a()
    }
    e();
    showc = false;

    function a() {
        windowW = jQuery(document).width();
        if (windowW < 641) {
            cW = 105;
            rH = 105
        } else {
            cW = 211;
            rH = 211
        }
        opt = {
            layoutMode: "perfectMasonry",
            perfectMasonry: {
                layout: "vertical",
                liquid: false,
                columnWidth: cW,
                rowHeight: rH
            },
            onLayout: function() {}
        };
        jQuery("#sg-mason").imagesLoaded(function() {
            jQuery("#sg-mason").isotope(opt);
            jQuery("#sg-mason img").fadeIn("slow");
            jQuery("#socialshortloader").hide()
        })
    }

    function g() {
        if (mason) {
            jQuery("#sg-mason").masonry("reload")
        } else {
            jQuery("#sg-mason").isotope("destroy");
            jQuery("#sg-mason").isotope(opt)
        }
    }

    function d() {
        jQuery("#sg-mason").masonry({
            columnWidth: 211,
            itemSelector: ".sg-item",
            isFitWidth: true,
            isAnimated: true
        }).imagesLoaded(function() {
            jQuery("#sg-mason").masonry("reload")
        })
    }

    function f() {
        jQuery(".sg-item").mouseenter(function() {
            jQuery(this).find("> ._53d").show();
            jQuery(this).find("> .fave").show();
            jQuery(this).find("> .nofave").show()
        });
        jQuery(".sg-item").mouseleave(function() {
            jQuery(this).find("> ._53d").hide();
            jQuery(this).find("> .fave").hide();
            jQuery(this).find("> .nofave").hide()
        });
        jQuery(".sgs-comment").click(function(h) {
            posit = jQuery(this).offset();
            if (jQuery("#sg-holder").length > 0) {
                parenttop = jQuery("#sg-holder").offset();
                comtop = h.pageY - parenttop.top + 20;
                comleft = posit.left - 150 - parenttop.left
            } else {
                parenttop = jQuery(this).position();
                comtop = h.pageY + 15;
                comleft = h.pageX - 174
            }
            if (showc) {
                if (posit.top == firstpos.top && posit.left == firstpos.left) {
                    jQuery(".fb-comment-holder").hide();
                    showc = false
                } else {
                    jQuery(".fb-comment-holder").css({
                        top: comtop,
                        left: comleft
                    }).show();
                    showc = true;
                    firstpos.top = posit.top;
                    firstpos.left = posit.left
                }
            } else {
                jQuery(".fb-comment-holder").css({
                    top: comtop,
                    left: comleft
                }).show();
                showc = true;
                firstpos = posit;
                firstpos.top = posit.top;
                firstpos.left = posit.left
            }
            like_link = jQuery(this).data("sgsc");
            jQuery(".fb-like").attr("data-href", like_link);
            jQuery(".fb-comments").attr("data-href", like_link);
            FB.XFBML.parse();
            return false
        });
        jQuery(document).click(function() {
            if (showc == true) {
                jQuery(".fb-comment-holder").hide();
                showc = false
            }
        })
    }

    function b() {
        jQuery(document).on("click", ".fave", function() {
            uid = jQuery(this).data("uid");
            pid = jQuery(this).data("pid");
            gid = jQuery(this).data("gid");
            fave = false;
            c(uid, pid, gid);
            jQuery(this).removeClass("fave").addClass("nofave").removeClass("fave-wrap").addClass("nofave-wrap");
            jQuery(this).find("> .fave-star").removeClass("fave-star").addClass("nofave-star");
            jQuery(this).parent(".social-gallery-item-fave").removeClass("social-gallery-item-fave").addClass("social-gallery-item");
            jQuery(this).siblings(".social-gallery-image-fave").removeClass("social-gallery-image-fave").addClass("social-gallery-image");
            g()
        });
        jQuery(document).on("click", ".nofave", function() {
            uid = jQuery(this).data("uid");
            pid = jQuery(this).data("pid");
            gid = jQuery(this).data("gid");
            fave = true;
            c(uid, pid, gid);
            jQuery(this).removeClass("nofave").addClass("fave").removeClass("nofave-wrap").addClass("fave-wrap");
            jQuery(this).find("> .nofave-star").removeClass("nofave-star").addClass("fave-star");
            jQuery(this).parent(".social-gallery-item").removeClass("social-gallery-item").addClass("social-gallery-item-fave");
            jQuery(this).siblings(".social-gallery-image").removeClass("social-gallery-image").addClass("social-gallery-image-fave");
            g()
        });
        jQuery(document).on("click", ".sgs-close", function() {
            jQuery(".sgs-modal-login").css("visibility", "hidden");
            sgsdismiss = true
        })
    }

    function e(h) {
        topreach = 0;
        topelem = 0;
        jQuery(".fblikes").each(function() {
            var j = jQuery(this);
            var i = j.attr("data-sgsc");
            jQuery.getJSON("http://graph.facebook.com/" + i, function(k) {
                j.find("> ._53n").text((k.shares || 0));
                j.find("> ._53m").text((k.comments || 0));
                curreach = k.shares
            })
        })
    }

    function c(m, o, n) {
        if (m == 0) {
            if (sgsdismiss == false) {
                jQuery(".sgs-modal-login").css({
                    visibility: "visible",
                    top: "0px"
                });
                return false
            }
        } else {
            var k = {
                action: "social_fave",
                uid: m,
                gid: n,
                pid: o
            };
            var h = jQuery.ajax({
                url: SocialAjax.ajaxurl,
                type: "POST",
                data: k,
                dataType: "json"
            });
            h.done(function(i) {
                if (fave) {
                    jQuery("f-" + m).removeClass("nofave").addClass("fave").removeClass("nofave-wrap").addClass("fave-wrap");
                    jQuery("f-" + m).find("> .nofave-star").removeClass("nofave-star").addClass("fave-star");
                    jQuery("f-" + m).parent(".social-gallery-item").removeClass("social-gallery-item").addClass("social-gallery-item-fave");
                    jQuery("f-" + m).siblings(".social-gallery-image").removeClass("social-gallery-image").addClass("social-gallery-image-fave")
                } else {
                    jQuery("f-" + m).removeClass("fave").addClass("nofave").removeClass("fave-wrap").addClass("nofave-wrap");
                    jQuery("f-" + m).find("> .fave-star").removeClass("fave-star").addClass("nofave-star");
                    jQuery("f-" + m).parent(".social-gallery-item-fave").removeClass("social-gallery-item-fave").addClass("social-gallery-item");
                    jQuery("f-" + m).siblings(".social-gallery-image-fave").removeClass("social-gallery-image-fave").addClass("social-gallery-image")
                }
                g()
            });
            h.fail(function(i, j) {
                alert("Request failed: " + j)
            })
        }
    }
});