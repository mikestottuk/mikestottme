
function sgp70da(e) {
    return "number" == typeof e && e % 1 == 0
}

function sgpe71a8c() {
    var e = !1;
    if ("undefined" != typeof window.sgp_config.sgp_inE && 1 != window.sgp_config.sgp_inE) {
        e = !0;
        var s = 700;
        "undefined" != typeof window.sgp_config.sgp_inET && (s = parseInt(window.sgp_config.sgp_inET)), jQuery("#sgPluginBox").removeClass().addClass(window.sgp_config.sgp_inE), jQuery("#sgPluginBox").css("display", "block"), jQuery("#sgPluginBox").css("opacity", 1), jQuery("#sgPluginBg").css("display", "block"), jQuery("#sgPluginBg").animate({
            opacity: window.sgp_config.sgp_bgo
        }, 300, "linear", function() {}), window.setTimeout(function() {
            jQuery("#sgPluginBox").removeClass()
        }, s)
    }
    e || (jQuery("#sgPluginBg").animate({
        opacity: window.sgp_config.sgp_bgo
    }, 300, "linear"), jQuery("#sgPluginBox").animate({
        opacity: "1.00"
    }, 300, "linear"), jQuery("#sgPluginBg, #sgPluginBox").css("display", "block"))
}

function sgmobilecom() {
    var e = "";
    shr = 1 == window.sgp_config.sgp_FBS ? "true" : "false", e += '<div class="fb-like sgfblike" data-href="' + ssc + '" data-width="500" data-height="30" data-colorscheme="light" data-layout="standard" data-action="like" data-show-faces="false" data-share="' + shr + '"></div>', e += '</div></div><div class = "sgmobdonecom"></div>', e += '<div id="sgmComments"><div class="fb-comments" data-href="' + ssc + '" data-num-posts="5" data-width="328"></div></div>', jQuery(".sgmsoc").html(e), jQuery(".fbpress, .sgmobdonecom").unbind("click").click(function() {
        jQuery(".sgmsoc").toggle("slide")
    })
}

function socialGalleryBind() {
    sgp94bb().not(".socialGalleryItem").each(function(e, s) {
        z = 0, z < 5 && (jQuery("#sgp-preloaded-images").append("<img src='" + s + "'width='1' height='1' alt='' />"), z++), jQuery(s).unbind("click").click(function(e) {
            if (!window.sgpc674b17) {
                var i = e.target.parentNode,
                    g = jQuery(s).attr("href");
                if ("undefined" != typeof g && "" != g) {
                    window.sgpc674b17 = !0;
                    var n = getTitle(s),
                        o = getDesc(s),
                        t = parseInt(sgp94bb().index(s)) + 1;
                    window.sgCurrind = t, "" != g && (sgp01e4(), jQuery("body").css("overflow", "hidden"), jQuery("html").css("overflow", "hidden"), jQuery("#sgPluginLoader").html('<img src="' + g + '" title="' + n + '" alt="" class="sgpI" />'), jQuery("#sgPluginLoader img").attr("title", n), "undefined" != typeof o && "" != o && jQuery("#sgPluginLoader img").attr("data-desc", o)), jQuery("#sgPluginLoader img").unbind("load").load(function() {
                        jQuery("#sgpILoading").wExists() && (document.getElementById("sgpILoading").width > 0 && (window.sgpDomW = document.getElementById("sgpILoading").width), document.getElementById("sgpILoading").height > 0 && (window.sgpDomH = document.getElementById("sgpILoading").height)), jQuery("#sgCont").html(""), jQuery("#sgPluginLoader img").appendTo("#sgCont"), sgpf19bc26(), sgp94bb().length > 1 && sgpbe330b7(), sgp4d5df(t), sgpe5c35()
                    }).bind("error", function() {
                        jQuery(i).addClass("noSocialGallery").unbind("click"), sgp7423()
                    }), sgpe71a8c(), sgp782498(t), e.preventDefault(), window.sgpc674b17 = !1
                } else jQuery(s).addClass("noSocialGallery")
            }
        }), jQuery(s).addClass("socialGalleryItem")
    })
}

function sgp4d5df(e) {
    if ("1" == window.sgp_config.sgp_bb) {
        var s = sgpe77bbcc(e, !0),
            i = "";
        if ("null" != jQuery("#sgCont img.sgpI").attr("title") && "undefined" != typeof jQuery("#sgCont img.sgpI").attr("title") && (i = jQuery("#sgCont img.sgpI").attr("title")), "null" != jQuery("#sgCont img.sgpI").attr("alt") && "undefined" != typeof jQuery("#sgCont img.sgpI").attr("alt") && "" == i && (i = jQuery("#sgCont img.sgpI").attr("alt")), "2" == window.sgp_config.sgp_bbt && (i = document.title), "3" == window.sgp_config.sgp_bbt && (i = window.sgp_config.sgp_bT), ("undefined" == i || "null" == i) && (i = ""), sgTagTit = i, "" != s && (i = '<a href="' + s + '" title="' + i + '">' + i + "</a>"), i += '<div id = "sgTag"><span class = "sgTagging">Tag Photo</span> </div>', jQuery(".sgpI").after("<div class = 'sg-face-tags'></div>"), jQuery("#sgControls").mouseenter(function() {
                jQuery(".sgBoxSug").show(), jQuery(".sgBoxT").show()
            }).mouseleave(function() {
                jQuery(".sgBoxSug").hide(), jQuery(".sgBoxT").hide(), jQuery(".sgTagName").hide()
            }), sgURL = jQuery(".sgpI").attr("src"), "1" == window.sgp_config.sgp_dll) {
            var g = jQuery("#sgCont img.sgpI").attr("src"),
                n = "Right Click Save as to download this image";
            if ("1" == window.sgp_config.sgp_dlh) {
                var o = getPermalinkIfExists(e, !0);
                if ("" != o && "undefined" != typeof o) var g = window.sgp_config.sgp_dlslug + o,
                    n = "Download this image"
            }
            "" != g && "undefined" != g && "null" != g && (i += '<div id="sgBaseDL">', i += '<a href="' + g + '" title="' + n + '" target="_blank">Download</a> |</div>')
        }
        var t = '<div id="sgBaseBarBg"></div><div id="sgBaseBar"><span class = "bbar">' + i + "</span></div>";
        jQuery("#sgCont").append(t), rebind(), jQuery("#sgCont").mouseenter(function() {
            jQuery("#sgBaseBarBg").fadeIn(100), jQuery("#sgBaseBar").fadeIn(100)
        }).mouseleave(function() {
            jQuery("#sgBaseBarBg").fadeOut(100), jQuery("#sgBaseBar").fadeOut(100)
        }), jQuery("#sgBaseBarBg").fadeIn(100), jQuery("#sgBaseBar").fadeIn(100)
    }
}

function sgp1d73() {
    window.sgp8b7a17 ? (window.sgp8b7a17 = !1, sgpf19bc26(!1), sgp94bb().length > 1 && sgpbe330b7()) : (sgpf19bc26(!0), sgp94bb().length > 1 && sgpbe330b7())
}

function sgpe5a3(e) {
    return e.replace(/-(\d*)x(\d*).jpg/, ".jpg").replace(/-(\d*)x(\d*).jpeg/, ".jpeg").replace(/-(\d*)x(\d*).gif/, ".gif").replace(/-(\d*)x(\d*).png/, ".png")
}

function sgpe77bbcc(e, s) {
    var i = !1,
        g = jQuery("#sgCont img.sgpI").attr("src");
    sgTagimg = g, ("" == g || "undefined" == typeof g || "undefined" == g) && "" != jQuery("#sgPluginLoader img").attr("src") && (g = jQuery("#sgPluginLoader img").attr("src"));
    var n = "";
    jQuery.each(window.sgi, function(e) {
        if (window.sgi[e][0] == g) return n = window.sgi[e][1], window.sgpcurrperm = n, i = !0, !1;
        var s = sgpe5a3(g);
        return window.sgi[e][0] == s ? (n = window.sgi[e][1], window.sgpcurrperm = n, i = !0, !1) : void 0
    });
    var o = !1,
        t = !1;
    return 1 == window.sgp_config.sgp_sgpages && "" != n ? n = window.sgp_config.sgp_slug + n : t = !0, t && (1 == window.sgp_config.sgp_fallback && (n = g), 2 == window.sgp_config.sgp_fallback && (n = sgpa6fe() + "#sg" + e, "undefined" != typeof s && s && (window.location.hash = "sg" + window.sgCurrind, o = !0)), 3 == window.sgp_config.sgp_fallback && (n = sgpa6fe()), "" == n && (n = g)), "undefined" != typeof s && s && !o && "#sg" == window.location.hash.substr(0, 3) && "" != window.location.hash && (window.location.hash = "_"), i || (window.sgpcurrperm = ""), n
}

function getPermalinkIfExists() {
    var e = !1,
        s = jQuery("#sgCont img.sgpI").attr("src");
    ("" == s || "undefined" == typeof s || "undefined" == s) && "" != jQuery("#sgPluginLoader img").attr("src") && (s = jQuery("#sgPluginLoader img").attr("src"));
    var i = "";
    return jQuery.each(window.sgi, function(g) {
        if (window.sgi[g][0] == s) return i = window.sgi[g][1], window.sgpcurrperm = i, e = !0, !1;
        var n = sgpe5a3(s);
        return window.sgi[g][0] == n ? (i = window.sgi[g][1], window.sgpcurrperm = i, e = !0, !1) : void 0
    }), i
}

function getPermalinkIfExistsMob() {
    var e = !1,
        s = jQuery("img.sgpmi").attr("src");
    ("" == s || "undefined" == typeof s || "undefined" == s) && "" != jQuery("#sgPluginLoader img").attr("src") && (s = jQuery("#sgPluginLoader img").attr("src"));
    var i = "";
    return jQuery.each(window.sgi, function(g) {
        if (window.sgi[g][0] == s) return i = window.sgi[g][1], window.sgpcurrperm = i, e = !0, !1;
        var n = sgpe5a3(s);
        return window.sgi[g][0] == n ? (i = window.sgi[g][1], window.sgpcurrperm = i, e = !0, !1) : void 0
    }), i
}

function sgp6938afc() {
    var e = jQuery("#sgCont img.sgpI").attr("src");
    ("" == e || "undefined" == typeof e || "undefined" == e) && "" != jQuery("#sgPluginLoader img").attr("src") && (e = jQuery("#sgPluginLoader img").attr("src"));
    var s = !1;
    return jQuery.each(window.sgi, function(i) {
        if (window.sgi[i][0] == e) return s = new Array, s[0] = window.sgi[i][2], s[1] = i, !1;
        var g = sgpe5a3(e);
        return window.sgi[i][0] == g ? (s = new Array, s[0] = window.sgi[i][2], s[1] = i, !1) : void 0
    }), s
}

function sgp782498(e) {
    jQuery(".esgbox-overlay").remove();
    var s = sgpe77bbcc(e, !1);
    if (jQuery("#disqus_thread").appendTo("#sgDisqusHold"), jQuery("#sgSideWrap").html(""), void 0 != typeof s && "" != s && "" != window.sgp_config.sgp_slug) var i = s;
    else var i = sgpa6fe();
    goog = i.replace(/^.*\/\/[^\/]+/, ""), sgTaglink = i, "undefined" != typeof _gaq && _gaq.push(["_trackPageview"], goog), "undefined" != typeof ga && ga("send", "pageview", goog);
    var g = "",
        n = "";
    if ("1" == window.sgp_config.sgp_hb && ("1" == window.sgp_config.sgp_hbt && (g = '<div id="sgBlogTitle"><img src="' + window.sgp_config.sgp_hbi + '" align="left">', g += '<a href="' + window.sgp_config.sgp_bU + '" title="' + window.sgp_config.sgp_bT + '">' + window.sgp_config.sgp_bT + "</a><br />" + window.sgp_config.sgp_bL + "</div>"), "2" == window.sgp_config.sgp_hbt && (g = '<div id="sgBlogTitle"><a href="' + window.sgp_config.sgp_bU + '" title="' + window.sgp_config.sgp_bT + '">' + window.sgp_config.sgp_bT + "</a><br />" + window.sgp_config.sgp_bL + "</div>"), "3" == window.sgp_config.sgp_hbt)) {
        var o = jQuery("<textarea/>").html(window.sgp_config.sgp_ch).val();
        g = '<div id="sgBlogTitle">' + o + "</div>"
    }
    if ("1" == window.sgp_config.sgp_desc) {
        var t = "";
        "null" != jQuery("#sgCont img.sgpI").attr("data-desc") && "undefined" != typeof jQuery("#sgCont img.sgpI").attr("data-desc") && (t = jQuery("#sgCont img.sgpI").attr("data-desc")), "null" != jQuery("#sgPluginLoader img").attr("data-desc") && "undefined" != typeof jQuery("#sgPluginLoader img").attr("data-desc") && "" == t && (t = jQuery("#sgPluginLoader img").attr("data-desc")), "" == t ? ("null" != jQuery("#sgCont img.sgpI").attr("title") && "undefined" != typeof jQuery("#sgCont img.sgpI").attr("title") && (n = jQuery("#sgCont img.sgpI").attr("title")), "null" != jQuery("#sgCont img.sgpI").attr("alt") && "undefined" != typeof jQuery("#sgCont img.sgpI").attr("alt") && "" == n && (n = jQuery("#sgCont img.sgpI").attr("alt")), "null" != jQuery("#sgPluginLoader img").attr("title") && "undefined" != typeof jQuery("#sgPluginLoader img").attr("title") && "" == n && (n = jQuery("#sgPluginLoader img").attr("title")), "null" != jQuery("#sgPluginLoader img").attr("alt") && "undefined" != typeof jQuery("#sgPluginLoader img").attr("alt") && "" == n && (n = jQuery("#sgPluginLoader img").attr("alt"))) : n = t, ("" == n || "undefined" == typeof n || "undefined" == n || "null" == n) && (n = ""), n = jQuery("<span>").html(n).text(), g += '<div id="sgBlogDesc">' + n + "</div>"
    }
    var a = "";
    if ((1 == window.sgp_config.sgp_shTU || 1 == window.sgp_config.sgp_shLI || 1 == window.sgp_config.sgp_shGP) && (a += '<div id="stTopRow">', 1 == window.sgp_config.sgp_shTU && (sgURL = jQuery(".sgpI").attr("src"), a += '<div id="sgTum"><a href="http://www.tumblr.com/share/photo?source=' + encodeURIComponent(sgURL) + '" title="Share on Tumblr" target="_blank" style="display:inline-block; text-indent:-9999px; overflow:hidden; width:81px; height:20px; background:url(\'http://platform.tumblr.com/v1/share_1.png\') top left no-repeat transparent;" target="_blank">Share on Tumblr</a></div>'), 1 == window.sgp_config.sgp_shLI && (a += '<div id="sgIN"><script type="IN/Share" data-url="' + i + '" data-counter="right"></script></div>'), 1 == window.sgp_config.sgp_shGP && (a += '<div id="sgGoog"><div class="g-plusone" data-size="medium" data-annotation="bubble" data-href="' + i + '"></div></div>'), a += "</div>"), 1 == window.sgp_config.sgp_tw || 1 == window.sgp_config.sgp_pin || 1 == window.sgp_config.sgp_shSU) {
        if (a += '<div id="stBottomRow">', "1" == window.sgp_config.sgp_tw) {
            var r = "";
            "undefined" != typeof window.sgp_config.sgp_twvia && "" != window.sgp_config.sgp_twvia && (r = ' data-via="' + window.sgp_config.sgp_twvia + '"'), a += '<div id="sgTwi"><a href="https://twitter.com/share" class="twitter-share-button"' + r + ' data-url="' + i + '">Tweet</a></div>'
        }
        if ("1" == window.sgp_config.sgp_pin) {
            if (jQuery("#sgPluginLoader img").wExists()) var d = jQuery("#sgPluginLoader img").attr("src");
            if (jQuery("#sgCont img.sgpI").wExists()) var d = jQuery("#sgCont img.sgpI").attr("src");
            if ("" == d || "undefined" == typeof d)
                if ("" != window.sgp_config.sgp_hbi) var d = window.sgp_config.sgp_hbi;
                else var d = "";
            var p = "";
            "undefined" != typeof n && "" != n && (p = n + " on " + window.sgp_config.sgp_bT + "  " + i), "" == p && (p = "Image on " + window.sgp_config.sgp_bT + "  " + i), a += '<div id="sgPin"><a data-pin-config="beside" href="//pinterest.com/pin/create/button/?url=' + encodeURIComponent(i) + "&media=" + encodeURIComponent(d), a += "&description=" + encodeURIComponent(p) + '" data-pin-do="buttonPin" target="_blank"><img src="//assets.pinterest.com/images/pidgets/pin_it_button.png" /></a></div>'
        }
        1 == window.sgp_config.sgp_shSU && (a += '<div id="sgSU"><div class="sbutton"><su:badge layout="1" location="' + i + '"></su:badge></div></div>'), a += "</div>"
    }
    if ("1" == window.sgp_config.sgp_fb && (shr = 1 == window.sgp_config.sgp_FBS ? "true" : "false", a += '<div class="fb-like sgfblike" data-href="' + i + '" data-share="' + shr + '" data-width="285" data-show-faces="', a += "1" == window.sgp_config.sgp_fbf ? "true" : "false", a += '"></div>', "undefined" != typeof FB && null != FB && FB.XFBML.parse(), sgURL = jQuery(".sgpI").attr("src"), 1 == window.sgp_config.sgp_Faces && sgDetectFaces(), rebind()), g += '<div id="sgSocial">' + a + "</div>", "1" == window.sgp_config.sgp_fbc && (g += '<div id="sgComments"><div class="fb-comments" data-href="' + i + '" data-num-posts="5" data-width="328"></div></div>'), "1" == window.sgp_config.sgp_dc && (sgpa6fe() + "#!sg" + e, g += jQuery("#disqus_thread").wExists() ? '<div id="sgComments"></div>' : '<div id="sgComments"><div id="disqus_thread"></div></div>'), "1" == window.sgp_config.sgp_hon) {
        var c = 'http://www.socialgalleryplugin.com"';
        "undefined" != typeof window.sgp_config.sgp_affU && "" != window.sgp_config.sgp_affU && (c = "http://codecanyon.net/item/social-gallery-wordpress-photo-viewer-plugin/2665332?ref=" + window.sgp_config.sgp_affU), g += '<div id="sgHonest"><a href="' + c + '" title="Powered by the Social Gallery Wordpress Plugin">Social Gallery Plugin</a></div>'
    }
    "1" == window.sgp_config.sgp_useAds && (g += "<div id='sgAdSlot'>" + decodeURIComponent((window.sgp_config.sgp_dfpInline + "").replace(/\+/g, "%20")) + "</div>"), jQuery("#sgSideWrap").html('<div id="sgScrollbox">' + g + "</div>"), socialGallery_LoadSocial(), socialGallery_LoadComments(i, n), sgpe5c35(), rebind(), sga_125_log()
}

function socialGallery_uts() {
    return Date.now()
}

function socialGallery_reloadAds() {
    var e = 2;
    return jQuery("#sgAdSlot") && "1" == window.sgp_config.sgp_useAds && window.sgpAdTime < socialGallery_uts() - e ? (window.sgpAdTime = socialGallery_uts(), googletag.pubads().refresh(), !1) : void 0
}

function socialGallery_LoadSocial() {
    "1" == window.sgp_config.sgp_tw && socialGallery_timedLoadTw(), ("1" == window.sgp_config.sgp_fb || "1" == window.sgp_config.sgp_fbc) && socialGallery_timedLoadFb(), "1" == window.sgp_config.sgp_pin, socialGallery_timedLoadOthers(), socialGallery_reloadAds()
}

function socialGallery_LoadComments(e, s, i) {
    var g = !1;
    "undefined" != typeof i && 1 == i && (g = !0), "1" != window.sgp_config.sgp_dc && !g || "undefined" == typeof window.sgp_config.sgp_dcn || "" == window.sgp_config.sgp_dcn || (window.sgpDisFire ? (window.sgpDiR < 5 && setTimeout(function() {
        socialGallery_LoadComments(e, s)
    }, 500), window.sgpDiR++) : (window.sgpDisFire = !0, jQuery("#sgDisqusHold #disqus_thread").wExists() && jQuery("#disqus_thread").css("display", "none").appendTo("#sgComments"), "" == s || "undefined" == typeof s || "undefined" == s, "undefined" != typeof DISQUS ? (DISQUS.reset({
        reload: !0,
        config: function() {
            this.page.identifier = e, this.page.url = e, ("" == s || "undefined" == typeof s || "undefined" == s) && (this.page.title = s)
        }
    }), jQuery("#disqus_thread").css("display", "inline-block")) : (! function() {
        var e = document.createElement("script");
        e.type = "text/javascript", e.async = !0, e.src = "http://" + window.sgp_config.sgp_dcn + ".disqus.com/embed.js", (document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]).appendChild(e)
    }(), socialGallery_timedLoadDisqus(e, e)), setTimeout(function() {
        window.sgpDisFire = !1
    }, 400)))
}

function socialGallery_timedLoadDisqus(e, s) {
    "undefined" != typeof DISQUS && window.sgpDiR < 5 && !window.sgpDisFire ? (DISQUS.reset({
        reload: !0,
        config: function() {
            this.page.identifier = e, this.page.url = s
        }
    }), jQuery("#disqus_thread").css("display", "inline-block")) : (window.sgpDiR++, setTimeout(function() {
        socialGallery_timedLoadDisqus(e, s)
    }, 500))
}

function socialGallery_timedLoadTw() {
    var e = !1;
    "undefined" != typeof twttr && window.sgpTwR < 5 && "undefined" != typeof twttr.widgets && (e = !0), e ? twttr.widgets.load() : (window.sgpTwR++, setTimeout(function() {}, 500))
}

function socialGallery_timedLoadOthers() {
    1 == window.sgp_config.sgp_shLI && "undefined" == typeof IN && jQuery("body").append('<script src="//platform.linkedin.com/in.js" type="text/javascript"></script>'), 1 == window.sgp_config.sgp_shGP && ("undefined" == typeof gapi ? ! function() {
        var e = document.createElement("script");
        e.type = "text/javascript", e.async = !0, e.src = "https://apis.google.com/js/plusone.js";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(e, s)
    }() : gapi.plusone.go()), 1 == window.sgp_config.sgp_shLI && ("undefined" == typeof window.STMBLPN ? ! function() {
        var e = document.createElement("script");
        e.type = "text/javascript", e.async = !0, e.src = ("https:" == document.location.protocol ? "https:" : "http:") + "//platform.stumbleupon.com/1/widgets.js";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(e, s)
    }() : STMBLPN.processWidgets()), 1 == window.sgp_config.sgp_pin && setTimeout(function() {
        jQuery("#pinterestSrc").remove(), jQuery("body").append('<script type="text/javascript" id="pinterestSrc" src="//assets.pinterest.com/js/pinit.js?wcb=' + Math.random() + '"></script>')
    }, 0)
}

function socialGallery_timedLoadFb() {
    "undefined" != typeof FB && window.sgpFbR < 5 ? ("1" == window.sgp_config.sgp_fb && "undefined" != typeof FB && null != FB && FB.XFBML.parse(jQuery("#sgSocial").get(0)), "1" == window.sgp_config.sgp_fbc && "undefined" != typeof FB && null != FB && FB.XFBML.parse(jQuery("#sgComments").get(0))) : (window.sgpFbR++, setTimeout(function() {}, 500))
}

function sgpde6() {
    "1" == window.sgp_config.sgp_fsm && "1" != window.sgp_config.sgp_ffsm && (jQuery("#sgFullScreen").wExists() || "undefined" == typeof window.sgptheme.iFs || (jQuery("#sgControls").append('<img id="sgFullScreen" src="' + window.sgptheme.iFs + '" alt="Fullscreen Mode" />'), jQuery("#sgFullScreen").unbind("click").click(function() {
        sgp1d73()
    })))
}

function sgpbe330b7() {
    if ("1" == window.sgp_config.sgp_nav) {
        var e = jQuery("#sgCont").height(),
            s = jQuery("#sgCont").width(),
            i = 22;
        "classic" == window.sgptheme.themename && (i = 22), "blue" == window.sgptheme.themename && (i = 32), "clean" == window.sgptheme.themename && (i = 26), "drawn" == window.sgptheme.themename && (i = 40);
        var g = (e - 39) / 2,
            n = .7 * s - i - 10;
        if (window.sgp_ie) var o = ' style="background:#FFF;opacity:0"';
        else var o = "";
        var t = '<div id="sgControls"><div id="sgLeft"' + o + "></div>";
        t += '<div id="sgRight"' + o + "></div></div>", jQuery("#sgControls").remove(), jQuery("#sgCont").append(t), window.sgp_ie && jQuery("#sgLeft").css("background", "#FFF").css("opacity", 0), window.sgp_ie && jQuery("#sgRight").css("background", "#FFF").css("opacity", 0), jQuery("#sgRight").mouseenter(function() {
            jQuery(this).css("background", "url(" + window.sgptheme.iRi + ") " + n + "px " + g + "px no-repeat").css("opacity", 1)
        }).mouseleave(function() {
            window.sgp_ie ? jQuery(this).css("background", "#FFF").css("opacity", 0) : jQuery(this).css("background", "url(" + window.sgp_config.sgp_iRoot + "i/1.png) transparent")
        }), jQuery("#sgLeft").mouseenter(function() {
            jQuery(this).css("background", "url(" + window.sgptheme.iLe + ") 10px " + g + "px no-repeat").css("opacity", 1)
        }).mouseleave(function() {
            window.sgp_ie ? jQuery(this).css("background", "#FFF").css("opacity", 0) : jQuery(this).css("background", "url(" + window.sgp_config.sgp_iRoot + "i/1.png) transparent")
        }), jQuery("#sgRight").click(function() {
            sgp9b69()
        }), jQuery("#sgLeft").click(function() {
            sgp2b57ae()
        })
    }
    sgpde6()
}

function sgpaddbind() {
    jQuery(".epic-sgpi img").unbind("swipeone").bind("swipeone", function(e, s) {
        var i = s.description.split(":")[2];
        return "left" == i ? (sgpmobright(), !1) : "right" == i ? (sgpmobleft(), !1) : void 0
    }), jQuery(".epic-sgpi img").unbind("tapone").bind("tapone", function() {
        jQuery(this).hasClass("sgphiding") ? (jQuery(this).removeClass("sgphiding"), jQuery(".sgmobdone").show(), jQuery(".sgmobbottom").show()) : (jQuery(this).addClass("sgphiding"), jQuery(".sgmobdone").hide(), jQuery(".sgmobbottom").hide())
    })
}

function sgpb4a() {
    "1" == window.sgp_config.sgp_nav && jQuery(document).keyup(function(e) {
        return 37 == e.keyCode && "block" == jQuery("#sgPluginBox").css("display") && sgp94bb().length > 1 ? (sgp2b57ae(), !1) : 39 == e.keyCode && "block" == jQuery("#sgPluginBox").css("display") && sgp94bb().length > 1 ? (sgp9b69(), !1) : 27 == e.keyCode && "block" == jQuery("#sgPluginBox").css("display") ? (sgp7423(), !1) : void 0
    })
}

function getTitle(e) {
    var s = jQuery(e).attr("title"),
        i = jQuery("img", e).attr("title");
    if (jQuery(".jig-caption-title", e).length > 0) var g = jQuery(".jig-caption-title", e).html();
    else var g = "";
    return "" == i || "undefined" == typeof i || "" != s && "undefined" != typeof s || (s = i), "" == g || "undefined" == typeof g || "" != s && "undefined" != typeof s || (s = g), s = "undefined" === s || "null" === s ? "" : jQuery("<span>").text(s).html()
}

function getDesc(e) {
    var s = "";
    try {
        var s = jQuery(e).attr("data-desc"),
            i = jQuery("img", e).attr("data-desc");
        "" == i || "undefined" == typeof i || "" != s && "undefined" != typeof s || (s = i), s = "undefined" === s || "null" === s ? "" : jQuery("<span>").text(s).html()
    } catch (g) {
        var s = ""
    }
    return s
}

function sgpmobright() {
    var e = window.sgCurrind;
    sgp94bb().length == e && (e = 0);
    var s = sgp94bb().get(e),
        i = jQuery(s).attr("href");
    if ("undefined" != typeof i && "" != i) {
        window.sgpc674b17 = !0;
        var g = getTitle(s),
            n = getDesc(s);
        parseInt(sgp94bb().index(s)) + 1, "" != i && (sgmtop = jQuery(document).scrollTop(), jQuery(".epic-sgpi").html("<img class = 'sgpmi' src = '" + i + "' width = '100%'/>"), jQuery(".epic-loading-mob").show(), jQuery(".epic-sgpi img").unbind("load").load(function() {
            ih = jQuery(".sgpmi").height(), topm = (windowh - ih) / 2, jQuery(".sgpmi").css("top", topm + "px"), jQuery(".sgmobtit").html(g), jQuery(".sgmobdesc").html(n), jQuery(".sgmobconts").html("<div class = 'fblike'></div><div class = 'fbcomm'></div>"), ssc = getEpicPermalinkIfExists(i), ssc = "" == ssc ? i : window.sgp_config.sgp_slug + ssc, jQuery(".sgmobcounts").html("<div class = '_53sgm'></div><div class = '_53sgn'><div>"), jQuery.getJSON("http://graph.facebook.com/" + ssc, function(e) {
                jQuery(".sgmobcounts").find("> ._53sgm").text((e.shares || 0) + " likes"), jQuery(".sgmobcounts").find("> ._53sgn").text((e.comments || 0) + " comments")
            }), sgmobilecom(), "undefined" != typeof FB && null != FB && FB.XFBML.parse(), jQuery(".epic-sgpi img").show(), jQuery(".epic-loading-mob").hide(), sgpaddbind()
        }), window.sgCurrind = e + 1, window.sgpc674b17 = !1)
    } else jQuery(this).addClass("noSocialGallery")
}

function sgpmobleft() {
    if (!window.sgpc674b17) {
        var e = window.sgCurrind - 2;
        0 > e && (e = sgp94bb().length - 1);
        for (var s = sgp94bb().get(e), i = jQuery(s).attr("href"), g = 10, n = 0;
            ("undefined" == typeof i || "" == i) && g > n;) {
            e--, 0 > e && (e = sgp94bb().length - 1);
            var s = sgp94bb().get(e),
                i = jQuery(s).attr("href");
            n++
        }
        if ("undefined" != typeof i && "" != i) {
            window.sgpc674b17 = !0;
            var o = getTitle(s),
                t = getDesc(s);
            parseInt(sgp94bb().index(s)) + 1, "" != i && (sgmtop = jQuery(document).scrollTop(), jQuery(".epic-sgpi").html("<img class = 'sgpmi' src = '" + i + "' width = '100%'/>"), jQuery(".epic-loading-mob").show(), jQuery(".epic-sgpi img").unbind("load").load(function() {
                ih = jQuery(".sgpmi").height(), topm = (windowh - ih) / 2, jQuery(".sgpmi").css("top", topm + "px"), jQuery(".sgmobtit").html(o), jQuery(".sgmobdesc").html(t), jQuery(".sgmobconts").html("<div class = 'fblike'></div><div class = 'fbcomm'></div>"), ssc = getEpicPermalinkIfExists(i), ssc = "" == ssc ? i : window.sgp_config.sgp_slug + ssc, jQuery(".sgmobcounts").html("<div class = '_53sgm'></div><div class = '_53sgn'><div>"), jQuery.getJSON("http://graph.facebook.com/" + ssc, function(e) {
                    jQuery(".sgmobcounts").find("> ._53sgm").text((e.shares || 0) + " likes"), jQuery(".sgmobcounts").find("> ._53sgn").text((e.comments || 0) + " comments")
                }), sgmobilecom(), "undefined" != typeof FB && null != FB && FB.XFBML.parse(), jQuery(".epic-sgpi img").show(), jQuery(".epic-loading-mob").hide(), sgpaddbind()
            }), window.sgCurrind = e + 1, window.sgpc674b17 = !1)
        } else jQuery(this).addClass("noSocialGallery")
    }
}

function sgp9b69() {
    if (window.sgpc674b17);
    else {
        var e = window.sgCurrind;
        sgp94bb().length == e && (e = 0);
        for (var s = sgp94bb().get(e), i = jQuery(s).attr("href"), g = 10, n = 0;
            ("undefined" == typeof i || "" == i) && g > n;) {
            e++, sgp94bb().length == e && (e = 0);
            var s = sgp94bb().get(e),
                i = jQuery(s).attr("href");
            n++
        }
        if ("undefined" != typeof i && "" != i) {
            window.sgpc674b17 = !0;
            var o = getTitle(s),
                t = getDesc(s),
                a = parseInt(sgp94bb().index(s)) + 1;
            "" != i && (sgp01e4(), jQuery("#sgPluginLoader").html('<img src="' + i + '" title="' + o + '" alt="" class="sgpI" />'), jQuery("#sgPluginLoader img").attr("title", o), "undefined" != typeof t && "" != t && jQuery("#sgPluginLoader img").attr("data-desc", t)), jQuery("#sgPluginLoader img").unbind("load").load(function() {
                jQuery("#sgCont").html(""), jQuery("#sgPluginLoader img").appendTo("#sgCont"), sgpf19bc26(), sgp94bb().length > 1 && sgpbe330b7(), sgp4d5df(a), sgpe5c35()
            }).bind("error", function() {
                jQuery(this).addClass("noSocialGallery")
            }), sgp782498(a), window.sgCurrind = e + 1, window.sgpc674b17 = !1
        } else jQuery(this).addClass("noSocialGallery")
    }
}

function sgp2b57ae() {
    if (!window.sgpc674b17) {
        var e = window.sgCurrind - 2;
        0 > e && (e = sgp94bb().length - 1);
        for (var s = sgp94bb().get(e), i = jQuery(s).attr("href"), g = 10, n = 0;
            ("undefined" == typeof i || "" == i) && g > n;) {
            e--, 0 > e && (e = sgp94bb().length - 1);
            var s = sgp94bb().get(e),
                i = jQuery(s).attr("href");
            n++
        }
        if ("undefined" != typeof i && "" != i) {
            window.sgpc674b17 = !0;
            var o = getTitle(s),
                t = getDesc(s),
                a = parseInt(sgp94bb().index(s)) + 1;
            "" != i && (sgp01e4(), jQuery("#sgPluginLoader").html('<img src="' + i + '" title="' + o + '" alt="" class="sgpI" />'), jQuery("#sgPluginLoader img").attr("title", o), "undefined" != typeof t && "" != t && jQuery("#sgPluginLoader img").attr("data-desc", t)), jQuery("#sgPluginLoader img").unbind("load").load(function() {
                jQuery("#sgCont").html(""), jQuery("#sgPluginLoader img").appendTo("#sgCont"), sgpf19bc26(), sgp94bb().length > 1 && sgpbe330b7(), sgp4d5df(a), sgpe5c35()
            }).bind("error", function() {
                jQuery(this).addClass("noSocialGallery")
            }), sgp782498(a), window.sgCurrind = e + 1, window.sgpc674b17 = !1
        } else jQuery(this).addClass("noSocialGallery")
    }
}

function sgpe5c35() {
    if ("1" == window.sgp_config.sgp_fbc) {
        var e = jQuery("#sgSideWrap").height(),
            s = jQuery("#sgSocial").outerHeight(!0),
            i = jQuery("#sgBlogDesc").outerHeight(!0),
            g = e - s - i - 80 - 20;
        300 > g && (g = 300), jQuery("#sgScrollbox").css("height", jQuery("#sgSideWrap").height() - 30 + "px")
    }
}

function sgp01e4() {
    if (window.sgp8b7a17) {
        var e = jQuery("#sgCont").height(),
            s = (e - 39) / 2;
        jQuery("#sgCont").html('<div style="margin-left:auto;margin-right:auto;width:520px;height:40px;position:relative;top:' + s + 'px"><img id="sgpLoadr" src="' + window.sgptheme.iLo + '" style="top:0;" alt="" title="Loading" /></div>')
    } else jQuery("#sgPluginBox").css("width", "880px").css("left", jQuery(window).width() / 2 - 440 + "px"), jQuery("#sgCont").css("width", "520px").html('<div style="width:520px;height:520px;"><img id="sgpLoadr" src="' + window.sgptheme.iLo + '" alt="" title="Loading" /></div>')
}

function sgpf19bc26(e) {
    var s = 10,
        i = 10;
    "undefined" != typeof window.sgp_config.sgp_mb && (s = window.sgp_config.sgp_mb, i = window.sgp_config.sgp_mb);
    var g = 7,
        n = i / 100,
        o = s / 100,
        t = jQuery(window).width(),
        a = jQuery(window).height(),
        r = jQuery("#sgCont img.sgpI").width(),
        d = jQuery("#sgCont img.sgpI").height(),
        p = "img.sgpI",
        c = "img.sgpI",
        u = sgp6938afc(),
        l = !1;
    if (u && "undefined" != typeof u[0]) {
        var w = u[1];
        sgp70da(u[0][0]) ? (r = parseInt(u[0][0]), p = "dims Array") : l = !0, sgp70da(u[0][1]) && (d = parseInt(u[0][1]), c = "dims Array")
    }
    if (sgp70da(window.sgpDomW) && window.sgpDomW > r && (r = window.sgpDomW, p = "dom img"), sgp70da(window.sgpDomH) && window.sgpDomH > d && (d = window.sgpDomH, c = "dom img"), l && (r > window.sgi[w][2][0] && (window.sgi[w][2][0] = r), d > window.sgi[w][2][1] && (window.sgi[w][2][1] = d)), window.sgpDomW = !1, window.sgpDomH = !1, "1" == window.sgp_config.sgp_ffsm) {
        var e = !0;
        window.sgp8b7a17 = !0
    } else {
        if ("undefined" == typeof e) var e = !1;
        if (window.sgp8b7a17) var e = !0
    }
    if ("1" == window.sgp_config.sgp_fsm && e) {
        jQuery("#sgPluginBox").css("top", "0").css("left", "0").css("width", t + "px").css("height", a + "px");
        var f = t - 374;
        jQuery("#sgCont").css("width", f + "px"), jQuery("#sgSideWrap").css("height", a - g + "px"), jQuery("#sgScrollbox").css("height", a - g - 30 + "px");
        var y = !0,
            m = 1.1;
        "undefined" != typeof window.sgp_config.sgp_usf && parseFloat(window.sgp_config.sgp_usf) > 0 && (m = window.sgp_config.sgp_usf);
        var h = sgp52517(f, a, r, d, y, m);
        jQuery("#sgCont img.sgpI").css("width", h[0] + "px").css("height", h[1] + "px");
        var b = .5 * a - .5 * h[1];
        jQuery("#sgCont img.sgpI").css("margin-top", b + "px"), window.sgp8b7a17 = !0
    } else if (r > 250 || d > 250) {
        var j = (t - 374) * o;
        34 > j && (j = 34);
        var _ = n * a;
        34 > _ && (_ = 34), j > _ ? j = _ : _ = j;
        var v = t - j - j - 374,
            Q = v + 374,
            x = a - _ - _;
        520 > v && (v = 520), 520 > x && (x = 520);
        var y = !0,
            m = 1.1;
        "undefined" != typeof window.sgp_config.sgp_usf && parseFloat(window.sgp_config.sgp_usf) > 0 && (m = window.sgp_config.sgp_usf);
        var h = sgp52517(v, x, r, d, y, m);
        520 > v && (v = 520), 520 > x && (x = 520);
        var C = h[0],
            B = h[1],
            Q = v + 374,
            x = B;
        v = 520 > C ? 520 : C, Q = v + 374, x > 1.1 * B && (x = 1.1 * B), 520 > x && (x = 520);
        var _ = .5 * a - .5 * x,
            j = .5 * t - .5 * Q;
        jQuery("#sgPluginBox").css("top", _ + "px").css("left", j + "px").css("width", Q + "px").css("height", x + "px"), jQuery("#sgCont").css("width", v + "px"), jQuery("#sgCont").css("width", v + "px"), jQuery("#sgCont img.sgpI").css("width", C + "px").css("height", B + "px"), jQuery("#sgPluginBox").css("top", _ + "px").css("left", j + "px").css("width", Q + "px").css("height", x + "px"), jQuery("#sgSideWrap").css("height", x - g + "px"), jQuery("#sgScrollbox").css("height", x - g - 30 + "px");
        var b = (x - B) / 2;
        jQuery("#sgCont img.sgpI").css("margin-top", b + "px")
    } else {
        var v = 520,
            Q = 894,
            x = 520,
            j = t / 2 - 440;
        34 > j && (j = 34);
        var _ = a / 2 - 260;
        34 > _ && (_ = 34), jQuery("#sgPluginBox").css("top", _ + "px").css("left", j + "px").css("width", Q + "px").css("height", x + "px"), jQuery("#sgCont").css("width", v + "px"), jQuery("#sgSideWrap").css("height", x - g + "px"), jQuery("#sgScrollbox").css("height", x - g - 30 + "px");
        var b = (x - d) / 2;
        jQuery("#sgCont img.sgpI").css("margin-top", b + "px")
    }
}

function sgp7423() {
    var e = !1;
    if ("undefined" != typeof window.sgp_config.sgp_outE && 1 != window.sgp_config.sgp_outE) {
        e = !0;
        var s = 700;
        "undefined" != typeof window.sgp_config.sgp_outET && (s = parseInt(window.sgp_config.sgp_outET)), jQuery("#sgPluginBox").removeClass().addClass(window.sgp_config.sgp_outE), window.setTimeout(function() {
            jQuery("#sgPluginBox").removeClass(), jQuery("#sgPluginBox").css("display", "none"), jQuery("#sgPluginBox").css("opacity", 0), jQuery("#sgPluginBg").animate({
                opacity: "0"
            }, 300, "linear", function() {
                jQuery("#sgPluginBg").css("display", "none"), jQuery("#sgPluginBg").css("opacity", 0)
            })
        }, s)
    }
    e || jQuery("#sgPluginBg, #sgPluginBox").animate({
        opacity: "0"
    }, 300, "linear", function() {
        jQuery("#sgPluginBg, #sgPluginBox").css("display", "none")
    }), "#sg" == window.location.hash.substr(0, 3) && (window.location.hash = "_"), tagging = !1, sgFirstClick = !0, jQuery("body").css("overflow", "visible"), jQuery("html").css("overflow", "visible")
}

function sgp0ca() {
    return window.location.pathname
}

function sgpa6fe() {
    var e = window.location.href,
        s = window.location.hash,
        i = e.indexOf(s) || e.length;
    return e.substr(0, i)
}

function sgp52517(e, s, i, g, n, o) {
    if ("undefined" == typeof n) var n = !1;
    if ("undefined" == typeof o) var o = 1.1;
    var t = Math.min(e / i, s / g),
        a = i * t,
        r = g * t;
    if (n) {
        if (a > i * o || r > g * o) var t = Math.min(i * o / i, g * o / g),
            a = i * t,
            r = g * t
    } else(a > i || r > g) && (a = i, r = g);
    var d = .5 * e - .5 * a,
        p = .5 * s - .5 * r,
        c = new Array;
    return c[0] = a, c[1] = r, c[2] = d, c[3] = p, c
}

function sgp94bb() {
    if ("undefined" == typeof window.sgp_config.sgp_dcsss || "" == window.sgp_config.sgp_dcsss) var e = jQuery(window.sgpCSSselector).not(window.sgpCSSdeselector);
    else var e = jQuery(window.sgpCSSselector).not(window.sgpCSSdeselector).not(window.sgp_config.sgp_dcsss);
    return e
}

function sgpTheme() {
    window.sgptheme.themename = "classic", "undefined" != typeof window.sgp_config.sgp_theme && "" != window.sgp_config.sgp_theme && "undefined" != typeof window.sgp_config.sgp_theme_root && "" != window.sgp_config.sgp_theme_root && (window.sgptheme.themename = window.sgp_config.sgp_theme), window.sgptheme.themedir = window.sgp_config.sgp_theme_root + window.sgptheme.themename + "/", window.sgptheme.iLe = window.sgptheme.themedir + "l.png", window.sgptheme.iRi = window.sgptheme.themedir + "r.png", window.sgptheme.iLo = window.sgptheme.themedir + "loading.gif", window.sgptheme.iFs = window.sgptheme.themedir + "fullscreen.png"
}



function rebind() {
    jQuery(".sgs-image-wrap-jig").mouseenter(function() {
        jQuery("._53d", this).show()
    }).mouseleave(function() {
        jQuery("._53d", this).hide()
    });
    jQuery(".sgs-image-wrap").mouseenter(function() {
        jQuery("._53d", this).show()
    }).mouseleave(function() {
        jQuery("._53d", this).hide()
    });
    jQuery(".sgTagging").unbind("click").click(function(e) {
        jQuery("#sgControls").hide();
        LBtags = '<div class="sgBox" style="width: 94px; height: 94px;"></div><div class="sgTagOptions" display: block;"><i class="_53io" style="left: 50%; margin-left: -8px;"></i><div class = "sgTagService"></div></div>';
        jQuery(".sgpI").after(LBtags);
        jQuery(".sgpI").addClass("sgTaggable");
        jQuery(".sgBoxSug").show();
        jQuery(".sgBoxT").show();
        SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
        fblogin()
    });
    jQuery(".detectFace").click(function() {
        sgDetectFaces()
    });
    jQuery(".epicTag").click(function() {
        if (!tagging) {
            jQuery(".sgTagPhoto img").addClass("sgTaggable");
            EpicTagHtml = jQuery(this).html();
            jQuery(this).html('<span class="uiButtonText">Finished tagging</span>');
            jQuery(this).css("width", "150px");
            tagging = true
        } else {
            jQuery(".sgTagPhoto img").removeClass("sgTaggable");
            jQuery(".sgBox").hide();
            jQuery(".sgTagOptions").hide();
            jQuery(this).html(EpicTagHtml);
            jQuery(this).css("width", "85px");
            tagging = false
        }
    })
}

function add_social_meta(e) {
    if (jQuery(".justified-image-grid").length > 0) {
        JiG = true
    }
    if (JiG) {
        ssc_i = e.parent("a").attr("href")
    } else {
        ssc_i = e.attr("src")
    }
    ssc = getEpicPermalinkIfExists(ssc_i);
    if (ssc == "") {
        ssc = ssc_i
    } else {
        ssc = window.sgp_config.sgp_slug + ssc
    }
    if (JiG) {} else {
        html = '<span class="_53d" style="display:none;"><div class="_53g"><div class="_53i"></div></div><div class="_53k" id="u_jsonp_20_2n"><a class="_53f _53fl sgs-comment" data-sgsc="' + ssc + '">Comment</a><a class="_53e _53f _53fr"><div class="_53z fblikes sgs-comment" data-sgsc="' + ssc + '" rel=""><span class="_53n"></span><span class="_53m"></span></div></a></div><div class="sgs"></div></span>';
        if (jQuery(".social-gallery-shortcode").length > 0) {} else {
            e.parent("a").wrap('<div class="sgs-image-wrap" />')
        }
        e.parent("a").after(html)
    }
    perma = "<a href = '" + ssc + "'>" + ssc + "</a>"
}

function epic_images() {
    grad = window.sgp_config.sgp_iRoot + "img/gradient.png";
    if (jQuery(".justified-image-grid").length > 0) {
        JiG = true;
        if (window.sgp_config.sgp_JiG == 1) {
            jQuery(".jig-caption").remove()
        }
    }
    if (jQuery(".ngg-gallery-thumbnail").length > 0) {
        return false
    }
    if (window.sgp_config.sgp_JiG == 1) {
        jQuery(".jig-imageContainer").each(function() {
            if (jQuery(this).hasClass("sgs-tagged")) {} else {
                jQuery(this).wrap('<div class="sgs-image-wrap-jig" />');
                ssc_i = jQuery(".jig-loaded", this).attr("href");
                ssc = getEpicPermalinkIfExists(ssc_i);
                if (ssc == "") {
                    ssc = ssc_i
                } else {
                    ssc = window.sgp_config.sgp_slug + ssc
                }
                html = '<div class="_53d" style="display:none;"><div class="_53g"><div class="_53i"></div></div><div class="_53k" id="u_jsonp_20_2n"><a class="_53f _53fl sgs-comment" data-sgsc="' + ssc + '">Comment</a><a class="_53e _53f _53fr"><div class="_53z fblikes sgs-comment" data-sgsc="' + ssc + '" rel=""><span class="_53n"></span><span class="_53m"></span></div></a></div><div class="sgs"></div></div>';
                jQuery(".jig-loaded", this).after(html);
                jQuery(".jig-caption-wrapper").remove();
                jQuery(".jig-overlay-wrapper").remove();
                jQuery(".jig-border").remove();
                jQuery(this).addClass("sgs-tagged")
            }
        })
    }
    jQuery("#content img").each(function() {
        current_image = jQuery(this);
        if (jQuery(this).hasClass("sgs-image")) {
            if (!jQuery(this).hasClass("jig-hiddenImg")) {
                jQuery(this).addClass("sgs-jig-image");
                add_social_meta(current_image);
                jQuery(this).removeClass("sgs-image")
            } else {
                return true
            }
        } else {
            return true
        }
    });
    if (jQuery(".social-gallery-shortcode").length > 0) {} else {}
    if (jQuery(".justified-image-grid").length == 0) {
        jQuery(".sgs-image-holder").after('<div style = "clear:both"></div>')
    }
}

function getEpicPermalinkIfExists(e) {
    var t = false;
    var n = e;
    var r = "";
    jQuery.each(window.sgi, function(e, i) {
        if (window.sgi[e][0] == n) {
            r = window.sgi[e][1];
            window.sgpcurrperm = r;
            t = true;
            return false
        }
        var s = sgpe5a3(n);
        if (window.sgi[e][0] == s) {
            r = window.sgi[e][1];
            window.sgpcurrperm = r;
            t = true;
            return false
        }
    });
    return r
}

function getLikes(e) {
    topreach = 0;
    topelem = 0;
    jQuery(".fblikes").each(function() {
        var e = jQuery(this);
        var t = e.attr("data-sgsc");
        jQuery.getJSON("http://graph.facebook.com/" + t, function(t) {
            e.find("> ._53n").text(t.shares || 0);
            e.find("> ._53m").text(t.comments || 0);
            curreach = t.shares
        });
        jQuery(this).removeClass("fblikes")
    })
}

function socialgal() {
    jQuery(".sg-item").mouseenter(function() {
        jQuery(this).show();
        jQuery(this).find("> .fave").show();
        jQuery(this).find("> .nofave").show()
    });
    jQuery(".sg-item").mouseleave(function() {
        jQuery(this).find("> ._53d").hide();
        jQuery(this).find("> .fave").hide();
        jQuery(this).find("> .nofave").hide()
    });
    jQuery(".sgs-comment").click(function(e) {
        posit = jQuery(this).offset();
        if (jQuery("#sg-holder").length > 0) {
            parenttop = jQuery("#sg-holder").offset();
            comtop = e.pageY - parenttop.top + 20;
            comleft = posit.left - 150 - parenttop.left
        } else {
            parenttop = jQuery(this).position();
            comtop = e.pageY + 15;
            comleft = e.pageX - 174
        }
        if (showc) {
            if (posit.top == firstpos.top && posit.left == firstpos.left) {
                jQuery(".fb-comment-holder").hide();
                showc = false
            } else {
                jQuery(".fb-comment-holder").css({
                    top: comtop,
                    left: comleft
                }).show();
                showc = true;
                firstpos.top = posit.top;
                firstpos.left = posit.left
            }
        } else {
            jQuery(".fb-comment-holder").css({
                top: comtop,
                left: comleft
            }).show();
            showc = true;
            firstpos = posit;
            firstpos.top = posit.top;
            firstpos.left = posit.left
        }
        like_link = jQuery(this).data("sgsc");
        jQuery(".fb-like").attr("data-href", like_link);
        jQuery(".fb-comments").attr("data-href", like_link);
        FB.XFBML.parse();
        return false
    });
    jQuery(document).click(function() {
        if (showc == true) {
            jQuery(".fb-comment-holder").hide();
            showc = false
        }
    })
}
showc = false;
JiG = false;
wrapped = false;
epicrebind = false;
tagoption = false;
boxSize = 94;
tagging = false;
html = "";
sgsuggested = false;
sgpmobbasic = false;
fblog = false;
jQuery(window).load(function(e) {
    if (jQuery(".fb-comment-holder").length > 0) {} else {
        parenttop = jQuery(".entry-content").offset();
        fbc = '<div class = "fb-comment-holder" id = "sgvFBXML"><i class="_53io" style="left: 50%; margin-left: -8px;"></i><div class="fb-like UFIRow" data-href="" data-layout = "button_count" data-send="false" data-width="348" data-show-faces="false" data-font="arial"></div><div class="fb-comments" data-href="" data-num-posts="10" data-width="348"></div></div>';
        jQuery("body").append(fbc)
    }
    epic_images();
    getLikes();
    socialgal();
    rebind();
    jQuery(".sgBoxT").each(function() {
        img = jQuery(this).siblings("img");
        h = img.height();
        boxSize = h * .12;
        currpos = jQuery(this).position();
        boxTop = currpos.top - boxSize / 2;
        boxLeft = currpos.left - boxSize / 2;
        jQuery(this).css({
            top: boxTop,
            left: boxLeft,
            height: boxSize,
            width: boxSize
        })
    })
});
jQuery(document).ready(function(e) {
    function t(e) {
        html = "";
        FB.api("/me/friends", {
            fields: "name,id"
        }, function(e) {
            items = [];
            for (var t = 0; t < e.data.length; t++) {
                items += '<div class = "tagRow" data-tageen = "' + e.data[t].name + '" data-tagee = "' + e.data[t].id + '"><img src = "http://graph.facebook.com/' + e.data[t].id + '/picture"/ class = "sgTag"><span class = "text"> ' + e.data[t].name + "</span></div>"
            }
            html += '<div class = "tagRow" data-tagee = "' + tagger + '"><img src = "http://graph.facebook.com/' + tagger + '/picture" class = "sgTag"/><span class = "text"> ' + ftaggername + " (me)</span></div>";
            html += items;
            jQuery(".sgTagRows").remove();
            jQuery(".sgTagService").html("<div class = 'sgTagRows'></div>");
            jQuery(".sgTagRows").append(html);
            jQuery(".sgTagRows").before("<div class = 'sgTagSearchC'><input type = 'text' id = 'sgTagSearch' placeholder = 'Type any name'/></div>");
            jQuery(".sgTagRows ._53d").remove();
            jQuery("#sgTagSearch").on("change", function() {
                var e = jQuery(this).val();
                jQuery(".sgTagRows").find(":contains(" + e + ")").show();
                jQuery(".sgTagRows").find(":not(:contains(" + e + "))").hide();
                jQuery(".sgTagRows img").show()
            }).on("keyup", function() {
                jQuery(this).change()
            });
            return true
        })
    }
    sgFirstClick = true;
    fblogin = function() {
        FB.login(function(e) {
            if (e.authResponse) {
                FB.api("/me", {
                    fields: "id,name,picture,gender"
                }, function(e) {
                    tagger = e.id;
                    ftaggername = e.name;
                    t(tagger);
                    return true
                })
            } else {
                return false
            }
        }, {
            scope: "user_friends,publish_actions"
        })
    };
    sgTag = function() {
        FB.getLoginStatus(function(e) {
            if (e.status === "connected") {
                FB.api("/me", {
                    fields: "id,name,picture,gender"
                }, function(e) {
                    console.log(e);
                    tagger = e.id;
                    ftaggername = e.name
                });
                var t = e.authResponse.userID;
                var n = e.authResponse.accessToken
            } else {
                if (e.status === "not_authorized") {
                    fblogin()
                } else {}
            }
        }, {
            scope: "user_friends,publish_actions"
        })
    };
    jQuery.expr[":"].contains = e.expr.createPseudo(function(e) {
        return function(t) {
            return jQuery(t).text().toUpperCase().indexOf(e.toUpperCase()) >= 0
        }
    });
    jQuery(document).on("click", ".tagRow", function() {
        tagee = jQuery(this).data("tagee");
        tagee_name = jQuery(this).data("tageen");
        if (sgTagTit == "") {
            sgTagTit = ""
        }
        if (tagee == tagger) {
            FB.api("/me/feed", "post", {
                picture: sgTagsrc,
                name: "Check me out on this photo!!",
                description: sgTagTit,
                link: sgTaglink
            }, function(e) {
                if (e && e.id) {
                    sgLogTag()
                } else {}
            })
        } else {
            FB.ui({
                method: "feed",
                name: "You have been tagged!!",
                to: tagee,
                link: sgTaglink,
                picture: sgTagsrc,
                caption: "You have been tagged in a photo",
                description: sgTagTit
            }, function(e) {
                if (e && e.post_id) {
                    sgLogTag()
                } else {}
            })
        }
    });
    jQuery(document).on("click", ".sgBoxSug", function() {
        sgsuggested = true;
        img = jQuery(".sgpI");
        sgTagsrc = jQuery(".sgpI").attr("src");
        h = img.height();
        w = img.width();
        thist = Number(jQuery(this).css("top").replace("px", ""));
        thisl = Number(jQuery(this).css("left").replace("px", ""));
        thish = jQuery(this).height();
        thisw = jQuery(this).width();
        thisb = thist + thish;
        xrel = (thisl + thisw / 2) / w;
        yrel = (thist + thish / 2) / h;
        hrel = thish / h;
        wrel = thisw / w;
        maxW = Math.min(thisw * 2, 215);
        jQuery(".sgTagOptions").css({
            width: maxW,
            top: thisb + 15,
            left: thisl - maxW / 2 + thisw / 2,
            visibility: "visible"
        });
        sgTag()
    });
    sgLogTag = function() {
        if (typeof tagee_name === "undefined") {
            tagee_name = ftaggername
        }
        img = jQuery(".sgpI");
        h = img.height();
        w = img.width();
        if (!sgsuggested) {
            hrel = h * .12 / h;
            wrel = h * .12 / w
        }
        var t = {
            action: "sgLogTag",
            tagger: tagger,
            tagee: tagee,
            tagger_name: ftaggername,
            tagee_name: tagee_name,
            relx: xrel,
            rely: yrel,
            relh: hrel,
            relw: wrel,
            url: sgTagsrc
        };
        var n = e.ajax({
            url: EpicAjax.ajaxurl,
            type: "POST",
            data: t,
            dataType: "json"
        });
        n.done(function(e) {
            var t = Math.floor(Math.random() * 101) + 50;
            jQuery(".sgBox").hide();
            jQuery(".sgTagOptions").hide();
            if (jQuery(".sgwith").length == 0) {
                jQuery("#sgBlogDesc").append(" - <span class = 'sgwith' style='color:grey'>with</span><span class='sgBoxN' data-tagid='" + t + "' > <a href='https://www.facebook.com/" + tagee + "' target='_blank'>" + tagee_name + "</a></span>")
            } else {
                if (jQuery(".sgBoxN").length > 1) {
                    jQuery(".sgwith").after(" <span class='sgBoxN' data-tagid='" + t + "' ><a href='https://www.facebook.com/" + tagee + "' target='_blank'>" + tagee_name + "</a></span>,")
                } else {
                    jQuery("#sgBlogDesc").append(" and<span class='sgBoxN' data-tagid='" + t + "' > <a href='https://www.facebook.com/" + tagee + "' target='_blank'>" + tagee_name + "</a></span>")
                }
            }
            fch = hrel * h;
            fcw = wrel * w;
            SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
            fct = Math.max(0, yrel * h - fch / 2);
            fcl = Math.max(0, xrel * w - fcw / 2);
            jQuery(".sg-face-tags").append("<div data-sgTN = '" + tagee_name + "' class = 'sgBoxT sgBoxT" + t + "' style = 'height:" + fch + "px;width:" + fcw + "px;top:" + fct + "px;left:" + fcl + "px'></div>");
            if (jQuery(".sgTagName").length == 0) {
                sgTN = '<div class="sgTagName"><i class="_53io" style="left: 50%; margin-left: -8px;"></i></div>';
                jQuery(".sg-face-tags").after(sgTN)
            }
            jQuery("#sgControls").show();
            jQuery(".sgpI").removeClass("sgTaggable");
            jQuery(".sgBoxSug").hide();
            jQuery(".sgBoxT").hide()
        });
        n.fail(function(e, t) {})
    };
    return true
});
jQuery(document).on("mousemove", ".sgTaggable", function(e) {
    w = jQuery(this).width();
    h = jQuery(this).height();
    pos = jQuery(this).offset();
    x = e.pageX - pos.left;
    y = e.pageY - pos.top
});
jQuery(document).on("mousemove", ".sg-faces", function(e) {
    w = jQuery(this).width();
    h = jQuery(this).height();
    pos = jQuery(this).offset();
    fx = e.pageX - pos.left;
    fy = e.pageY - pos.top
});
jQuery(document).on("mouseenter", ".sgBoxT", function() {
    callout = '<i class="_53io" style="left: 50%; margin-left: -8px;"></i>';
    callout += jQuery(this).data("sgtn");
    jQuery(".sgTagName").html(callout);
    nw = jQuery(".sgTagName").width();
    t = jQuery(this).css("top").replace("px", "");
    l = jQuery(this).css("left").replace("px", "");
    h = jQuery(this).height();
    w = jQuery(this).width();
    jQuery(".sgTagName").css({
        top: Number(t) + h + 15,
        left: Number(l) + w / 2 - (nw + 20) / 2
    });
    jQuery(".sgBoxT").show();
    jQuery(".sgTagName").show()
});
jQuery(document).on("mouseleave", ".sgBoxT", function() {
    jQuery(".sgBoxT").hide();
    jQuery(".sgTagName").hide()
});
jQuery(document).on("mouseenter", ".sgBoxN", function() {
    tagIDd = jQuery(this).data("tagid");
    jQuery(".sgBoxT" + tagIDd).show();
    callout = '<i class="_53io" style="left: 50%; margin-left: -8px;"></i>';
    callout += jQuery(".sgBoxT" + tagIDd).data("sgtn");
    jQuery(".sgTagName").html(callout);
    nw = jQuery(".sgTagName").width();
    t = jQuery(".sgBoxT" + tagIDd).css("top").replace("px", "");
    l = jQuery(".sgBoxT" + tagIDd).css("left").replace("px", "");
    h = jQuery(".sgBoxT" + tagIDd).height();
    w = jQuery(".sgBoxT" + tagIDd).width();
    jQuery(".sgTagName").css({
        top: Number(t) + h + 15,
        left: Number(l) + w / 2 - (nw + 20) / 2
    });
    jQuery(".sgTagName").show()
});
jQuery(document).on("mouseleave", ".sgBoxN", function() {
    tagIDd = jQuery(this).data("tagid");
    jQuery(".sgBoxT" + tagIDd).hide();
    jQuery(".sgTagName").hide()
});
jQuery(document).on("click", ".sgTaggable", function(e) {
    sgTagTit = jQuery(this).data("title");
    sgTagsrc = jQuery(".sgpI").attr("src");
    sgsuggested = false;
    sgTag();
    boxSize = h * .12;
    boxMin = Math.min(w - 4, h - 3);
    if (boxMin < boxSize) {
        boxSize = boxMin
    }
    sgBoxtop = Math.max(y - boxSize / 2, 0);
    sgBoxleft = Math.max(x - boxSize / 2, 0);
    sgBoxright = sgBoxleft + boxSize;
    sgBoxbottom = sgBoxtop + boxSize;
    if (sgBoxright > w) {
        sgBoxleft = sgBoxleft - (sgBoxright - w + 4)
    }
    if (sgBoxbottom > h) {
        sgBoxtop = sgBoxtop - (sgBoxbottom - h + 5)
    }
    if (typeof SGPmargin != "undefined") {
        sgBoxtop = sgBoxtop + Number(SGPmargin)
    }
    sgBoxbottom = sgBoxtop + boxSize;
    jQuery(".sgBox").css({
        top: sgBoxtop,
        left: sgBoxleft,
        visibility: "visible",
        height: boxSize,
        width: boxSize
    });
    maxW = Math.max(boxSize * 2, 215);
    jQuery(".sgTagOptions").css({
        width: maxW,
        top: sgBoxbottom + 15,
        left: sgBoxleft - maxW / 2 + boxSize / 2,
        visibility: "visible"
    });
    yrel = (y + Number(SGPmargin)) / h;
    xrel = x / w
});
sgDetectFaces = function() {
    var e = {
        action: "socialGallery_facedetect",
        img: sgURL
    };
    var t = jQuery.ajax({
        url: EpicAjax.ajaxurl,
        type: "POST",
        data: e,
        dataType: "json"
    });
    t.done(function(e) {
        if (e.status == "success") {
            photoW = e.photos[0].width;
            photoH = e.photos[0].height;
            jQuery.each(e.photos[0].tags, function(t) {
                fcx = e.photos[0].tags[t].center.x;
                fcy = e.photos[0].tags[t].center.y;
                fch = e.photos[0].tags[t].height;
                fcw = e.photos[0].tags[t].width;
                fct = (fcy - fch / 2) / photoH * 100;
                fcl = (fcx - fcw / 2) / photoW * 100;
                fch = fch / photoH * 100;
                fcw = fcw / photoW * 100;
                SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
                img = jQuery(".sgpI");
                h = img.height();
                w = img.width();
                fctp = fct / 100 * h + Number(SGPmargin);
                fclp = fcl / 100 * w;
                fchp = fch / 100 * h;
                fcwp = fcw / 100 * w;
                jQuery(".sg-face-tags").append("<div class = 'sgBoxSug' style = 'height:" + fchp + "px;width:" + fcwp + "px;top:" + fctp + "px;left:" + fclp + "px'></div>")
            })
        } else {
            return false
        }
    });
    t.fail(function(e, t) {})
};
sgGetTags = function() {
    var e = {
        action: "get_sg_tags_ajax",
        img: sgURL
    };
    var t = jQuery.ajax({
        url: EpicAjax.ajaxurl,
        type: "POST",
        data: e,
        dataType: "json"
    });
    t.done(function(t) {
        if (typeof t[0] === "undefined") {
            return false
        } else {
            img = jQuery(".sgpI");
            h = img.height();
            w = img.width();
            e = 0;
            jQuery.each(t, function(n) {
                e = n + 1;
                if (n == 0) {
                    jQuery("#sgBlogDesc").append(" - <span class = 'sgwith' style='color:grey'>with</span><span class='sgBoxN' data-tagid='" + t[n].sg_tid + "' > <a href='https://www.facebook.com/" + t[n].sg_taggee_id + "' target='_blank'>" + t[n].sg_taggee_name + "</a></span>")
                } else {
                    if (e == t.length) {
                        jQuery("#sgBlogDesc").append(" and<span class='sgBoxN' data-tagid='" + t[n].sg_tid + "' > <a href='https://www.facebook.com/" + t[n].sg_taggee_id + "' target='_blank'>" + t[n].sg_taggee_name + "</a></span>")
                    } else {
                        jQuery("#sgBlogDesc").append(", <span class='sgBoxN' data-tagid='" + t[n].sg_tid + "' ><a href='https://www.facebook.com/" + t[n].sg_taggee_id + "' target='_blank'>" + t[n].sg_taggee_name + "</a></span>")
                    }
                }
                fch = t[n].sg_relh * h;
                fcw = t[n].sg_relw * w;
                SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
                fct = Math.max(0, t[n].sg_rely * h - fch / 2);
                fcl = Math.max(0, t[n].sg_relx * w - fcw / 2);
                jQuery(".sg-face-tags").append("<div data-sgTN = '" + t[n].sg_taggee_name + "' class = 'sgBoxT sgBoxT" + t[n].sg_tid + "' style = 'height:" + fch + "px;width:" + fcw + "px;top:" + fct + "px;left:" + fcl + "px'></div>")
            });
            sgTN = '<div class="sgTagName"><i class="_53io" style="left: 50%; margin-left: -8px;"></i></div>';
            jQuery(".sg-face-tags").after(sgTN)
        }
    });
    t.fail(function(e, t) {})
};






var sgURL;
sga_125_log = function() {
    var e = {
            action: "sga_analytics_js",
            img: sgURL
        },
        s = jQuery.ajax({
            url: EpicAjax.ajaxurl,
            type: "POST",
            data: e,
            dataType: "json"
        });
    s.done(function(e) {}), s.fail(function(e, s) {})
};
var sgpVerifiedJQ = !1,
    jQueryVersionError = "";
if (window.jQuery)
    if ("undefined" != typeof jQuery.fn.jquery) try {
        var jqv = jQuery.fn.jquery.split("."),
            verNo = jqv[0],
            sV = jqv[1];
        parseInt(sV) > 9 ? verNo = parseInt(verNo) + 1 : verNo += "." + sV;
        var jqvf = parseFloat(verNo).toFixed(2);
        jqvf >= 1.8 ? sgpVerifiedJQ = !0 : jQueryVersionError = "Your jQuery version is out of date! (Version: " + jQuery.fn.jquery + ")"
    } catch (e) {
        jQueryVersionError = "No valid version of jQuery could be found"
    } else jQueryVersionError = "No valid version of jQuery could be found";
    else jQueryVersionError = "No valid version of jQuery could be found";
if (sgpVerifiedJQ) {
    var sgCurrind = -1,
        sgpDisFire = !1,
        sgpDiR = 0,
        sgpTwR = 0,
        sgpFbR = 0,
        sgpPinR = 0,
        sgpGogR = 0,
        sgpSuR = 0,
        sgpTumR = 0,
        sgpCSSselector = "#nothinghere",
        sgp8b7a17 = !1,
        sgpDomW = 0,
        sgpDomH = 0,
        sgpc674b17 = !1,
        sgpCSSdeselector = ".noSocialGallery, .noLightBox, .pin-it-button, .jig-customLink",
        sgptheme = [],
        sgpcurrperm = "";
    switch (parseInt(window.sgp_config.sgp_selT)) {
        case 1:
            sgpCSSselector = ".entry a:has(img), .entry-content a:has(img), .entry_content a:has(img), .content a:has(img), #content a:has(img)";
            break;
        case 10:
            sgpCSSselector = ".post a:has(img), .post-content a:has(img), .postcontent a:has(img), .post-data a:has(img), .single-post a:has(img)";
            break;
        case 11:
            sgpCSSselector = ".jigSgConnect a";
            break;
        case 12:
            sgpCSSselector = ".esgbox";
            break;
        case 13:
            sgpCSSselector = ".ftg-lightbox";
            break;
        case 2:
            sgpCSSselector = window.sgp_config.sgp_sel;
            break;
        case 3:
            sgpCSSselector = ".page a:has(img), .page-content a:has(img), .page-data a:has(img), .pagecontent a:has(img)";
            break;
        case 4:
            sgpCSSselector = ".entry a:has(img), .entry-content a:has(img), .entry_content a:has(img), .entry-image a:has(img), .content a:has(img), #content a:has(img), #contentwide  a:has(img), article a:has(img), .page a:has(img), .page-content a:has(img), .post a:has(img), .post-content a:has(img), .post-data a:has(img), .postcontent a:has(img), .gallery a:has(img), .gallery-item a:has(img), .blog-content a:has(img), .thumb a:has(img), .single-post a:has(img), .block-content a:has(img), .gallery-icon";
            break;
        case 5:
            sgpCSSselector = ".gallery a:has(img), .gallery-item a:has(img), .dcs-gallery-thumbs a:has(img), .thumb a:has(img), .gallery-icon a:has(img)";
            break;
        case 6:
            sgpCSSselector = ".ngg-galleryoverview a:has(img), .ngg-gallery-thumbnail-box a:has(img), .ngg-gallery-thumbnail a:has(img), .ngg-galleryoverview a:has(img), .ngg-widget a:has(img)";
            break;
        case 7:
            sgpCSSselector = ".ngg-gallery-thumbnail a:has(img), .ngg-gallery-thumbnail-box a:has(img)";
            break;
        case 8:
            sgpCSSselector = ".ngg-widget a:has(img)";
            break;
        case 9:
            sgpCSSselector = ".ngg-galleryoverview a:has(img)";
            break;
        default:
            sgpCSSselector = ".entry a:has(img), .entry-content a:has(img), .entry_content a:has(img), .content a:has(img), #content a:has(img)"
    }
    if (sgpCSSselector += ", .socialGalleryItemImage a:has(img)", "" != window.sgp_config.sgp_dcn) var disqus_shortname = window.sgp_config.sgp_dcn;
    !jQuery.isFunction(window.sgp70da), jQuery.isFunction(jQuery.fn.wExists) || (jQuery.fn.wExists = function() {
        return this.length > 0
    }), jQuery(window).load(function() {
        sgpTheme(), setTimeout(function() {
            if ("#sg" == window.location.hash.substr(0, 3)) {
                var e = parseInt(window.location.hash.substr(3));
                if (sgp94bb().length >= e) {
                    var s = sgp94bb().get(e - 1),
                        i = jQuery(s).attr("href"),
                        g = getTitle(s),
                        n = getDesc(s),
                        o = parseInt(sgp94bb().index(s)) + 1;
                    "" != i && "undefined" != typeof i && "undefined" != i && (sgp01e4(), jQuery("#sgPluginLoader").html('<img src="' + i + '" title="' + g + '" alt="" class="sgpI" />'), jQuery("#sgPluginLoader img").attr("title", g), "undefined" != typeof n && "" != n && jQuery("#sgPluginLoader img").attr("data-desc", n), jQuery("#sgPluginLoader img").load(function() {
                        jQuery("#sgCont").html(""), jQuery("#sgPluginLoader img").appendTo("#sgCont"), sgpf19bc26(), sgp94bb().length > 1 && sgpbe330b7(), sgp4d5df(o), sgpe5c35()
                    }), sgpe71a8c(), sgp782498(o)), window.sgCurrind = o
                }
            }
        }, 300)
    }), jQuery(document).ready(function() {
        jQuery(window).resize(function() {
            wheight = jQuery(window).height()
        }), jQuery("body").append('<div id="sgPluginBg"></div><div id="sgPluginBox"><div id="sgCont"></div><div id="sgSide"><div id="sgSideWrap"></div></div><div id="sgPluginBoxClose">x</div></div><div id="sgPluginLoader"></div><div id="sgDisqusHold" style="display:none"><div id="disqus_thread"></div></div>'), "1" == window.sgp_config.sgp_dc && ! function() {
            var e = document.createElement("script");
            e.type = "text/javascript", e.async = !0, e.src = "http://" + window.sgp_config.sgp_dcn + ".disqus.com/embed.js", (document.getElementsByTagName("head")[0] || document.getElementsByTagName("body")[0]).appendChild(e)
        }(), "" != window.sgp_config.sgp_bg && "000000" != window.sgp_config.sgp_bg && jQuery("#sgPluginBg").css("background-color", "#" + window.sgp_config.sgp_bg), "" != window.sgp_config.sgp_bgo && jQuery("#sgPluginBg").css("opacity", window.sgp_config.sgp_bgo), +new Date, socialGalleryBind(), jQuery(function() {
            var e = setInterval(function() {
                socialGalleryBind()
            }, 1e3);
            setTimeout(function() {
                clearInterval(e)
            }, 6e3)
        }), +new Date, jQuery("#sgPluginBoxClose").click(function() {
            sgp7423()
        }), jQuery("#sgPluginBg").click(function() {
            sgp7423()
        }), jQuery(window).resize(function() {
            "block" == jQuery("#sgPluginBg").css("display") && (sgpf19bc26(), sgpe5c35())
        }), sgpb4a(), jQuery(document).on("click", ".sgmobdone", function() {
            jQuery("#sgmobbg").remove(), jQuery("#sgPluginBox").remove(), jQuery("#sgPluginBg").remove()
        })
    }), jQuery(window).load(function() {
        jQuery("#social-auto").length > 0 && jQuery("#social-auto").click()
    }), Date.now || (Date.now = function() {
        return (new Date).getTime()
    });
    var sgpAdTime = socialGallery_uts()
} else alert("Social Gallery: jQuery Error: " + jQueryVersionError);