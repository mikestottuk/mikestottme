
function rebind() {
    jQuery(".sgs-image-wrap-jig").mouseenter(function() {
        jQuery("._53d", this).show()
    }).mouseleave(function() {
        jQuery("._53d", this).hide()
    });
    jQuery(".sgs-image-wrap").mouseenter(function() {
        jQuery("._53d", this).show()
    }).mouseleave(function() {
        jQuery("._53d", this).hide()
    });
    jQuery(".sgTagging").unbind("click").click(function(e) {
        jQuery("#sgControls").hide();
        LBtags = '<div class="sgBox" style="width: 94px; height: 94px;"></div><div class="sgTagOptions" display: block;"><i class="_53io" style="left: 50%; margin-left: -8px;"></i><div class = "sgTagService"></div></div>';
        jQuery(".sgpI").after(LBtags);
        jQuery(".sgpI").addClass("sgTaggable");
        jQuery(".sgBoxSug").show();
        jQuery(".sgBoxT").show();
        SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
        fblogin()
    });
    jQuery(".detectFace").click(function() {
        sgDetectFaces()
    });
    jQuery(".epicTag").click(function() {
        if (!tagging) {
            jQuery(".sgTagPhoto img").addClass("sgTaggable");
            EpicTagHtml = jQuery(this).html();
            jQuery(this).html('<span class="uiButtonText">Finished tagging</span>');
            jQuery(this).css("width", "150px");
            tagging = true
        } else {
            jQuery(".sgTagPhoto img").removeClass("sgTaggable");
            jQuery(".sgBox").hide();
            jQuery(".sgTagOptions").hide();
            jQuery(this).html(EpicTagHtml);
            jQuery(this).css("width", "85px");
            tagging = false
        }
    })
}

function add_social_meta(e) {
    if (jQuery(".justified-image-grid").length > 0) {
        JiG = true
    }
    if (JiG) {
        ssc_i = e.parent("a").attr("href")
    } else {
        ssc_i = e.attr("src")
    }
    ssc = getEpicPermalinkIfExists(ssc_i);
    if (ssc == "") {
        ssc = ssc_i
    } else {
        ssc = window.sgp_config.sgp_slug + ssc
    }
    if (JiG) {} else {
        html = '<span class="_53d" style="display:none;"><div class="_53g"><div class="_53i"></div></div><div class="_53k" id="u_jsonp_20_2n"><a class="_53f _53fl sgs-comment" data-sgsc="' + ssc + '">Comment</a><a class="_53e _53f _53fr"><div class="_53z fblikes sgs-comment" data-sgsc="' + ssc + '" rel=""><span class="_53n"></span><span class="_53m"></span></div></a></div><div class="sgs"></div></span>';
        if (jQuery(".social-gallery-shortcode").length > 0) {} else {
            e.parent("a").wrap('<div class="sgs-image-wrap" />')
        }
        e.parent("a").after(html)
    }
    perma = "<a href = '" + ssc + "'>" + ssc + "</a>"
}

function epic_images() {
    grad = window.sgp_config.sgp_iRoot + "img/gradient.png";
    if (jQuery(".justified-image-grid").length > 0) {
        JiG = true;
        if (window.sgp_config.sgp_JiG == 1) {
            jQuery(".jig-caption").remove()
        }
    }
    if (jQuery(".ngg-gallery-thumbnail").length > 0) {
        return false
    }
    if (window.sgp_config.sgp_JiG == 1) {
        jQuery(".jig-imageContainer").each(function() {
            if (jQuery(this).hasClass("sgs-tagged")) {} else {
                jQuery(this).wrap('<div class="sgs-image-wrap-jig" />');
                ssc_i = jQuery(".jig-loaded", this).attr("href");
                ssc = getEpicPermalinkIfExists(ssc_i);
                if (ssc == "") {
                    ssc = ssc_i
                } else {
                    ssc = window.sgp_config.sgp_slug + ssc
                }
                html = '<div class="_53d" style="display:none;"><div class="_53g"><div class="_53i"></div></div><div class="_53k" id="u_jsonp_20_2n"><a class="_53f _53fl sgs-comment" data-sgsc="' + ssc + '">Comment</a><a class="_53e _53f _53fr"><div class="_53z fblikes sgs-comment" data-sgsc="' + ssc + '" rel=""><span class="_53n"></span><span class="_53m"></span></div></a></div><div class="sgs"></div></div>';
                jQuery(".jig-loaded", this).after(html);
                jQuery(".jig-caption-wrapper").remove();
                jQuery(".jig-overlay-wrapper").remove();
                jQuery(".jig-border").remove();
                jQuery(this).addClass("sgs-tagged")
            }
        })
    }
    jQuery("#content img").each(function() {
        current_image = jQuery(this);
        if (jQuery(this).hasClass("sgs-image")) {
            if (!jQuery(this).hasClass("jig-hiddenImg")) {
                jQuery(this).addClass("sgs-jig-image");
                add_social_meta(current_image);
                jQuery(this).removeClass("sgs-image")
            } else {
                return true
            }
        } else {
            return true
        }
    });
    if (jQuery(".social-gallery-shortcode").length > 0) {} else {}
    if (jQuery(".justified-image-grid").length == 0) {
        jQuery(".sgs-image-holder").after('<div style = "clear:both"></div>')
    }
}

function getEpicPermalinkIfExists(e) {
    var t = false;
    var n = e;
    var r = "";
    jQuery.each(window.sgi, function(e, i) {
        if (window.sgi[e][0] == n) {
            r = window.sgi[e][1];
            window.sgpcurrperm = r;
            t = true;
            return false
        }
        var s = sgpe5a3(n);
        if (window.sgi[e][0] == s) {
            r = window.sgi[e][1];
            window.sgpcurrperm = r;
            t = true;
            return false
        }
    });
    return r
}

function getLikes(e) {
    topreach = 0;
    topelem = 0;
    jQuery(".fblikes").each(function() {
        var e = jQuery(this);
        var t = e.attr("data-sgsc");
        jQuery.getJSON("http://graph.facebook.com/" + t, function(t) {
            e.find("> ._53n").text(t.shares || 0);
            e.find("> ._53m").text(t.comments || 0);
            curreach = t.shares
        });
        jQuery(this).removeClass("fblikes")
    })
}

function socialgal() {
    jQuery(".sg-item").mouseenter(function() {
        jQuery(this).show();
        jQuery(this).find("> .fave").show();
        jQuery(this).find("> .nofave").show()
    });
    jQuery(".sg-item").mouseleave(function() {
        jQuery(this).find("> ._53d").hide();
        jQuery(this).find("> .fave").hide();
        jQuery(this).find("> .nofave").hide()
    });
    jQuery(".sgs-comment").click(function(e) {
        posit = jQuery(this).offset();
        if (jQuery("#sg-holder").length > 0) {
            parenttop = jQuery("#sg-holder").offset();
            comtop = e.pageY - parenttop.top + 20;
            comleft = posit.left - 150 - parenttop.left
        } else {
            parenttop = jQuery(this).position();
            comtop = e.pageY + 15;
            comleft = e.pageX - 174
        }
        if (showc) {
            if (posit.top == firstpos.top && posit.left == firstpos.left) {
                jQuery(".fb-comment-holder").hide();
                showc = false
            } else {
                jQuery(".fb-comment-holder").css({
                    top: comtop,
                    left: comleft
                }).show();
                showc = true;
                firstpos.top = posit.top;
                firstpos.left = posit.left
            }
        } else {
            jQuery(".fb-comment-holder").css({
                top: comtop,
                left: comleft
            }).show();
            showc = true;
            firstpos = posit;
            firstpos.top = posit.top;
            firstpos.left = posit.left
        }
        like_link = jQuery(this).data("sgsc");
        jQuery(".fb-like").attr("data-href", like_link);
        jQuery(".fb-comments").attr("data-href", like_link);
        FB.XFBML.parse();
        return false
    });
    jQuery(document).click(function() {
        if (showc == true) {
            jQuery(".fb-comment-holder").hide();
            showc = false
        }
    })
}
showc = false;
JiG = false;
wrapped = false;
epicrebind = false;
tagoption = false;
boxSize = 94;
tagging = false;
html = "";
sgsuggested = false;
sgpmobbasic = false;
fblog = false;
jQuery(window).load(function(e) {
    if (jQuery(".fb-comment-holder").length > 0) {} else {
        parenttop = jQuery(".entry-content").offset();
        fbc = '<div class = "fb-comment-holder" id = "sgvFBXML"><i class="_53io" style="left: 50%; margin-left: -8px;"></i><div class="fb-like UFIRow" data-href="" data-layout = "button_count" data-send="false" data-width="348" data-show-faces="false" data-font="arial"></div><div class="fb-comments" data-href="" data-num-posts="10" data-width="348"></div></div>';
        jQuery("body").append(fbc)
    }
    epic_images();
    getLikes();
    socialgal();
    rebind();
    jQuery(".sgBoxT").each(function() {
        img = jQuery(this).siblings("img");
        h = img.height();
        boxSize = h * .12;
        currpos = jQuery(this).position();
        boxTop = currpos.top - boxSize / 2;
        boxLeft = currpos.left - boxSize / 2;
        jQuery(this).css({
            top: boxTop,
            left: boxLeft,
            height: boxSize,
            width: boxSize
        })
    })
});
jQuery(document).ready(function(e) {
    function t(e) {
        html = "";
        FB.api("/me/friends", {
            fields: "name,id"
        }, function(e) {
            items = [];
            for (var t = 0; t < e.data.length; t++) {
                items += '<div class = "tagRow" data-tageen = "' + e.data[t].name + '" data-tagee = "' + e.data[t].id + '"><img src = "http://graph.facebook.com/' + e.data[t].id + '/picture"/ class = "sgTag"><span class = "text"> ' + e.data[t].name + "</span></div>"
            }
            html += '<div class = "tagRow" data-tagee = "' + tagger + '"><img src = "http://graph.facebook.com/' + tagger + '/picture" class = "sgTag"/><span class = "text"> ' + ftaggername + " (me)</span></div>";
            html += items;
            jQuery(".sgTagRows").remove();
            jQuery(".sgTagService").html("<div class = 'sgTagRows'></div>");
            jQuery(".sgTagRows").append(html);
            jQuery(".sgTagRows").before("<div class = 'sgTagSearchC'><input type = 'text' id = 'sgTagSearch' placeholder = 'Type any name'/></div>");
            jQuery(".sgTagRows ._53d").remove();
            jQuery("#sgTagSearch").on("change", function() {
                var e = jQuery(this).val();
                jQuery(".sgTagRows").find(":contains(" + e + ")").show();
                jQuery(".sgTagRows").find(":not(:contains(" + e + "))").hide();
                jQuery(".sgTagRows img").show()
            }).on("keyup", function() {
                jQuery(this).change()
            });
            return true
        })
    }
    sgFirstClick = true;
    fblogin = function() {
        FB.login(function(e) {
            if (e.authResponse) {
                FB.api("/me", {
                    fields: "id,name,picture,gender"
                }, function(e) {
                    tagger = e.id;
                    ftaggername = e.name;
                    t(tagger);
                    return true
                })
            } else {
                return false
            }
        }, {
            scope: "user_friends,publish_actions"
        })
    };
    sgTag = function() {
        FB.getLoginStatus(function(e) {
            if (e.status === "connected") {
                FB.api("/me", {
                    fields: "id,name,picture,gender"
                }, function(e) {
                    console.log(e);
                    tagger = e.id;
                    ftaggername = e.name
                });
                var t = e.authResponse.userID;
                var n = e.authResponse.accessToken
            } else {
                if (e.status === "not_authorized") {
                    fblogin()
                } else {}
            }
        }, {
            scope: "user_friends,publish_actions"
        })
    };
    jQuery.expr[":"].contains = e.expr.createPseudo(function(e) {
        return function(t) {
            return jQuery(t).text().toUpperCase().indexOf(e.toUpperCase()) >= 0
        }
    });
    jQuery(document).on("click", ".tagRow", function() {
        tagee = jQuery(this).data("tagee");
        tagee_name = jQuery(this).data("tageen");
        if (sgTagTit == "") {
            sgTagTit = ""
        }
        if (tagee == tagger) {
            FB.api("/me/feed", "post", {
                picture: sgTagsrc,
                name: "Check me out on this photo!!",
                description: sgTagTit,
                link: sgTaglink
            }, function(e) {
                if (e && e.id) {
                    sgLogTag()
                } else {}
            })
        } else {
            FB.ui({
                method: "feed",
                name: "You have been tagged!!",
                to: tagee,
                link: sgTaglink,
                picture: sgTagsrc,
                caption: "You have been tagged in a photo",
                description: sgTagTit
            }, function(e) {
                if (e && e.post_id) {
                    sgLogTag()
                } else {}
            })
        }
    });
    jQuery(document).on("click", ".sgBoxSug", function() {
        sgsuggested = true;
        img = jQuery(".sgpI");
        sgTagsrc = jQuery(".sgpI").attr("src");
        h = img.height();
        w = img.width();
        thist = Number(jQuery(this).css("top").replace("px", ""));
        thisl = Number(jQuery(this).css("left").replace("px", ""));
        thish = jQuery(this).height();
        thisw = jQuery(this).width();
        thisb = thist + thish;
        xrel = (thisl + thisw / 2) / w;
        yrel = (thist + thish / 2) / h;
        hrel = thish / h;
        wrel = thisw / w;
        maxW = Math.min(thisw * 2, 215);
        jQuery(".sgTagOptions").css({
            width: maxW,
            top: thisb + 15,
            left: thisl - maxW / 2 + thisw / 2,
            visibility: "visible"
        });
        sgTag()
    });
    sgLogTag = function() {
        if (typeof tagee_name === "undefined") {
            tagee_name = ftaggername
        }
        img = jQuery(".sgpI");
        h = img.height();
        w = img.width();
        if (!sgsuggested) {
            hrel = h * .12 / h;
            wrel = h * .12 / w
        }
        var t = {
            action: "sgLogTag",
            tagger: tagger,
            tagee: tagee,
            tagger_name: ftaggername,
            tagee_name: tagee_name,
            relx: xrel,
            rely: yrel,
            relh: hrel,
            relw: wrel,
            url: sgTagsrc
        };
        var n = e.ajax({
            url: EpicAjax.ajaxurl,
            type: "POST",
            data: t,
            dataType: "json"
        });
        n.done(function(e) {
            var t = Math.floor(Math.random() * 101) + 50;
            jQuery(".sgBox").hide();
            jQuery(".sgTagOptions").hide();
            if (jQuery(".sgwith").length == 0) {
                jQuery("#sgBlogDesc").append(" - <span class = 'sgwith' style='color:grey'>with</span><span class='sgBoxN' data-tagid='" + t + "' > <a href='https://www.facebook.com/" + tagee + "' target='_blank'>" + tagee_name + "</a></span>")
            } else {
                if (jQuery(".sgBoxN").length > 1) {
                    jQuery(".sgwith").after(" <span class='sgBoxN' data-tagid='" + t + "' ><a href='https://www.facebook.com/" + tagee + "' target='_blank'>" + tagee_name + "</a></span>,")
                } else {
                    jQuery("#sgBlogDesc").append(" and<span class='sgBoxN' data-tagid='" + t + "' > <a href='https://www.facebook.com/" + tagee + "' target='_blank'>" + tagee_name + "</a></span>")
                }
            }
            fch = hrel * h;
            fcw = wrel * w;
            SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
            fct = Math.max(0, yrel * h - fch / 2);
            fcl = Math.max(0, xrel * w - fcw / 2);
            jQuery(".sg-face-tags").append("<div data-sgTN = '" + tagee_name + "' class = 'sgBoxT sgBoxT" + t + "' style = 'height:" + fch + "px;width:" + fcw + "px;top:" + fct + "px;left:" + fcl + "px'></div>");
            if (jQuery(".sgTagName").length == 0) {
                sgTN = '<div class="sgTagName"><i class="_53io" style="left: 50%; margin-left: -8px;"></i></div>';
                jQuery(".sg-face-tags").after(sgTN)
            }
            jQuery("#sgControls").show();
            jQuery(".sgpI").removeClass("sgTaggable");
            jQuery(".sgBoxSug").hide();
            jQuery(".sgBoxT").hide()
        });
        n.fail(function(e, t) {})
    };
    return true
});
jQuery(document).on("mousemove", ".sgTaggable", function(e) {
    w = jQuery(this).width();
    h = jQuery(this).height();
    pos = jQuery(this).offset();
    x = e.pageX - pos.left;
    y = e.pageY - pos.top
});
jQuery(document).on("mousemove", ".sg-faces", function(e) {
    w = jQuery(this).width();
    h = jQuery(this).height();
    pos = jQuery(this).offset();
    fx = e.pageX - pos.left;
    fy = e.pageY - pos.top
});
jQuery(document).on("mouseenter", ".sgBoxT", function() {
    callout = '<i class="_53io" style="left: 50%; margin-left: -8px;"></i>';
    callout += jQuery(this).data("sgtn");
    jQuery(".sgTagName").html(callout);
    nw = jQuery(".sgTagName").width();
    t = jQuery(this).css("top").replace("px", "");
    l = jQuery(this).css("left").replace("px", "");
    h = jQuery(this).height();
    w = jQuery(this).width();
    jQuery(".sgTagName").css({
        top: Number(t) + h + 15,
        left: Number(l) + w / 2 - (nw + 20) / 2
    });
    jQuery(".sgBoxT").show();
    jQuery(".sgTagName").show()
});
jQuery(document).on("mouseleave", ".sgBoxT", function() {
    jQuery(".sgBoxT").hide();
    jQuery(".sgTagName").hide()
});
jQuery(document).on("mouseenter", ".sgBoxN", function() {
    tagIDd = jQuery(this).data("tagid");
    jQuery(".sgBoxT" + tagIDd).show();
    callout = '<i class="_53io" style="left: 50%; margin-left: -8px;"></i>';
    callout += jQuery(".sgBoxT" + tagIDd).data("sgtn");
    jQuery(".sgTagName").html(callout);
    nw = jQuery(".sgTagName").width();
    t = jQuery(".sgBoxT" + tagIDd).css("top").replace("px", "");
    l = jQuery(".sgBoxT" + tagIDd).css("left").replace("px", "");
    h = jQuery(".sgBoxT" + tagIDd).height();
    w = jQuery(".sgBoxT" + tagIDd).width();
    jQuery(".sgTagName").css({
        top: Number(t) + h + 15,
        left: Number(l) + w / 2 - (nw + 20) / 2
    });
    jQuery(".sgTagName").show()
});
jQuery(document).on("mouseleave", ".sgBoxN", function() {
    tagIDd = jQuery(this).data("tagid");
    jQuery(".sgBoxT" + tagIDd).hide();
    jQuery(".sgTagName").hide()
});
jQuery(document).on("click", ".sgTaggable", function(e) {
    sgTagTit = jQuery(this).data("title");
    sgTagsrc = jQuery(".sgpI").attr("src");
    sgsuggested = false;
    sgTag();
    boxSize = h * .12;
    boxMin = Math.min(w - 4, h - 3);
    if (boxMin < boxSize) {
        boxSize = boxMin
    }
    sgBoxtop = Math.max(y - boxSize / 2, 0);
    sgBoxleft = Math.max(x - boxSize / 2, 0);
    sgBoxright = sgBoxleft + boxSize;
    sgBoxbottom = sgBoxtop + boxSize;
    if (sgBoxright > w) {
        sgBoxleft = sgBoxleft - (sgBoxright - w + 4)
    }
    if (sgBoxbottom > h) {
        sgBoxtop = sgBoxtop - (sgBoxbottom - h + 5)
    }
    if (typeof SGPmargin != "undefined") {
        sgBoxtop = sgBoxtop + Number(SGPmargin)
    }
    sgBoxbottom = sgBoxtop + boxSize;
    jQuery(".sgBox").css({
        top: sgBoxtop,
        left: sgBoxleft,
        visibility: "visible",
        height: boxSize,
        width: boxSize
    });
    maxW = Math.max(boxSize * 2, 215);
    jQuery(".sgTagOptions").css({
        width: maxW,
        top: sgBoxbottom + 15,
        left: sgBoxleft - maxW / 2 + boxSize / 2,
        visibility: "visible"
    });
    yrel = (y + Number(SGPmargin)) / h;
    xrel = x / w
});
sgDetectFaces = function() {
    var e = {
        action: "socialGallery_facedetect",
        img: sgURL
    };
    var t = jQuery.ajax({
        url: EpicAjax.ajaxurl,
        type: "POST",
        data: e,
        dataType: "json"
    });
    t.done(function(e) {
        if (e.status == "success") {
            photoW = e.photos[0].width;
            photoH = e.photos[0].height;
            jQuery.each(e.photos[0].tags, function(t) {
                fcx = e.photos[0].tags[t].center.x;
                fcy = e.photos[0].tags[t].center.y;
                fch = e.photos[0].tags[t].height;
                fcw = e.photos[0].tags[t].width;
                fct = (fcy - fch / 2) / photoH * 100;
                fcl = (fcx - fcw / 2) / photoW * 100;
                fch = fch / photoH * 100;
                fcw = fcw / photoW * 100;
                SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
                img = jQuery(".sgpI");
                h = img.height();
                w = img.width();
                fctp = fct / 100 * h + Number(SGPmargin);
                fclp = fcl / 100 * w;
                fchp = fch / 100 * h;
                fcwp = fcw / 100 * w;
                jQuery(".sg-face-tags").append("<div class = 'sgBoxSug' style = 'height:" + fchp + "px;width:" + fcwp + "px;top:" + fctp + "px;left:" + fclp + "px'></div>")
            })
        } else {
            return false
        }
    });
    t.fail(function(e, t) {})
};
sgGetTags = function() {
    var e = {
        action: "get_sg_tags_ajax",
        img: sgURL
    };
    var t = jQuery.ajax({
        url: EpicAjax.ajaxurl,
        type: "POST",
        data: e,
        dataType: "json"
    });
    t.done(function(t) {
        if (typeof t[0] === "undefined") {
            return false
        } else {
            img = jQuery(".sgpI");
            h = img.height();
            w = img.width();
            e = 0;
            jQuery.each(t, function(n) {
                e = n + 1;
                if (n == 0) {
                    jQuery("#sgBlogDesc").append(" - <span class = 'sgwith' style='color:grey'>with</span><span class='sgBoxN' data-tagid='" + t[n].sg_tid + "' > <a href='https://www.facebook.com/" + t[n].sg_taggee_id + "' target='_blank'>" + t[n].sg_taggee_name + "</a></span>")
                } else {
                    if (e == t.length) {
                        jQuery("#sgBlogDesc").append(" and<span class='sgBoxN' data-tagid='" + t[n].sg_tid + "' > <a href='https://www.facebook.com/" + t[n].sg_taggee_id + "' target='_blank'>" + t[n].sg_taggee_name + "</a></span>")
                    } else {
                        jQuery("#sgBlogDesc").append(", <span class='sgBoxN' data-tagid='" + t[n].sg_tid + "' ><a href='https://www.facebook.com/" + t[n].sg_taggee_id + "' target='_blank'>" + t[n].sg_taggee_name + "</a></span>")
                    }
                }
                fch = t[n].sg_relh * h;
                fcw = t[n].sg_relw * w;
                SGPmargin = jQuery(".sgpI").css("margin-top").replace("px", "");
                fct = Math.max(0, t[n].sg_rely * h - fch / 2);
                fcl = Math.max(0, t[n].sg_relx * w - fcw / 2);
                jQuery(".sg-face-tags").append("<div data-sgTN = '" + t[n].sg_taggee_name + "' class = 'sgBoxT sgBoxT" + t[n].sg_tid + "' style = 'height:" + fch + "px;width:" + fcw + "px;top:" + fct + "px;left:" + fcl + "px'></div>")
            });
            sgTN = '<div class="sgTagName"><i class="_53io" style="left: 50%; margin-left: -8px;"></i></div>';
            jQuery(".sg-face-tags").after(sgTN)
        }
    });
    t.fail(function(e, t) {})
};