
jQuery(document).ready(function() {
    jQuery(".options_pages li").click(function() {
        var b = "div#" + jQuery(this).attr("id");
        var a = "div#" + jQuery(".options_pages li.active").attr("id");
        jQuery(".options_pages li.active").removeClass("active");
        jQuery(this).addClass("active");
        jQuery(a).fadeOut("slow", function() {
            jQuery(b).fadeIn("slow")
        })
    });
    jQuery("form#plugin-options").submit(function() {
        var a = jQuery(this).serialize();
        jQuery.post(ajaxurl, a, function(b) {
            if (b == 0) {
                var d = jQuery("#success-save");
                var c = jQuery("#message-bg");
                d.css("position", "fixed");
                d.css("top", ((jQuery(window).height() - 65) / 2) + jQuery(window).scrollTop() + "px");
                d.css("left", ((jQuery(window).width() - 257) / 2) + jQuery(window).scrollLeft() + "px");
                c.css({
                    height: jQuery(window).height()
                });
                c.css({
                    opacity: 0.45
                });
                c.fadeIn("slow", function() {
                    d.fadeIn("slow", function() {
                        d.delay(1500).fadeOut("fast", function() {
                            c.fadeOut("fast")
                        })
                    })
                })
            } else {}
        });
        return false
    })
});