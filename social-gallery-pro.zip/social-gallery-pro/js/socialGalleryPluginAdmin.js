
/*!
 * Social Gallery - The Ultimate WordPress Social Lightbox
 * http://www.socialgalleryplugin.com
 * V3.2
 *
 * Copyright 2012-2013, Epic Plugins.com, MYO Ltd.
 *
 * Date: 01/11/2013
 */
;
if (!jQuery.isFunction(jQuery.fn.wExists)) {
    jQuery.fn.wExists = function () {
        return this.length > 0
    }
}
jQuery(document).ready(function (a) {
	
	

    socialGalleryAdmin_checkForShows();
    jQuery("#socialGallery_headerBoxType").change(function (b) {
        if (jQuery("#socialGallery_headerBox").attr("checked")) {
            jQuery("#sgWhatHeader").show();
            if (jQuery("#socialGallery_headerBoxType").val() == 1) {
                jQuery("#sgpCustomLogo").show()
            } else {
                jQuery("#sgpCustomLogo").hide()
            } if (jQuery("#socialGallery_headerBoxType").val() == 3) {
                jQuery("#sgpCustomHtml").show()
            } else {
                jQuery("#sgpCustomHtml").hide()
            }
        } else {
            jQuery("#sgWhatHeader").hide();
            jQuery("#sgpCustomLogo").hide();
            jQuery("#sgpCustomHtml").hide()
        }
    });
    jQuery("#upload_image_button").click(function () {
        formfield = jQuery("#socialGallery_headerImg").attr("name");
        tb_show("", "media-upload.php?type=image&amp;TB_iframe=true");
        return false
    });
    jQuery("#socialGallery_selectorType").change(function (b) {
        socialGalleryAdmin_checkForShows()
    });
    window.send_to_editor = function (b) {
        imgurl = jQuery("img", b).attr("src");
        jQuery("#socialGallery_headerImg").val(imgurl);
        tb_remove()
    }
});

function socialGalleryAdmin_checkForShows() {
    if (jQuery("#socialGallery_incDLLink").attr("checked")) {
        jQuery(".imageDownloadLinkShow").show()
    } else {
        jQuery(".imageDownloadLinkShow").hide()
    } if (jQuery("#socialGallery_selectorType").val() == 2) {
        jQuery("#sgpCustomCSS").show()
    } else {
        jQuery("#sgpCustomCSS").hide()
    } if (jQuery("#socialGallery_selectorType").val() == 6 || jQuery("#socialGallery_selectorType").val() == 7 || jQuery("#socialGallery_selectorType").val() == 8 || jQuery("#socialGallery_selectorType").val() == 9) {
        jQuery("#sgpNextGenAutoSwitch").show()
    } else {
        jQuery("#sgpNextGenAutoSwitch").hide()
    } if (jQuery("#socialGallery_incFB:checked").wExists()) {
        jQuery("#facebookFaces").show()
    } else {
        jQuery("#facebookFaces").hide()
    }
    socialGalleryAdmin_showHideFBAppID();
    if (jQuery("#socialGallery_headerBox").attr("checked")) {
        jQuery("#sgWhatHeader").show();
        if (jQuery("#socialGallery_headerBoxType").val() == 1) {
            jQuery("#sgpCustomLogo").show()
        } else {
            jQuery("#sgpCustomLogo").hide()
        } if (jQuery("#socialGallery_headerBoxType").val() == 3) {
            jQuery("#sgpCustomHtml").show()
        } else {
            jQuery("#sgpCustomHtml").hide()
        }
    } else {
        jQuery("#sgWhatHeader").hide();
        jQuery("#sgpCustomLogo").hide();
        jQuery("#sgpCustomHtml").hide()
    } if (jQuery("#socialGallery_bottomBar").attr("checked")) {
        jQuery("#sgWhatPictureBar").show()
    } else {
        jQuery("#sgWhatPictureBar").hide()
    } if (jQuery("#socialGallery_useSGPages").attr("checked")) {
        jQuery(".socialGalleryPagesHide").show()
    } else {
        jQuery(".socialGalleryPagesHide").hide()
    } if (jQuery("#socialGallery_incHomeCall").attr("checked")) {
        jQuery("#affUser").show()
    } else {
        jQuery("#affUser").hide()
    } if (jQuery("#socialGallery_useDFP").attr("checked")) {
        jQuery("#socialGallery_dfpHeadTR, #socialGallery_dfpInlineTR").show()
    } else {
        jQuery("#socialGallery_dfpHeadTR, #socialGallery_dfpInlineTR").hide()
    }
}

function socialGalleryAdmin_showHideFBAppID() {
    if (jQuery("#socialGallery_incFBSRC:checked").wExists()) {
        jQuery("#facebookAppID").show();
        jQuery("#facebookAppIDInfo").show()
    } else {
        jQuery("#facebookAppID").hide();
        jQuery("#facebookAppIDInfo").hide()
    }
}

function socialGalleryAdmin_postToAEP(e, d) {
    var f = {
        action: "SocialGallery",
        socialGalleryRequestVar: e
    };
    jQuery.post(ajaxurl, f, function (a) {
        if (typeof d == "function") {
            d(a)
        }
        return false
    })
}
var ubRunning = false;
var perc = 0;
var crawling = false;
jQuery(document).ready(function (b) {
    jQuery("#startUB").click(function (a) {
        jQuery("#startUBFull").attr("disabled", "disabled").fadeOut(100, function () {});
        jQuery("#startUB").attr("disabled", "disabled").fadeOut(100, function () {
            jQuery("#processUpdate").html("<h4>Running Scan...</h4>")
        });
        jQuery("#ubProgress").fadeIn(5000, function () {
            if (!window.ubRunning) {
                window.ubRunning = true;
                socialGalleryAdmin_postToAEP({
                    t: "initFull"
                }, function (e) {
                    var f = jQuery.parseJSON(e);
                    console.log(f);
                    if (f.s) {
                        jQuery("#progressBar").addClass("animate");
                        socialGalleryAdmin_startCrawlerFull();
                        socialGalleryAdmin_updateStatsFull()
                    }
                })
            }
        })
    });
    jQuery("#startUBFull").click(function (a) {
        jQuery("#startUB").attr("disabled", "disabled").fadeOut(100, function () {});
        jQuery("#startUBFull").attr("disabled", "disabled").fadeOut(100, function () {
            jQuery("#processUpdate").html("<h4>Running Scan...</h4>")
        });
        jQuery("#ubProgress").fadeIn(5000, function () {
            if (!window.ubRunning) {
                window.ubRunning = true;
                socialGalleryAdmin_postToAEP({
                    t: "initFull"
                }, function (e) {
                    var f = jQuery.parseJSON(e);
                    if (f.s) {
                        jQuery("#progressBar").addClass("animate");
                        socialGalleryAdmin_startCrawlerFull();
                        socialGalleryAdmin_updateStatsFull()
                    }
                })
            }
        })
    })
});

function socialGalleryAdmin_updateStats() {
    socialGalleryAdmin_postToAEP({
        t: "stats"
    }, function (c) {
        var d = jQuery.parseJSON(c);
        if (d.s) {
            jQuery("#progMe").css("width", (d.p) + "%");
            window.perc = d.p;
            jQuery("#progressText").html(d.t + "<br />" + d.t2);
            jQuery("#unProcessed").html(d.t);
            jQuery("#imageLib").html(d.i + " images");
            if (parseInt(window.perc) < 100) {
                setTimeout(function () {
                    socialGalleryAdmin_updateStats()
                }, 5000)
            } else {
                jQuery("#progressText").html('<div class="sgsuccess wrap sgM" style="width:382px">Social Gallery Library Update Complete!</div>');
                jQuery("#lastUpdated").html("Completed a moment ago");
                jQuery("#progressBar").removeClass("animate");
                jQuery("#processUpdate").html("<h4>Library Updated...</h4>");
                if (typeof window.onStatCompletion == "function") {
                    window.onStatCompletion()
                }
            }
        }
    })
}

function socialGalleryAdmin_updateStatsFull() {
    socialGalleryAdmin_postToAEP({
        t: "statsFull"
    }, function (c) {
        var d = jQuery.parseJSON(c);
        console.log(d);
        if (d.s) {
            jQuery("#progMe").css("width", (d.p) + "%");
            window.perc = d.p;
            jQuery("#progressText").html(d.t + "<br />" + d.t2);
            jQuery("#unProcessed2").html(d.t);
            jQuery("#imageLib").html(d.i + " images");
            if (parseInt(window.perc) < 100) {
                setTimeout(function () {
                    socialGalleryAdmin_updateStatsFull()
                }, 5000)
            } else {
                jQuery("#progressText").html('<div class="sgsuccess wrap sgM" style="width:382px">Social Gallery Library Update Complete!</div>');
                jQuery("#lastUpdated").html("Completed a moment ago");
                jQuery("#progressBar").removeClass("animate");
                jQuery("#processUpdate").html("<h4>Library Updated...</h4>");
                if (typeof window.onStatCompletion == "function") {
                    window.onStatCompletion()
                }
            }
        }
    })
}

function socialGalleryAdmin_startCrawler() {
    if (!window.crawling) {
        jQuery("#crawler").attr("src", "admin.php?page=sgp-plugin-uber&sgSilentCrawl=true&sgGo=3")
    }
}

function confirmSkip() {
    var a = confirm("skipping the scan will break your social gallery pages... only do this if you need to access settings and RESCAN later following support");
    if (a == true) {
        return true
    } else {
        return false
    }
}

function socialGalleryAdmin_startCrawlerFull() {
    if (!window.crawling) {
        jQuery("#crawlerFull").attr("src", "admin.php?page=sgp-plugin-uber&sgSilentCrawl=true&sgGo=3&sgFull=true")
    }
}
var ubRunning2 = false;
var perc2 = 0;
var crawling2 = false;
jQuery(document).ready(function (b) {
    jQuery("#startUB2").click(function (a) {
        jQuery("#startUB2").attr("disabled", "disabled").fadeOut(100, function () {
            jQuery("#processUpdate2").html("<h4>Updating Social Stats for Library...</h4>")
        });
        jQuery("#ubProgress2").fadeIn(1000, function () {
            if (!window.ubRunning2) {
                window.ubRunning2 = true;
                socialGalleryAdmin_postToAEP({
                    t: "init2"
                }, function (e) {
                    var f = jQuery.parseJSON(e);
                    if (f.s) {
                        jQuery("#progressBar2").addClass("animate");
                        socialGalleryAdmin_startCrawler2();
                        socialGalleryAdmin_updateStats2()
                    }
                })
            }
        })
    })
});

function socialGalleryAdmin_updateStats2() {
    socialGalleryAdmin_postToAEP({
        t: "stats2"
    }, function (c) {
        var d = jQuery.parseJSON(c);
        if (d.s) {
            jQuery("#progMe2").css("width", (d.p) + "%");
            window.perc2 = d.p;
            jQuery("#progressText2").html(d.t + "<br />" + d.t2);
            if (parseInt(window.perc2) < 100) {
                setTimeout(function () {
                    socialGalleryAdmin_updateStats2()
                }, 1000)
            } else {
                jQuery("#progressText2").html('<div class="sgsuccess wrap sgM" id="crawl2success" style="width:382px">Social Gallery Library Update Complete!</div>');
                jQuery("#progressBar2").removeClass("animate");
                jQuery("#processUpdate2").html("<h4>Library Social Stats Updated...</h4>");
                socialGalleryAdmin_postToAEP({
                    t: "totLikeCount"
                }, function (a) {
                    var b = jQuery.parseJSON(a);
                    if (b.s) {
                        jQuery("#crawl2success").append("<br />" + b.r.total + " Total Likes, Shares, Comments, Tweets and Pins!")
                    }
                })
            }
        }
    })
}

function socialGalleryAdmin_startCrawler2() {
    if (!window.crawling2) {
        jQuery("#crawler2").attr("src", "admin.php?page=sgp-plugin-uber&sgSilentCrawlSocial=true&sgGo=3")
    }
}(function () {
    var b = function (a) {
        return Array.prototype.slice.call(document.querySelectorAll(a))
    };
    document.addEventListener("DOMContentLoaded", function () {
        var a;
        b(".sgFieldCB").forEach(function (f) {
            if (f.className === ("sgFieldCB on")) {
                f.lastElementChild.checked = true
            }
            f.addEventListener("click", function e() {
                if (f.className === "sgFieldCB on") {
                    f.className = "sgFieldCB off";
                    var c = "off"
                } else {
                    f.className = ("sgFieldCB on");
                    var c = "on"
                }
                a = f.lastElementChild;
                a.checked = !a.checked;
                if (f.lastElementChild.id == "socialGallery_incDisqusComments" || f.lastElementChild.id == "socialGallery_incFBComments") {
                    if (f.lastElementChild.id == "socialGallery_incDisqusComments" && c == "on") {
                        jQuery("#disqusShort").show();
                        jQuery("#disqusDisclaim").show();
                        jQuery("#socialGallery_incDisqusComments").parent().removeClass("off").addClass("on").attr("checked");
                        jQuery("#socialGallery_incFBComments").parent().removeClass("on").addClass("off").removeAttr("checked")
                    }
                    if (f.lastElementChild.id == "socialGallery_incFBComments" && c == "on") {
                        jQuery("#disqusShort").hide();
                        jQuery("#disqusDisclaim").hide();
                        jQuery("#socialGallery_incFBComments").parent().removeClass("off").addClass("on").attr("checked");
                        jQuery("#socialGallery_incDisqusComments").parent().removeClass("on").addClass("off").removeAttr("checked")
                    }
                }
                socialGalleryAdmin_checkForShows()
            }, false)
        })
    }, false)
})();