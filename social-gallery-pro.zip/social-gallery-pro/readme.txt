Social Gallery - Premium WordPress Social Lightbox [Pro]
Plugin URI: http://www.socialgalleryplugin.com
Description: <a href="http://www.socialgalleryplugin.com">Social Gallery</a> is the ultimate Social Lightbox for WordPress.
Version: 6.0
Author: Mike Stott
Author URI: https://epicplugins.com
---------------------------
Copyright 2012-2016, Epic Plugins.com


--------CHANGE LOG--------------------------------------------------

Version 6.0 - 14th January 2021
===============================
* Improved: 